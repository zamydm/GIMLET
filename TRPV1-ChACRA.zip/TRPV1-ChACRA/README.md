# TRPV1 ChACRA-style analysis (T × salt)

Adapting Burns *et al.*'s ChACRA framework to a 2D grid of straight-MD
runs of TRPV1 spanning temperature and ionic strength.

## Layout

```
TRPV1-ChACRA/
├── ChACRA/                   # vendored ChACRA package (Burns, GitHub)
├── SRC/                      # project Python modules
│   ├── config.py             # paths, condition grid, salt encoding
│   ├── conditions.py         # parse "310K10" → Condition; discovery on disk
│   ├── trajectory_io.py      # MDAnalysis loaders, equil cuts, protein-only writes
│   ├── contacts.py           # atomistic getcontacts wrapper (one state at a time)
│   ├── cg_contacts.py        # CG (Martini) bead-distance contacts
│   ├── frequencies.py        # aggregate per-state freqs into (state × pair) matrix
│   ├── chacra2d.py           # PCA + per-PC partial-R² decomposition into T/salt modes
│   └── plot.py               # PC-vs-(T,salt) heatmaps, loading rank plots, decomp bars
├── Analysis/                 # numbered driver scripts
│   ├── 01_inventory.py       # list every (T, salt) state on disk + frame counts
│   ├── 02_atom_contacts.py   # getcontacts on atomistic grid
│   ├── 03_atom_chacra.py     # PCA + 2D decomp + figures + .pml on atomistic
│   ├── 04_cg_contacts.py     # CG bead-distance contacts
│   └── 05_cg_chacra.py       # PCA + 2D decomp + figures on CG
├── Materials/
│   ├── method_notes.md       # adaptation rationale, expected modes, caveats
│   ├── grid_layout.md        # which states are on disk, salt encoding
│   └── selections/           # per-residue ndx/PML selections (TBD)
```

## Running

The scripts assume the vendored `ChACRA/` package and its conda env (which
provides `getcontacts`, MDAnalysis, sklearn, etc.). After
`conda activate chacra-env`:

```bash
# from the project root
python -m analysis.01_inventory
python -m analysis.02_atom_contacts --jobs 8
python -m analysis.03_atom_chacra
python -m analysis.04_cg_contacts --stride 5
python -m analysis.05_cg_chacra
```

Each step is idempotent — already-computed outputs are skipped — so it's
safe to re-run as states fill in.

## What the analysis yields

- `outputs/chacras/atom_decomp.csv`: one row per PC with explained variance,
  partial R² on T, partial R² on salt, and a label (`T`, `salt`, `coupled`,
  `neither`).
- `outputs/chacras/atom_loadings.csv`: contact-pair × PC matrix; sort by
  `|loading|` to find the residues driving each chacra.
- `outputs/figures/atom_pc_grid.png`: top PCs as 2D heatmaps over the
  (T, salt) grid — at-a-glance diagnostic of T-mode vs salt-mode vs coupled.
- `outputs/pymol/atom_top_chacras.pml`: load alongside
  `materials/8GFA*.pdb` in PyMOL to project chacras onto the structure.

See `materials/method_notes.md` for the rationale behind the 2D extension.
