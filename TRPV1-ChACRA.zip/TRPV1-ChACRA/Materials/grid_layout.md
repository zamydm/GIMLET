# Trajectory inventory (snapshot at project setup)

`DATA_PATH.txt` → `/Volumes/potoyan-lab/zach/TRPV1Simulations`

## Atomistic — `AtomisticCompletedV1/`

|       | 0 mM | 50 mM | 100 mM | 150 mM |
|-------|------|-------|--------|--------|
| 280 K |  ✓   |  ✓    |  ✓     |  ✓     |
| 310 K |  ✓   |  ✓    |  ✓     |  ✓     |
| 315 K |  ✓   |  ✓    |  ✓     |  ✓     |
| 325 K |  ✓   |  ✓    |  ✓     |  ✓     |
| 340 K |  ✓   |  ✓    |  ✓     |  ✓     |

`NPT.xtc` ≈ 2.6 GB / state, plus `NPT-Center.xtc` (centered) and `NPT.tpr`.

In-progress directories with equilibration only (no production yet):
`AtomisticCompletedV1/{290,300,320,330}K??`, `Atomistic/{305,310,315,320,325,330}K{05,10,15}`.

## CG (Martini) — `CoarseCompletedV2/` (V1 fallback)

|       | 0 mM | 50 mM | 100 mM | 150 mM |
|-------|------|-------|--------|--------|
| 280 K |  ✓   |  ✓    |  ✓     |  ✓     |
| 310 K |  ✓   |  ✓    |  ✓     |  ✓     |
| 315 K |  ✓   |  ✓    |  ✓     |  ✓     |
| 325 K |  ✓   |  ✓    |  ✓     |  ✓     |
| 340 K |  ✓   |  ✓    |  ✓     |  ✓     |

`NPT.xtc` ≈ 4.6–4.7 GB / state — CG is run longer, so each state contributes
substantially more frames to the contact statistics than its atomistic
counterpart.

**The CG and atomistic grids are identical** (same 20 conditions),
which makes cross-resolution validation straightforward.

## Reference structure

`Protein/8GFARepairCenter.pdb` — repaired 8GFA tetramer, used as the
ChACRA visualization template.

## Salt encoding

Inferred from the topology of `310K10`:

```
[ molecules ]
TIP3   115473
POT       49        # K+
CLA       49        # Cl-  (pairs K+)
SOD       49        # Na+
CLA       49        # Cl-  (pairs Na+)
SOD       44        # Na+ (charge neutralization)
```

`05/10/15` doubles per increment → roughly 50/100/150 mM total ionic
strength of mixed K⁺ + Na⁺ + Cl⁻. **Confirm with Zach** before claiming
specific concentrations.
