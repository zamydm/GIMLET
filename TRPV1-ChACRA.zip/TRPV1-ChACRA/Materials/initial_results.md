# TRPV1 2D-ChACRA — corrected results

Re-run on 2026-05-12 after discovering that the first pass had 3 states
(315K05, 320K10, 320K15) with **stale MDAnalysis offsets caches** that
reported truncated frame counts (4882 / 16850 / 4882 frames respectively
vs the actual 20001).  Cleared all `.NPTProteinCenter.xtc_offsets.npz`
sidecars and re-extracted those 3 states.

**All 18 states now have ~1750 post-equilibration frames** at stride 10
(50 ns equilibration drop, 4.5 Å heavy-atom cutoff, C4 chain symmetry-
averaged).  The previous (stale) artifacts are archived under
`outputs/chacras/prev_short/` for comparison.

## What changed

The shift from stale → corrected data is substantial:

| Old PC (stale)                | New PC (clean)                                | Change                                                                            |
| ----------------------------- | --------------------------------------------- | --------------------------------------------------------------------------------- |
| **PC1 = coupled (R²_T=0.96)** | **PC1 = salt (R²_T=0.31, R²_S=0.72)**         | the clean T-monotonicity was an artifact of the 3 short states                    |
| PC2 = salt                    | **PC2 = coupled (R²_T=0.85, R²_S=0.56)**      | the *real* T-mode lives here, with positive b_T = contacts weaken with T          |
| PC7 = T (R²_T=0.54)           | PC7 = salt (R²_T=0.20, R²_S=0.78)             | the canonical S6-gate melting set merged into PC2                                 |

Lesson: with 18 states and 3 of them carrying ~7× less data each, the
PCA was being pulled by outliers in a way that *looked* like a clean
T-monotonic PC1.  Fixing the data moved the genuine T-trend to PC2 and
exposed a different (salt-dominated) PC1.

## Significant chacras — corrected

| PC  | var   | label       | R²_T_marg | R²_salt_marg | b_T        | top residues                                                                  |
| --- | ----- | ----------- | --------- | ------------ | ---------- | ----------------------------------------------------------------------------- |
| PC1 | 10.4% | salt        | 0.31      | **0.72**     | −0.060     | inter-subunit gating: R617–D655, Y454–R617, R557–R702/T705                    |
| PC2 |  9.9% | **coupled** | **0.85**  | 0.56         | **+0.141** | **intra-subunit S5/S6 melting** — V595–R615, V596–W616, T597–G618, L598–W616  |
| PC3 |  9.1% | neither     | 0.15      | 0.36         | −0.060     | —                                                                             |
| PC4 |  7.7% | salt        | 0.43      | **0.88**     | +0.094     | S2/S5 pore vestibule: Y454/Y455–(B-chain S5)                                  |
| PC5 |  7.5% | salt        | 0.03      | **0.88**     | −0.017     | **H614** centered: L598–H614, V595–W616, L598–S613                            |
| PC6 |  6.4% | salt        | 0.20      | **1.00**     | −0.029     | S6 gate: A620–L631, L598–W616, T593–P619, H614–F660                           |
| PC7 |  6.2% | salt        | 0.20      | 0.78         | −0.035     | S6 gate / pore helix: V595–W616, A620–S630, R615–V659                         |

Cumulative variance: PC1–5 = 44.6%, PC1–10 = 72.4% (essentially unchanged).

### PC2 — the *real* canonical melting mode (now properly classified)

`b_T = +0.141`, R²_T = 0.85.  PC scores averaged over salt:

```text
T (K)   PC2_avg
305     -1.81
310     -0.82
315     -0.12
320     +0.13
325     +0.13
330     +2.50
```

Strong monotonic rise across T, with a steep jump at 325→330 K.  All
top loadings are **negative**, meaning these intra-subunit S5/S6 packing
contacts *weaken* as T increases — the textbook "S6 gate melting":

- **V595–R615** (S5–pore helix)
- **V596–W616** (S5–S6)
- **T597–G618** (S5–S6)
- **L598–W616** (S5–S6)
- **V596–G618** (S5–S6)
- **L598–T(R)615** (S5–pore helix)
- **T612–L631** (pore helix–S6, positive sign — strengthens with T)

The 325→330 K jump is interesting — it's near the temperature where
TRPV1 is supposed to activate (~315-325 K).  Worth examining whether
that's a real transition or just a single noisy state.

### PC1 — salt-modulated inter-subunit gating contacts

R²_salt = 0.72 with `b_T = −0.06` (mild residual T effect).  PC scores:

T-marginal (averaged over salt):

```text
305: +1.21    315: -1.30    325: -0.81
310: +1.12    320: -0.29    330: +0.05
```

*Non-monotonic in T*, with a sharp dip at 315 K.

Salt-marginal (averaged over T):

```text
50 mM: -0.29    100 mM: +0.15    150 mM: +0.14
```

Top loadings include the key inter-subunit gating contacts:

- **A:ARG:617 – B:ASP:655** (−)  inter-subunit salt bridge (S5 Arg to
  pore-helix Asp, *between* chains)
- **A:LEU:598 – A:SER:613** (−)  intra-S6
- **A:ARG:557 – A:THR:705** (+)  S4 → TRP-domain
- **A:ARG:615 – A:PHE:660** (−)  pore helix
- **A:TRP:616 – A:PHE:660** (−)  S6 / pore helix
- **A:TYR:454 – B:ARG:617** (+)  S2 → inter-subunit S5
- **A:ARG:557 – A:ARG:702** (+)  S4 → TRP-domain (charge cluster)

So PC1 captures the **inter-subunit gating-cluster contacts** (especially
the R617–D655 salt bridge and the R557 / TRP-domain interface) reorganizing
as ionic strength changes.  The mild T-dependence (b_T = -0.06) suggests
these contacts also weaken slightly at high T, but the dominant axis is
salt — likely because the involved residues (R557, R617, R557, R740) are
all charged and feel Debye screening directly.

### Salt-mode story: H614 and P619 are central

Looking across PC4–PC7 (all salt-classified, var ~6–8% each):

- **H614** dominates PC5 and PC6.  H614 is the textbook TRPV1 pore-helix
  histidine, implicated in proton/pH sensing.  Its contacts to L598,
  S613, F650, F660 all rearrange systematically with salt.
- **P619** appears in PCs 4 and 6, contacting T593, T597, T450 (S2),
  M451.  P619 is the S6 helix kink residue.
- **R615 / R617** (S5–pore boundary) and the **R617–D655 salt bridge**
  appear in PC1, PC5, PC6 — multiple modes, suggesting these are the
  most ion-environment-sensitive residues.

This is more consistent with a story where **ionic environment modulates
the gating-region contacts more than temperature does** — at least in
the 305–330 K window we sampled.  TRPV1 activation is supposed to occur
around 315-325 K, so most of our T range straddles activation; the
salt response may be on top of an already activation-poised channel.

## Caveats (unchanged)

1. **3-level salt grid** (50/100/150 mM) — marginal-R²(salt) test passes
   easily for any monotonic trend on 3 points.  Adding 0 mM and 200 mM
   would strengthen salt-mode assignments.
2. **Pure-T modes are now scarce in the top-10**.  After fixing the
   3 short states, no top PC is purely T-classified (PC2 is coupled).
   This may be because (a) salt variation creates more variance than T
   in this regime, or (b) the T window doesn't span the activation
   transition cleanly.
3. **PC permutation significance** (1000-rep test) still needs to be
   run explicitly — current run used the chacra default which appears
   to have been truncated.
4. **315 K outlier behavior** on PC1 — sharp dip not present at neighboring
   temperatures.  Worth checking the 315K state RMSD curves to see if
   that's an equilibration artifact vs. a real T-localized transition.
5. **325→330 K jump on PC2** could be the activation transition; worth
   examining the open-vs-closed gate diameter in those frames.

## Files

- `outputs/chacras/atom_decomp.csv` — corrected per-PC classification
- `outputs/chacras/atom_scores.csv`, `atom_loadings.csv` — corrected
- `outputs/matrices/atom_freqs_symavg.parquet` — 18 × 8724 matrix
- `outputs/chacras/prev_short/` — previous (stale-cache) artifacts archived
- `outputs/figures/atom_pc_grid.png` — 2D heatmap of top 4 PCs over (T, salt)
- `outputs/figures/atom_top_loadings_PC{1..4}.png` — top contacts per PC
