# Reconciling Figure 4 (raw contact variance) with Figure 5 (ChACRA) — data check, 2026-09-08

Source: `outputs/matrices/{atom,cg}_freqs_symavg.parquet` (Fig 4 basis: symmetry-averaged
contact probabilities, 18 states), `*_symfilt.parquet` (C4-filtered), `outputs/chacras/*_symmetry_scores.csv`.
"var-across-T" = variance over the 6 temperatures at fixed salt, averaged over the 3 salts (what Fig 4 plots).
CG residue numbers below are shifted +198 to 8GFA numbering (verified: 556/556 residue names match).
Scripts: scratchpad `reconcile.py`, `reconcile_cg.py`; CG filtered ChACRA = `analysis/21_cg_chacra_symfilt.py`.

## 1. How much of the raw Fig-4 variance is artifact?

| quantity | atomistic | CG |
|---|---|---|
| contacts involving built loop 602-626 | 24% of contacts | 25% |
| share of var-across-T carried by loop contacts | 43% | 54% |
| share of var-across-T in pore/S6 bin (600-690) | 42% | 63% |
| cytoplasmic (ANK + pre-S1 + TRP/C-term) share | 35% | 8% |
| contacts with signal removed by C4 filter (consistency < 0.5) | 44% (2050/4692) | 24% (820/3369) |
| share of var-across-T carried by removed contacts | 57% | 59% |
| share of var-across-salt carried by removed contacts | 59% | 54% |
| loop var-across-T that is removed | 94% | 98% |
| pore/S6 var-across-T that is removed | 85% | 71% |
| ANK / pre-S1 / TRP var-across-T removed | 26 / 18 / 25% | 32 / 38 / 11% |
| top-12 var-across-T contacts with consistency = 0.25 (1 of 4 subunits) | 12 of 12 | 12 of 12 |

Atomistic top-12 raw hot spots are all loop (613-620) contacts to S5 (595-598) plus R617-D655 and T450-P619.
CG top-12 raw hot spots are inter-subunit ANK(249-341) to pre-S1(415-423) and pre-S1(417/418)-Y469.

## 2. After the filter (same contact set as Fig 5)

| regional share of var-across-T | atomistic | CG |
|---|---|---|
| ankyrin | 28% | 6% |
| pre-S1 | 16% | 4% |
| TRP / C-term | 18% | 5% |
| S1-S4 | 12% | 16% |
| S4-S5 / S5 | 11% | 25% |
| pore / S6 | 15% | 44% |
| loop 602-626 | 6% | 3% |
| intra : inter | 84 : 16 | 42 : 58 |

## 3. Salt vs temperature magnitude

| | atomistic raw | atomistic filt | CG raw | CG filt |
|---|---|---|---|---|
| total var-across-salt / total var-across-T | 0.77 | 0.73 | 0.73 | 0.83 |
| correlation between per-salt var-across-T maps | 0.56-0.62 | 0.67-0.68 | 0.73-0.77 | 0.55-0.85 |

Salt moves contacts ~3/4 as much as temperature. "Salt has little impact" is wrong; "the temperature-variance
pattern is similar at each salt" is right.

## 4. CG ChACRA on the filtered set (new, script 21)

| PC | var | R2_T | R2_S | label | regional localization (top 3) |
|---|---|---|---|---|---|
| 1 | 33% | 0.46 | 0.44 | neither | pore/S6 39, S4-S5 21, S1-S4 18 |
| 2 | 15% | 0.52 | 0.16 | T | S1-S4 25, S4-S5 23, pore/S6 22 |
| 3 | 12% | 0.32 | 1.00 | salt | pore/S6 34, S4-S5 18, ANK 16 |
| 4 | 7% | 0.10 | 0.70 | salt | |
| 5 | 6% | 0.71 | 0.59 | coupled | |
| 6 | 5% | 0.09 | 0.94 | salt | |

Atomistic filtered T mode (PC1, R2_T 0.75): ANK 33, pre-S1 21, TRP/C-term 18 (71% cytoplasmic).
CG filtered T mode (PC2, R2_T 0.52): 70% TM. Per-residue T responsiveness atom vs CG: Pearson 0.04, Spearman 0.21.
Top T-mode residues atom: R740, 365, D738, 237, 368, 375, 246, 236, 731, 324. CG: 549, M645, 597, 542, 456, 545, 537, 594, 446, 546.

**Conclusion.** The two resolutions do NOT agree on where the temperature-responsive contact network is.
Earlier claim "CG ≈ 0 across TM" (analysis/15, outputs/figures/regional_comparison.png) was an offset bug
(CG numbering 1-556 binned against 8GFA ranges) and is retracted.

## Recommendation for the manuscript

Filter first (option B). Regenerate Fig 4 from `*_freqs_symfilt.parquet`; move the raw maps to SI as the
"what the filter removes" panel. Then Fig 4 and Fig 5 use one contact set and the loop/pore hot spots do not
have to be interpreted and then withdrawn. Report CG ChACRA in SI as a genuine divergence between resolutions.
