# 2D-ChACRA for TRPV1 across temperature × salt

## Why this is non-standard

ChACRA was designed for **HREMD** simulations: a single Hamiltonian-replica
ladder where each replica scales the protein force-field, and contact
frequencies are computed per-state at a common reference temperature. The
PCA across replicas then surfaces "chacras" — collective contact modes that
respond coherently to the perturbation axis (effective temperature).

Zach's TRPV1 dataset is **straight MD on a 2D (T, [NaCl]) grid**:

- Atomistic: T ∈ {280, 310, 315, 325, 340} K × salt ∈ {0, 50, 100, 150} mM →
  20 independent simulations, ~2.6 GB / 100 ns each.
- CG (Martini): same 5 × 4 grid, ~4.6–4.7 GB / multi-µs each.

Identical grids mean the atomistic and CG ChACRAs can be compared one-to-one.

That breaks two ChACRA assumptions:

1. **No exchange weighting**: each state is its own production run; we have
   no exchange probabilities to validate convergence between states. We
   compensate with explicit equilibration cuts (`equil_cut` defaults: 50 ns
   atomistic, 100 ns CG) and per-block bootstrap CIs on PC eigenvalues.
2. **Two perturbation axes, not one**: the chacras are no longer purely
   temperature-driven. We adapt by post-hoc decomposing each PC's score
   vector against `T` and `[NaCl]`.

## Pipeline

```text
                   per-state contacts                aggregated
trajectories ──►  (getcontacts | CG cutoff)  ──►   (state × pair)  ──► PCA + decomp
                                                       matrix
```

1. **Per-state contact frequencies** (`src/contacts.py` for atomistic,
   `src/cg_contacts.py` for CG). One TSV per state, schema identical to
   getcontacts so the same downstream code works.
2. **Aggregation** (`src/frequencies.py`): build a `(state × contact-pair)`
   DataFrame with MultiIndex `(T_K, salt_mM)` and columns `chain:resn:resid-…`.
   Missing pairs filled with 0. Then **symmetry-average across the 4 chains**
   of the TRPV1 tetramer using `chacra.average.average_multimer` with
   `representative_chains=["A"]`. Each unique chemical contact appears 4×
   in the raw matrix (A-A, B-B, C-C, D-D self; plus A-B/B-C/C-D/D-A
   inter-subunit and A-C/B-D diagonal); collapsing these into one column
   per equivalence class boosts effective sample size 4× on the PCA.
   Symmetry-averaging is on by default (`symmetry_average=True`).
3. **PCA** (`src/chacra2d.run`): hand the flattened matrix to ChACRA's
   `ContactFrequencies` for the standard PCA + permutation significance.
4. **2D mode decomposition** (`src/chacra2d.decompose_modes`): for each PC k,
   fit `score_k ~ b0 + b_T·T + b_S·salt` and compute partial R² on T and on
   salt. Classify each PC:

   | Partial R²(T) ≥ τ | Partial R²(salt) ≥ τ | Label       |
   |-------------------|----------------------|-------------|
   | ✓                 | ✗                    | **T**       |
   | ✗                 | ✓                    | **salt**    |
   | ✓                 | ✓                    | **coupled** |
   | ✗                 | ✗                    | neither     |

   τ defaults to 0.5; tune in the script.

## What we expect to see

- **PC1 = T-mode (melting)**. The original ChACRA PC1 captures contacts that
  weaken with T; same should hold here. Verify b_T < 0 and partial R²(T) ≫
  partial R²(salt).
- **PC2 or PC3 = salt-mode**. Likely picks up surface-charged residues
  (Asp, Glu, Lys, Arg) on the cytosolic and pore-mouth faces — contacts
  whose populations track Debye screening as ionic strength increases.
- **Coupled modes (mid-rank PCs)** are the scientifically interesting ones:
  contacts whose temperature response is *gated* by ionic environment
  (different b_T at low vs high salt → coupling captured by the interaction
  term, which we can extend to `score ~ T + salt + T·salt` if PC1/PC2
  alone don't give a clean split).

## Caveats and validation

- **Non-uniform T grid**: T ∈ {280, 310, 315, 325, 340} K — clusters around
  physiological T with anchors at the cold and hot ends. PC1 score vs T is
  not linear by construction; treat the linear-fit b_T as a directional
  indicator, not a slope. The 280 K and 340 K endpoints are especially
  valuable — TRPV1 is a heat-activated channel, so the 325→340 K leg may
  capture activation-related contact rearrangements.
- **Mixed salt is intentional**: `00/05/10/15` ≈ 0/50/100/150 mM total ionic
  strength of mixed K⁺ + Na⁺ + Cl⁻. The mixing is a deliberate design choice
  to probe **cation selectivity** of TRPV1 gating (TRPV1 is non-selective
  among monovalent cations but with measurable preferences). Salt-mode
  chacras may therefore report on selectivity-relevant residues — pore-
  facing acidic residues in the selectivity filter (Asp/Glu) and outer-
  vestibule sites — rather than only general electrostatic screening.
  Worth examining the cation-residue radial distribution functions
  (separately for K⁺ and Na⁺) at the residues that drive each salt-mode
  chacra to disentangle screening from cation-specific binding.
- **CG vs atomistic crosstalk**: BB-bead distance contacts ≠ getcontacts
  interaction-typed contacts. Compare CG and atomistic chacras only on a
  shared residue-pair basis (e.g. coarse-grain the atomistic contact pairs
  to BB-BB).
- **Tetrameric symmetry-averaging is on by default** in `frequencies.build_matrix`.
  After PCA, use `chacra.average.everything_from_averaged` to broadcast the
  averaged loadings back to all 4 chains for PyMOL visualization.

## References

- Burns *et al.* PCB 2022 (EI temperature-sensitive contacts) → original
  ChACRA pipeline.
- Burns *et al.* PLOS CB 2023 (TRPV3 paper, in repo as `trpv3_paper.pdf`) →
  closest precedent; uses HREMD on TRPV3.
- Burns *et al.* JCTC 2024 (`chacra_paper.pdf`) → method paper; relevant
  sections on permutation significance and `CombinedChacra` for combining
  ensembles.
