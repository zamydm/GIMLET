"""
Lead figure (symmetry-filtered): the defensible atomistic ChACRA result.

After removing C4-symmetry-broken basin-trapping artifacts (44% of contacts,
incl. the spurious R617-D655 "salt bridge"), the reliable signal is:
  (a) a clean spectrum — temperature mode at PC1 (R²_T=0.75), salt modes
      following;
  (b) localized to the cytoplasmic coupling apparatus (ankyrin repeats,
      pre-S1, TRP helix, S4), NOT the pore gate (which was mostly artifacts).

Panel B shows, per structural region, how much of each mode's
responsiveness sits there — temperature (blue) vs salt (red) — making the
cytoplasmic localization and the gate's collapse visible without a render.

Main-text font sizes. No SMB volume needed (local CSVs only).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpec

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config

mpl.rcParams.update({
    "font.family": "sans-serif", "font.size": 14, "axes.titlesize": 16,
    "axes.labelsize": 15, "xtick.labelsize": 13, "ytick.labelsize": 13,
    "legend.fontsize": 13, "axes.spines.top": False, "axes.spines.right": False,
})

C_T, C_S, C_N = "#2166ac", "#b2182b", "#cfcfcf"
DOMAINS = [(110, 360, "ankyrin repeats"), (360, 430, "pre-S1"),
           (430, 545, "S1–S4 (VSLD)"), (545, 600, "S4–S5 / S5"),
           (600, 690, "pore / S6 gate"), (690, 760, "TRP helix / C-term")]


def dom(ri):
    for lo, hi, nm in DOMAINS:
        if lo <= ri < hi:
            return nm
    return "other"


def main():
    dec = pd.read_csv(config.OUTPUTS / "chacras/atom_decomp_symfilt.csv", index_col=0)
    L = pd.read_csv(config.OUTPUTS / "chacras/atom_loadings_symfilt.csv", index_col=0)

    fig = plt.figure(figsize=(16.5, 6.4))
    gs = GridSpec(2, 2, width_ratios=[1.05, 1.0], height_ratios=[1, 1],
                  left=0.055, right=0.99, top=0.90, bottom=0.13,
                  wspace=0.30, hspace=0.62)
    ax = fig.add_subplot(gs[0, 0])     # (a) spectrum
    axb = fig.add_subplot(gs[1, 0])    # (b) regional
    axc = fig.add_subplot(gs[:, 1])    # (c) structure (spans both rows)

    # ── (a) filtered spectrum ───────────────────────────────────────────
    n = 6
    d = dec.iloc[:n]
    y = np.arange(len(d))[::-1]
    var = d["var_explained"].to_numpy() * 100
    r2T = d["r2_T_marginal"].to_numpy()
    r2S = d["r2_salt_marginal"].to_numpy()
    sig = np.maximum(r2T, r2S) >= 0.5
    cmap = plt.cm.RdBu
    colors = [C_N if not s else cmap(np.clip(t - sa, -0.5, 0.5) + 0.5)
              for s, t, sa in zip(sig, r2T, r2S)]
    ax.barh(y, var, color=colors, edgecolor="black", linewidth=0.6, height=0.74)
    for yi, pc, v, t, sa, s in zip(y, d.index, var, r2T, r2S, sig):
        tag = "neither" if not s else ("temperature" if (t - sa) > 0 else "salt")
        ax.text(v + 0.25, yi, f"PC{pc} · {tag}  (R²$_T$={t:.2f}, R²$_S$={sa:.2f})",
                va="center", fontsize=12)
    ax.set_yticks([]); ax.set_xlabel("variance explained (%)")
    ax.set_xlim(0, max(var) * 2.1)
    ax.text(0.0, 1.03, "a", transform=ax.transAxes, fontsize=18,
            fontweight="bold", va="bottom", ha="left")
    handles = [mpl.patches.Patch(color=cmap(0.95), label="temperature"),
               mpl.patches.Patch(color=cmap(0.05), label="salt"),
               mpl.patches.Patch(color=C_N, label="neither")]
    ax.legend(handles=handles, loc="lower right", frameon=False, fontsize=11,
              ncol=1, title="mode character", title_fontsize=11)

    # ── (b) regional localization, split by mode class ──────────────────
    pat = re.compile(r"[A-Z]:[A-Z0-9]+:(\d+)-[A-Z]:[A-Z0-9]+:(\d+)")
    regnames = [nm for _, _, nm in DOMAINS]
    Tband = {nm: 0.0 for nm in regnames}
    Sband = {nm: 0.0 for nm in regnames}
    for pc in range(1, 8):
        col = f"PC{pc}"
        if col not in L.columns:
            continue
        lab = dec.loc[pc, "label"]
        is_T = (dec.loc[pc, "r2_T_marginal"] - dec.loc[pc, "r2_salt_marginal"]) > 0 \
            and max(dec.loc[pc, "r2_T_marginal"], dec.loc[pc, "r2_salt_marginal"]) >= 0.5
        is_S = (not is_T) and dec.loc[pc, "r2_salt_marginal"] >= 0.5
        if not (is_T or is_S):
            continue
        w = dec.loc[pc, "var_explained"]
        band = Tband if is_T else Sband
        for c, v in (L[col].abs() * w).items():
            m = pat.match(c)
            if not m:
                continue
            for ri in (int(m.group(1)), int(m.group(2))):
                band[dom(ri)] = band.get(dom(ri), 0) + v
    tot = sum(Tband.values()) + sum(Sband.values())
    yb = np.arange(len(regnames))[::-1]
    Tv = np.array([Tband[nm] for nm in regnames]) / tot * 100
    Sv = np.array([Sband[nm] for nm in regnames]) / tot * 100
    axb.barh(yb, Tv, color=C_T, edgecolor="black", linewidth=0.4, label="temperature mode")
    axb.barh(yb, Sv, left=Tv, color=C_S, edgecolor="black", linewidth=0.4, label="salt modes")
    axb.set_yticks(yb); axb.set_yticklabels(regnames)
    axb.set_xlabel("share of responsiveness (%)")
    axb.text(0.0, 1.03, "b", transform=axb.transAxes, fontsize=18,
             fontweight="bold", va="bottom", ha="left")
    axb.legend(loc="lower right", frameon=False, fontsize=12)
    # shade the cytoplasmic regions
    for yi, nm in zip(yb, regnames):
        if nm in ("ankyrin repeats", "pre-S1", "TRP helix / C-term"):
            axb.axhspan(yi - 0.5, yi + 0.5, color="#fff8e1", zorder=0)

    # ── (c) structure ───────────────────────────────────────────────────
    img_path = config.OUTPUTS / "figures" / "lead_structure_filtered.png"
    if img_path.exists():
        img = mpimg.imread(img_path)
        gray = img[..., :3].mean(2) if img.ndim == 3 else img
        rows = np.where((gray < 0.97).any(1))[0]
        cols = np.where((gray < 0.97).any(0))[0]
        if len(rows) and len(cols):
            p = 12
            img = img[max(rows[0]-p, 0):rows[-1]+p, max(cols[0]-p, 0):cols[-1]+p]
        axc.imshow(img)
    axc.text(0.0, 1.0, "c", transform=axc.transAxes, fontsize=18,
             fontweight="bold", va="bottom", ha="left")
    axc.axis("off")

    out = config.OUTPUTS / "figures" / "lead_atomistic.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    print(f"saved {out}")
    print(f"cytoplasmic share: {Tv[0]+Sv[0]+Tv[1]+Sv[1]+Tv[5]+Sv[5]:.0f}%")


if __name__ == "__main__":
    main()
