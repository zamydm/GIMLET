"""
CG (Martini 3) ChACRA on C4-symmetry-filtered contacts — the CG twin of
17_atom_chacra_symfilt.py, so the two resolutions can be compared on equal
footing.  CG residue numbering in the freq files is 1-based (TYR1 == TYR199
of 8GFA); the +198 offset is applied only in downstream region binning.

Outputs (suffix _symfilt):
  outputs/chacras/cg_decomp_symfilt.csv
  outputs/chacras/cg_loadings_symfilt.csv
  outputs/chacras/cg_scores_symfilt.csv
  outputs/chacras/cg_symmetry_scores.csv
  outputs/matrices/cg_freqs_symfilt.parquet
"""
from __future__ import annotations
import sys
from pathlib import Path
import pandas as pd
_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_root)); sys.path.insert(0, str(_root / "ChACRA"))
from src.conditions import Condition
from src import frequencies, symmetry_filter, chacra2d, config
MIN_CONSISTENCY = 0.5

def main():
    conds = [Condition(T=int(f.stem[6:9]), salt_code=f.stem[10:12], resolution="cg")
             for f in sorted((config.OUTPUTS / "freqs/cg").glob("freqs_*.tsv"))]
    raw = frequencies.build_matrix(conds, resolution="cg", symmetry_average=False)
    print(f"[raw] {raw.shape[0]} states x {raw.shape[1]} raw contacts")
    avg, scores = symmetry_filter.filtered_average(raw, min_consistency=MIN_CONSISTENCY)
    n_total = scores["consistency"].notna().sum(); n_keep = avg.shape[1]
    print(f"[filter] kept {n_keep}/{n_total} (consistency >= {MIN_CONSISTENCY}); dropped {n_total-n_keep}")
    frequencies.save_matrix(avg, "cg_freqs_symfilt")
    scores.to_csv(config.OUTPUTS / "chacras/cg_symmetry_scores.csv")
    res = chacra2d.run(avg, n_permutations=1000, n_jobs=4, r2_thresh=0.5)
    out = config.OUTPUTS / "chacras"
    res["scores"].to_csv(out / "cg_scores_symfilt.csv")
    res["loadings"].to_csv(out / "cg_loadings_symfilt.csv")
    res["decomp"].to_csv(out / "cg_decomp_symfilt.csv")
    print(res["decomp"][["var_explained", "r2_T_marginal", "r2_salt_marginal", "label"]].head(7).round(3))

if __name__ == "__main__":
    main()
