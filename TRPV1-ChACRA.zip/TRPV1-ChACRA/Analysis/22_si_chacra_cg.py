"""Supplemental figure: C4 consistency distribution (atom vs CG), filtered CG ChACRA
spectrum, and T-mode regional share at both resolutions. -> outputs/figures/ChACRA_CG_SI.png"""
import re, sys
from pathlib import Path
import numpy as np, pandas as pd, matplotlib as mpl
mpl.use("Agg"); import matplotlib.pyplot as plt
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config
mpl.rcParams.update({"font.size": 12, "axes.spines.top": False, "axes.spines.right": False})
C_T, C_S, C_N = "#2166ac", "#b2182b", "#cfcfcf"
DOMAINS = [(110, 360, "ankyrin repeats"), (360, 430, "pre-S1"), (430, 545, "S1–S4 (VSLD)"),
           (545, 600, "S4–S5 / S5"), (600, 690, "pore / S6 gate"), (690, 760, "TRP helix / C-term")]
def dom(r):
    for lo, hi, n in DOMAINS:
        if lo <= r < hi: return n
    return "other"
pat = re.compile(r"[A-Z]:[A-Z0-9]+:(\d+)-[A-Z]:[A-Z0-9]+:(\d+)")
O = config.OUTPUTS
sa = pd.read_csv(O/"chacras/atom_symmetry_scores.csv", index_col=0)["consistency"].dropna()
sc = pd.read_csv(O/"chacras/cg_symmetry_scores.csv", index_col=0)["consistency"].dropna()
dec_c = pd.read_csv(O/"chacras/cg_decomp_symfilt.csv", index_col=0)
L_c = pd.read_csv(O/"chacras/cg_loadings_symfilt.csv", index_col=0)
dec_a = pd.read_csv(O/"chacras/atom_decomp_symfilt.csv", index_col=0)
L_a = pd.read_csv(O/"chacras/atom_loadings_symfilt.csv", index_col=0)

def regional(L, pc, off):
    w = L[f"PC{pc}"].abs(); reg = {n: 0.0 for _, _, n in DOMAINS}
    for c, v in w.items():
        m = pat.match(c)
        if not m: continue
        for r in (int(m.group(1)) + off, int(m.group(2)) + off):
            d = dom(r)
            if d in reg: reg[d] += v / 2
    t = sum(reg.values()); return {k: v / t * 100 for k, v in reg.items()}

fig, axes = plt.subplots(1, 3, figsize=(19, 5.2), gridspec_kw=dict(width_ratios=[1, 1.3, 1.1], wspace=0.55))
# (a) consistency histograms
ax = axes[0]
bins = np.array([0.125, 0.375, 0.625, 0.875, 1.125])
ha, _ = np.histogram(sa, bins=bins); hc, _ = np.histogram(sc, bins=bins)
x = np.array([0.25, 0.5, 0.75, 1.0]); wdt = 0.09
ax.bar(x - wdt/2 - 0.005, ha / ha.sum() * 100, width=wdt, color=C_T, label=f"atomistic (n={len(sa)})")
ax.bar(x + wdt/2 + 0.005, hc / hc.sum() * 100, width=wdt, color=C_S, label=f"coarse-grained (n={len(sc)})")
ax.axvline(0.5 - 0.125, color="black", ls="--", lw=1); ax.set_ylim(0, 80); ax.text(0.5 - 0.135, 38, "removed", ha="right", fontsize=10); ax.text(0.5 - 0.115, 38, "kept", ha="left", fontsize=10)
ax.set_xticks(x); ax.set_xticklabels(["0.25\n1 of 4", "0.50\n2 of 4", "0.75\n3 of 4", "1.00\n4 of 4"])
ax.set_xlabel("C4 consistency score (subunit copies present)"); ax.set_ylabel("contacts with signal (%)")
ax.legend(frameon=False, fontsize=10, loc="upper center", ncol=1, bbox_to_anchor=(0.5, 1.0)); ax.text(-0.15, 1.05, "a", transform=ax.transAxes, fontsize=18, fontweight="bold")
# (b) CG spectrum
ax = axes[1]
n = 6; y = np.arange(n)[::-1]
cols, labs = [], []
for pc in range(1, n + 1):
    rT, rS = dec_c.loc[pc, "r2_T_marginal"], dec_c.loc[pc, "r2_salt_marginal"]
    isT = rT > rS and rT >= 0.5; isS = (not isT) and rS >= 0.5
    cols.append(C_T if isT else C_S if isS else C_N)
    labs.append(f"PC{pc} · {'temperature' if isT else 'salt' if isS else 'neither'}  (R²$_T$={rT:.2f}, R²$_S$={rS:.2f})")
v = dec_c.loc[1:n, "var_explained"].values * 100
ax.barh(y, v, color=cols, edgecolor="black", linewidth=0.4)
for yi, vi, lb in zip(y, v, labs): ax.text(vi + 0.6, yi, lb, va="center", fontsize=10)
ax.set_yticks([]); ax.set_xlim(0, 110); ax.set_xticks([0, 20, 40, 60]); ax.set_xlabel("variance explained (%)"); ax.set_title("coarse-grained, C4-filtered", fontsize=12)
ax.text(-0.05, 1.05, "b", transform=ax.transAxes, fontsize=18, fontweight="bold")
# (c) T-mode regional share, atom PC1 vs CG PC2
ax = axes[2]
ra = regional(L_a, 1, 0); rc = regional(L_c, 2, 198)
names = [n_ for _, _, n_ in DOMAINS]; y = np.arange(len(names))[::-1]; h = 0.38
ax.barh(y + h/2, [ra[k] for k in names], height=h, color=C_T, edgecolor="black", linewidth=0.4, label="atomistic T mode (PC1, R²$_T$=0.75)")
ax.barh(y - h/2, [rc[k] for k in names], height=h, color=C_S, edgecolor="black", linewidth=0.4, label="coarse-grained T mode (PC2, R²$_T$=0.52)")
for yi, nm in zip(y, names):
    if nm in ("ankyrin repeats", "pre-S1", "TRP helix / C-term"):
        ax.axhspan(yi - 0.5, yi + 0.5, color="#fff3d6", zorder=0)
ax.set_yticks(y); ax.set_yticklabels(names); ax.set_xlabel("share of T-mode responsiveness (%)"); ax.set_xlim(0, 40)
ax.legend(frameon=False, fontsize=10, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=1); ax.text(-0.5, 1.05, "c", transform=ax.transAxes, fontsize=18, fontweight="bold")
out = O/"figures/ChACRA_CG_SI.png"; fig.savefig(out, dpi=220, bbox_inches="tight"); print("wrote", out)
print("atom T regional", {k: round(v,1) for k,v in ra.items()}); print("CG T regional", {k: round(v,1) for k,v in rc.items()})
