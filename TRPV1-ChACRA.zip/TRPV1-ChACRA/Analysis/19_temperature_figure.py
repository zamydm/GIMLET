"""
Temperature-sensitivity figure, ChACRA loading-score selection (Burns method).

The temperature mode is PC1 of the symmetry-filtered ChACRA. Following Burns
et al., the temperature-sensitive contacts are the highest |loading| contacts
on that mode. Treating the three salinities as independent replicates at each
temperature (on top of the four-monomer C4 average) gives the curve means and
their standard error.

Panel a: representative contact-frequency vs temperature curves with SEM error
bars over the salt runs; red = weakens with heat, blue = strengthens. Panel b:
the responsive residues mapped onto the structure (single colour; they localize
to the cytoplasmic coupling apparatus, the melt/form split lives in panel a).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpec

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.conditions import Condition
from src import frequencies, symmetry_filter as sf, config

mpl.rcParams.update({
    "font.family": "sans-serif", "font.size": 14, "axes.titlesize": 16,
    "axes.labelsize": 15, "xtick.labelsize": 13, "ytick.labelsize": 13,
    "legend.fontsize": 11, "axes.spines.top": False, "axes.spines.right": False,
})

# orange = weakens with heat, purple = strengthens with heat.
# Distinct from the red(salt)/blue(temperature) scheme of the main ChACRA figure.
C_MELT, C_FORM = "#e08214", "#8073ac"
N_TOP = 18          # Burns: top 18 contacts per mode
N_CURVE = 3         # representative curves per direction

ONE = {"ARG": "R", "LYS": "K", "ASP": "D", "GLU": "E", "TYR": "Y", "SER": "S",
       "THR": "T", "LEU": "L", "VAL": "V", "PHE": "F", "ALA": "A", "GLY": "G",
       "ILE": "I", "MET": "M", "CYS": "C", "ASN": "N", "GLN": "Q", "PRO": "P",
       "TRP": "W", "HSD": "H", "HIS": "H"}


def nice(c):
    return "-".join(f"{ONE.get(rn, rn)}{ri}" for rn, ri in re.findall(r"[A-Z]:([A-Z]+):(\d+)", c))


def main():
    L = pd.read_csv(config.OUTPUTS / "chacras/atom_loadings_symfilt.csv", index_col=0)
    top = L["PC1"].abs().sort_values(ascending=False).head(N_TOP).index.tolist()

    conds = [Condition(T=int(f.stem[6:9]), salt_code=f.stem[10:12], resolution="atom")
             for f in sorted((config.OUTPUTS / "freqs/atom").glob("freqs_*.tsv"))]
    raw = frequencies.build_matrix(conds, resolution="atom", symmetry_average=False)
    avg, _ = sf.filtered_average(raw, min_consistency=0.5)
    avg.index = pd.MultiIndex.from_tuples(avg.index, names=["T", "salt"])
    Ts = np.array(sorted(avg.index.get_level_values("T").unique()), dtype=float)
    mean_T = avg.groupby("T").mean()
    sem_T = avg.groupby("T").std() / np.sqrt(avg.groupby("T").count().clip(lower=1))
    X = np.vstack([Ts, np.ones_like(Ts)]).T

    # melt/form by replica-averaged slope; also R^2 to pick clean curves
    info = {}
    for c in top:
        if c not in mean_T.columns:
            continue
        y = mean_T[c].values
        b = np.linalg.lstsq(X, y, rcond=None)[0]
        pred = X @ b
        r2 = 1 - ((y - pred)**2).sum() / max(((y - y.mean())**2).sum(), 1e-9)
        info[c] = (b[0], r2, abs(L.loc[c, "PC1"]))
    melt = sorted([c for c, v in info.items() if v[0] < 0], key=lambda c: -info[c][2])
    form = sorted([c for c, v in info.items() if v[0] > 0], key=lambda c: -info[c][2])
    # representative curves: curated from the top-18 to span regions
    # (TRP hub, C-terminal bridge, gate; pre-S1, ankyrin) rather than 3 R740 lines
    curated_melt = ["A:SER:367-A:ARG:740", "A:GLY:730-A:ASP:738", "A:TYR:731-A:LYS:736"]
    curated_form = ["A:LEU:354-A:LYS:369", "A:ASP:297-A:THR:303", "A:GLU:327-A:ARG:368"]
    melt_show = [c for c in curated_melt if c in mean_T.columns] or melt[:N_CURVE]
    form_show = [c for c in curated_form if c in mean_T.columns] or form[:N_CURVE]

    fig = plt.figure(figsize=(13.5, 5.8))
    gs = GridSpec(1, 2, width_ratios=[1.0, 1.15],
                  left=0.07, right=0.99, top=0.93, bottom=0.27, wspace=0.10)
    ax = fig.add_subplot(gs[0, 0])
    axs = fig.add_subplot(gs[0, 1])

    for c in melt_show + form_show:
        col = C_MELT if c in melt_show else C_FORM
        ax.errorbar(Ts, mean_T[c], yerr=sem_T[c], marker="o", ms=5, lw=1.8,
                    color=col, capsize=3, alpha=0.9, label=nice(c))
    ax.set_xlabel("temperature (K)")
    ax.set_ylabel("contact frequency  (mean $\\pm$ s.e.m. over salt runs)")
    ax.set_xticks(Ts.astype(int)); ax.set_ylim(-0.05, 1.05)
    ax.text(0.0, 1.03, "a", transform=ax.transAxes, fontsize=18, fontweight="bold",
            va="bottom", ha="left")
    h, l = ax.get_legend_handles_labels()
    ax.legend(h, l, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.16),
              frameon=False, title="weakens with heat (orange)        strengthens with heat (purple)",
              title_fontsize=11)

    img_path = config.OUTPUTS / "figures" / "temperature_structure.png"
    if img_path.exists():
        img = mpimg.imread(img_path)
        g = img[..., :3].mean(2) if img.ndim == 3 else img
        rr = np.where((g < 0.97).any(1))[0]; cc = np.where((g < 0.97).any(0))[0]
        if len(rr) and len(cc):
            p = 12
            img = img[max(rr[0]-p, 0):rr[-1]+p, max(cc[0]-p, 0):cc[-1]+p]
        axs.imshow(img)
    axs.text(0.0, 1.0, "b", transform=axs.transAxes, fontsize=18, fontweight="bold",
             va="bottom", ha="left")
    axs.axis("off")
    # domain labels below the structure with leader lines (avoid bead overlap).
    # targets are axes-fraction positions of the clusters in the render.
    arrows = [
        ("ankyrin / pre-S1", (0.30, 0.52), (0.24, -0.05)),
        ("TRP helix / C-term", (0.66, 0.45), (0.74, -0.05)),
    ]
    for txt, xy, xytext in arrows:
        axs.annotate(txt, xy=xy, xytext=xytext, xycoords="axes fraction",
                     textcoords="axes fraction", fontsize=12.5, ha="center", va="top",
                     arrowprops=dict(arrowstyle="-", color="0.35", lw=1.0))

    out = config.OUTPUTS / "figures" / "temperature_figure.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    print(f"saved {out}")

    # residues for the PyMOL structure (chain A)
    pr = re.compile(r"[A-Z]:[A-Z0-9]+:(\d+)-[A-Z]:[A-Z0-9]+:(\d+)")
    res = set()
    for c in top:
        m = pr.match(c)
        if m:
            res.update([int(m.group(1)), int(m.group(2))])
    print("TSENS_RESIDUES =", "+".join(map(str, sorted(res))))
    print(f"melt={len(melt)}, form={len(form)}; curves melt={[nice(c) for c in melt_show]}, form={[nice(c) for c in form_show]}")


if __name__ == "__main__":
    main()
