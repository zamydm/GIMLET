"""
Run salt-stratified ChACRA (one temperature-PCA per salt level) and save:
  - outputs/chacras/stratified/pc1_loadings_aligned.csv
  - outputs/chacras/stratified/residue_Tsensitivity.csv
  - outputs/chacras/stratified/summary.csv
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_root))
sys.path.insert(0, str(_root / "ChACRA"))   # vendored chacra package

from src import chacra_stratified, config


def main():
    out = config.OUTPUTS / "chacras" / "stratified"
    out.mkdir(parents=True, exist_ok=True)

    res = chacra_stratified.run(n_permutations=1000, n_jobs=4)

    # Per-slice summary
    summary = pd.DataFrame({
        salt: {
            "pc1_var": r["pc1_var"],
            "pc1_r2T": r["pc1_r2T"],
            "pc1_slope": r["pc1_slope"],
            "n_contacts": r["loadings"].shape[0],
            "top_chacras": str(getattr(r["cpca"], "top_chacras", None)),
        }
        for salt, r in res.items()
    }).T
    summary.index.name = "salt_mM"
    summary.to_csv(out / "summary.csv")
    print("\n=== per-salt summary ===")
    print(summary)

    # Aligned PC1 loadings across salts
    pc1 = chacra_stratified.aligned_pc1_loadings(res, pc=1)
    pc1.to_csv(out / "pc1_loadings_aligned.csv")
    print(f"\nAligned PC1 loadings: {pc1.shape[0]} contacts × {pc1.shape[1]} salts")

    # Residue temperature-sensitivity per salt
    res_sens = chacra_stratified.residue_sensitivity(res, pc=1, agg="max")
    res_sens.to_csv(out / "residue_Tsensitivity.csv")
    print(f"Residue T-sensitivity: {res_sens.shape[0]} residues × {res_sens.shape[1]} salts")

    # Save full loadings per salt for figure scripts
    for salt_mM, r in res.items():
        r["loadings"].to_csv(out / f"loadings_{salt_mM}mM.csv")
        proj = pd.Series(r["pc1_proj"], index=r["temps"], name="PC1_proj")
        proj.to_csv(out / f"pc1_proj_{salt_mM}mM.csv")

    print("\nSaved stratified outputs to", out)


if __name__ == "__main__":
    main()
