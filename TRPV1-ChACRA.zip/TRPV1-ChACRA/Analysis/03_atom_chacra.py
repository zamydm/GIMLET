"""
Run 2D-ChACRA on the atomistic (T, salt) grid and write all artifacts:
  - outputs/matrices/atom_freqs.parquet
  - outputs/chacras/atom_scores.csv, atom_loadings.csv, atom_decomp.csv
  - outputs/figures/atom_pc_grid.png, atom_decomp.png, atom_top_loadings_PC{1..4}.png
  - outputs/pymol/atom_top_chacras.pml  (for visual inspection on the
    8GFA structure)
"""
from __future__ import annotations

import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_root))
sys.path.insert(0, str(_root / "ChACRA"))   # vendored chacra package

from src import chacra2d, conditions, config, frequencies, plot


def main():
    conds = conditions.discover("atom")
    if not conds:
        sys.exit("No atomistic states with completed contact frequencies.")

    df = frequencies.build_matrix(conds, resolution="atom", symmetry_average=True)
    frequencies.save_matrix(df, "atom_freqs_symavg")
    print(f"[matrix] {df.shape[0]} states × {df.shape[1]} C4-symmetry-averaged contacts")

    res = chacra2d.run(df, n_permutations=1000, n_jobs=4, r2_thresh=0.5)
    out = config.OUTPUTS / "chacras"
    out.mkdir(parents=True, exist_ok=True)
    res["scores"].to_csv(out / "atom_scores.csv")
    res["loadings"].to_csv(out / "atom_loadings.csv")
    res["decomp"].to_csv(out / "atom_decomp.csv")
    print(res["decomp"])

    fig_dir = config.OUTPUTS / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    pcs = [f"PC{i+1}" for i in range(min(4, res["scores"].shape[1]))]
    plot.plot_pc_grid(res["scores"], pcs=pcs).savefig(fig_dir / "atom_pc_grid.png", dpi=160)
    plot.plot_decomp_bars(res["decomp"]).savefig(fig_dir / "atom_decomp.png", dpi=160)
    for pc in pcs:
        plot.plot_top_loadings(res["loadings"], pc=pc).savefig(
            fig_dir / f"atom_top_loadings_{pc}.png", dpi=160)

    # PyMOL projection of top chacras onto the 8GFA structure
    try:
        from chacra.visualize.pymol import to_pymol
        cpca = res["cf"].cpca
        if config.REF_PDB.exists():
            cpca.structure = str(config.REF_PDB)
            to_pymol(
                freqs=res["cf"].freqs, contactPCA=cpca,
                output_file=str(config.OUTPUTS / "pymol" / "atom_top_chacras.pml"),
            )
            print(f"[pymol] {config.OUTPUTS/'pymol'/'atom_top_chacras.pml'}")
    except Exception as e:
        print(f"[pymol] skipped: {e}")


if __name__ == "__main__":
    main()
