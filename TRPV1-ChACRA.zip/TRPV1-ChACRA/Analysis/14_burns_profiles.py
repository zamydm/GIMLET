"""
Burns-style ChACRA mode profiles: PC projections vs temperature.

Matches the presentation in Burns et al. (the chacra `plot_chacras` style) —
top PCs as smoothed colored lines of projection vs temperature, using the
standard chacra color scheme (PC1 red, PC2 blue, PC3 green, PC4 purple…).

Our grid is 2D (T, salt); to render the 1D temperature profile the way the
HREMD ChACRA papers do, we average each PC's projection over the 3 salt
levels at every temperature.  Actual (salt-averaged) points are shown as
markers; the spline is for visual continuity only.
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.interpolate import make_interp_spline

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config

CHACRA_COLORS = ["#ff0000", "#00bfff", "#00b730", "#7400ff", "#ff831d", "#ff00ff"]

mpl.rcParams.update({"font.family": "sans-serif", "font.size": 10,
                     "axes.spines.top": False, "axes.spines.right": False})


def panel(ax, scores_csv, decomp_csv, title, n_pcs=4):
    s = pd.read_csv(scores_csv, index_col=[0, 1])
    dec = pd.read_csv(decomp_csv, index_col=0)
    s.index = pd.MultiIndex.from_tuples(s.index, names=["T", "salt"])
    Tmean = s.groupby("T").mean().sort_index()
    Ts = Tmean.index.to_numpy(dtype=float)
    Xs = np.linspace(Ts.min(), Ts.max(), 300)

    for pc in range(1, n_pcs + 1):
        y = Tmean[f"PC{pc}"].to_numpy()
        # straight segments between the actual salt-averaged points (honest:
        # no spline fabrication — 6 points are too few to spline cleanly)
        ax.plot(Ts, y, "-o", color=CHACRA_COLORS[pc - 1], lw=1.8, ms=5,
                markeredgecolor="white", markeredgewidth=0.5, zorder=3,
                label=f"PC{pc} ({dec.loc[pc,'label']})")

    ax.axhline(0, color="grey", lw=0.5, ls=":")
    ax.set_xlabel("temperature (K)")
    ax.set_ylabel("PC projection (mean over salt)")
    ax.set_title(title, fontsize=11, fontweight="bold", loc="left")
    ax.set_xticks(Ts.astype(int))
    ax.legend(fontsize=8, loc="upper right", ncol=1, frameon=False,
              handlelength=1.4, bbox_to_anchor=(1.0, 1.0))


def main():
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.6))
    fig.subplots_adjust(left=0.07, right=0.985, top=0.83, bottom=0.13, wspace=0.22)

    panel(axes[0], config.OUTPUTS / "chacras/cg_scores.csv",
          config.OUTPUTS / "chacras/cg_decomp.csv",
          "(a)  coarse-grained  (Martini, 4 µs)")
    panel(axes[1], config.OUTPUTS / "chacras/atom_scores.csv",
          config.OUTPUTS / "chacras/atom_decomp.csv",
          "(b)  atomistic  (400 ns)")

    fig.suptitle("TRPV1 ChACRA modes — PC projections vs temperature",
                 fontsize=12.5, fontweight="bold", x=0.07, ha="left", y=0.96)
    fig.text(0.07, 0.88, "PC1 = red, PC2 = blue, PC3 = green, PC4 = purple "
             "(chacra convention). Each point = salt-averaged projection at that T "
             "(straight segments, no smoothing).",
             fontsize=8.5, color="#555555")

    out = config.OUTPUTS / "figures" / "burns_profiles.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    print(f"saved {out}")


if __name__ == "__main__":
    main()
