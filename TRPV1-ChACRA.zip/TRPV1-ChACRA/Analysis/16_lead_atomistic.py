"""
Atomistic-only lead ChACRA figure for the main text.

(a) atomistic mode spectrum — contact-frequency PCs classified as salt-,
    temperature-, or coupled-responsive (variance-weighted).
(b) the mode-driving residues mapped onto the TRPV1 gating machinery.

Atomistic is the resolution that resolves the transmembrane gate (the CG
elastic network restrains that bundle), so the gating story is told here.
Single-trajectory-per-condition caveat stated in the caption.

Fonts are sized for a 2-column main-text figure (base ~14 pt).
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpec

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config

# Larger fonts for print/main-text legibility
mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 14,
    "axes.titlesize": 16,
    "axes.labelsize": 15,
    "xtick.labelsize": 13,
    "ytick.labelsize": 13,
    "legend.fontsize": 13,
    "axes.spines.top": False,
    "axes.spines.right": False,
})

C = {"T": "#2166ac", "salt": "#b2182b", "coupled": "#762a83", "neither": "#bdbdbd"}
NICE = {"T": "temperature", "salt": "salt", "coupled": "coupled", "neither": "—"}


def main():
    at = pd.read_csv(config.OUTPUTS / "chacras/atom_decomp.csv", index_col=0)

    fig = plt.figure(figsize=(13.5, 6.2))
    gs = GridSpec(1, 2, width_ratios=[1.0, 1.15],
                  left=0.075, right=0.985, top=0.90, bottom=0.16, wspace=0.12)
    ax = fig.add_subplot(gs[0, 0])
    ax_st = fig.add_subplot(gs[0, 1])

    # ── (a) spectrum — colored by temperature vs salt character ─────────
    n = 7
    d = at.iloc[:n]
    y = np.arange(len(d))[::-1]
    var = d["var_explained"].to_numpy() * 100
    r2T = d["r2_T_marginal"].to_numpy()
    r2S = d["r2_salt_marginal"].to_numpy()
    diff = r2T - r2S                      # >0 temperature-leaning, <0 salt
    sig = np.maximum(r2T, r2S) >= 0.5     # a mode "responds" if either ≥ 0.5

    cmap = plt.cm.RdBu                     # 0 = red (salt), 1 = blue (T)
    colors = []
    for s, dd in zip(sig, diff):
        if not s:
            colors.append("#cfcfcf")       # neither — grey
        else:
            colors.append(cmap((np.clip(dd, -0.5, 0.5) + 0.5)))
    ax.barh(y, var, color=colors, edgecolor="black", linewidth=0.6, height=0.74)

    for yi, pc, v, t, sa, s in zip(y, d.index, var, r2T, r2S, sig):
        tag = "neither" if not s else ("temperature" if (t - sa) > 0 else "salt")
        ax.text(v + 0.3, yi,
                f"PC{pc}  ·  {tag}    (R²$_T$={t:.2f}, R²$_S$={sa:.2f})",
                va="center", fontsize=12, fontweight="normal")
    ax.set_yticks([])
    ax.set_xlabel("variance explained (%)")
    ax.set_xlim(0, max(var) * 2.3)
    ax.set_title("(a)  contact-frequency modes", fontweight="bold", loc="left")

    # colorbar legend: salt ↔ temperature
    import matplotlib.cm as cm
    from matplotlib.colors import Normalize
    sm = cm.ScalarMappable(cmap=cmap, norm=Normalize(-0.5, 0.5))
    cbar = fig.colorbar(sm, ax=ax, orientation="horizontal", fraction=0.05,
                        pad=0.16, aspect=28)
    cbar.set_ticks([-0.5, 0, 0.5])
    cbar.set_ticklabels(["salt", "balanced", "temperature"])
    cbar.set_label("mode character   (R²$_T$ − R²$_{salt}$)", fontsize=11.5)

    # ── (b) structure ───────────────────────────────────────────────────
    img_path = config.OUTPUTS / "figures" / "lead_structure.png"
    if img_path.exists():
        img = mpimg.imread(img_path)
        gray = img[..., :3].mean(2) if img.ndim == 3 else img
        rows = np.where((gray < 0.97).any(1))[0]
        cols = np.where((gray < 0.97).any(0))[0]
        if len(rows) and len(cols):
            p = 15
            img = img[max(rows[0]-p, 0):rows[-1]+p, max(cols[0]-p, 0):cols[-1]+p]
        ax_st.imshow(img)
    ax_st.axis("off")
    ax_st.set_title("(b)  modes localize to the S5/S6 gate + pore mouth",
                    fontweight="bold", loc="left")

    out = config.OUTPUTS / "figures" / "lead_atomistic.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    print(f"saved {out}")


if __name__ == "__main__":
    main()
