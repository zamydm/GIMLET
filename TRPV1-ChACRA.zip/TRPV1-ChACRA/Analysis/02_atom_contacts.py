"""
Per-state atomistic contact frequencies.

Two backends:
  --backend mda           pure-MDAnalysis distance cutoff (default; no install)
  --backend getcontacts   atom-typed contacts via the chacra-env getcontacts CLI

Run with:
    python -m analysis.02_atom_contacts --backend mda --stride 5
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import conditions, contacts, distance_contacts, config


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", choices=["mda", "getcontacts"], default="mda")
    ap.add_argument("--stride", type=int, default=5,
                    help="Frame stride (20001 frames at 20 ps → stride 5 = 100 ps eff.)")
    ap.add_argument("--drop_ns", type=float, default=50.0)
    ap.add_argument("--cutoff", type=float, default=4.5,
                    help="Heavy-atom distance cutoff in Å (mda backend only)")
    ap.add_argument("--jobs", type=int, default=8,
                    help="--cores for get-dynamic-contacts (getcontacts backend)")
    ap.add_argument("--only", nargs="*", default=None)
    args = ap.parse_args()

    todo = conditions.discover("atom")
    if args.only:
        todo = [c for c in todo if c.label in set(args.only)]
    if not todo:
        sys.exit("No atomistic states found on disk.")

    print(f"[plan] {len(todo)} state(s), backend={args.backend}, "
          f"stride={args.stride}, drop_ns={args.drop_ns}", flush=True)

    for c in todo:
        out = config.OUTPUTS / "freqs" / "atom" / f"freqs_{c.label}.tsv"
        if out.exists():
            print(f"[skip] {c.label} — {out}")
            continue
        print(f"[run ] {c.label}", flush=True)
        if args.backend == "mda":
            distance_contacts.write_state_freqs_atom(
                c, stride=args.stride, drop_ns=args.drop_ns, cutoff_A=args.cutoff,
            )
        else:
            contacts.process_state(
                c, stride=args.stride, drop_ns=args.drop_ns, n_jobs=args.jobs,
            )


if __name__ == "__main__":
    main()
