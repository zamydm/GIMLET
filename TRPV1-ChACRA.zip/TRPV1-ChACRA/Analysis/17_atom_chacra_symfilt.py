"""
Re-run atomistic ChACRA on C4-symmetry-filtered contacts.

Single-trajectory straight-MD traps subunits in different basins, breaking
the C4 symmetry of the tetramer and injecting artifacts into the top
contacts (e.g. R617-D655, which forms in only 1 of 4 symmetric interfaces).
Here we keep only contacts whose symmetric copies are mutually consistent
(``symmetry_filter``), then run the same PCA + 2D decomposition.

Works from the local freq files only (no SMB volume needed).

Outputs (suffix _symfilt):
  outputs/chacras/atom_decomp_symfilt.csv
  outputs/chacras/atom_loadings_symfilt.csv
  outputs/chacras/atom_scores_symfilt.csv
  outputs/matrices/atom_freqs_symfilt.parquet
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_root))
sys.path.insert(0, str(_root / "ChACRA"))

from src.conditions import Condition
from src import frequencies, symmetry_filter, chacra2d, config

MIN_CONSISTENCY = 0.5


def main():
    conds = [Condition(T=int(f.stem[6:9]), salt_code=f.stem[10:12], resolution="atom")
             for f in sorted((config.OUTPUTS / "freqs/atom").glob("freqs_*.tsv"))]
    raw = frequencies.build_matrix(conds, resolution="atom", symmetry_average=False)
    print(f"[raw] {raw.shape[0]} states x {raw.shape[1]} raw contacts")

    avg, scores = symmetry_filter.filtered_average(raw, min_consistency=MIN_CONSISTENCY)
    n_total = scores["consistency"].notna().sum()
    n_keep = avg.shape[1]
    print(f"[filter] kept {n_keep}/{n_total} symmetry-consistent contacts "
          f"(consistency >= {MIN_CONSISTENCY}); dropped {n_total - n_keep} artifacts")

    frequencies.save_matrix(avg, "atom_freqs_symfilt")
    scores.to_csv(config.OUTPUTS / "chacras/atom_symmetry_scores.csv")

    res = chacra2d.run(avg, n_permutations=1000, n_jobs=4, r2_thresh=0.5)
    out = config.OUTPUTS / "chacras"
    res["scores"].to_csv(out / "atom_scores_symfilt.csv")
    res["loadings"].to_csv(out / "atom_loadings_symfilt.csv")
    res["decomp"].to_csv(out / "atom_decomp_symfilt.csv")

    print("\n=== symmetry-filtered decomposition (top 7) ===")
    print(res["decomp"][["var_explained", "r2_T_marginal", "r2_salt_marginal", "label"]]
          .head(7).round(3))

    print("\n=== top 6 loadings per significant PC ===")
    L = res["loadings"]
    for pc in [1, 2, 3, 4]:
        col = f"PC{pc}"
        if col not in L.columns:
            continue
        lab = res["decomp"].loc[pc, "label"]
        top = L[col].abs().sort_values(ascending=False).head(6)
        print(f"\nPC{pc} ({lab}):")
        for c in top.index:
            print(f"   {L.loc[c, col]:+.3f}  {c}")


if __name__ == "__main__":
    main()
