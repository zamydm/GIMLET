"""
Combined contact-analysis figure (temperature-forward), 3 panels:
  (a) symmetry-filtered ChACRA mode spectrum (salt modes dominate, one
      temperature mode), bars coloured by mode character.
  (b) temperature-mode contact-frequency curves vs temperature, melt/form,
      with SEM over the three salt runs.
  (c) the temperature-sensitive residues on the structure, localized to the
      cytoplasmic coupling apparatus.

Colour logic:
  panel a  red = salt mode, blue = temperature mode, grey = neither
  panels b,c  orange = weakens with heat, purple = strengthens with heat
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.cm as cm
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import Normalize
from matplotlib.gridspec import GridSpec

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.conditions import Condition
from src import frequencies, symmetry_filter as sf, config

mpl.rcParams.update({
    "font.family": "sans-serif", "font.size": 13.5, "axes.titlesize": 15,
    "axes.labelsize": 14, "xtick.labelsize": 12.5, "ytick.labelsize": 12.5,
    "legend.fontsize": 10.5, "axes.spines.top": False, "axes.spines.right": False,
})

C_NEITHER = "#cfcfcf"
C_MELT, C_FORM = "#e08214", "#8073ac"
ONE = {"ARG": "R", "LYS": "K", "ASP": "D", "GLU": "E", "TYR": "Y", "SER": "S",
       "THR": "T", "LEU": "L", "VAL": "V", "PHE": "F", "ALA": "A", "GLY": "G",
       "ILE": "I", "MET": "M", "CYS": "C", "ASN": "N", "GLN": "Q", "PRO": "P",
       "TRP": "W", "HSD": "H", "HIS": "H"}


def nice(c):
    return "-".join(f"{ONE.get(rn, rn)}{ri}" for rn, ri in re.findall(r"[A-Z]:([A-Z]+):(\d+)", c))


def main():
    dec = pd.read_csv(config.OUTPUTS / "chacras/atom_decomp_symfilt.csv", index_col=0)
    L = pd.read_csv(config.OUTPUTS / "chacras/atom_loadings_symfilt.csv", index_col=0)

    # curve data
    conds = [Condition(T=int(f.stem[6:9]), salt_code=f.stem[10:12], resolution="atom")
             for f in sorted((config.OUTPUTS / "freqs/atom").glob("freqs_*.tsv"))]
    raw = frequencies.build_matrix(conds, resolution="atom", symmetry_average=False)
    avg, _ = sf.filtered_average(raw, min_consistency=0.5)
    avg.index = pd.MultiIndex.from_tuples(avg.index, names=["T", "salt"])
    Ts = np.array(sorted(avg.index.get_level_values("T").unique()), dtype=float)
    mean_T = avg.groupby("T").mean()
    sem_T = avg.groupby("T").std() / np.sqrt(avg.groupby("T").count().clip(lower=1))

    melt_show = ["A:SER:367-A:ARG:740", "A:GLY:730-A:ASP:738", "A:TYR:731-A:LYS:736"]
    form_show = ["A:LEU:354-A:LYS:369", "A:ASP:297-A:THR:303", "A:GLU:327-A:ARG:368"]

    fig = plt.figure(figsize=(17.0, 5.9))
    gs = GridSpec(1, 3, width_ratios=[1.08, 1.0, 1.15],
                  left=0.045, right=0.995, top=0.92, bottom=0.26, wspace=0.26)
    axa = fig.add_subplot(gs[0, 0])
    axb = fig.add_subplot(gs[0, 1])
    axc = fig.add_subplot(gs[0, 2])

    # ---- (a) mode spectrum ----
    n = 6
    d = dec.iloc[:n]
    y = np.arange(len(d))[::-1]
    var = d["var_explained"].to_numpy() * 100
    r2T = d["r2_T_marginal"].to_numpy(); r2S = d["r2_salt_marginal"].to_numpy()
    sig = np.maximum(r2T, r2S) >= 0.5
    cmap = plt.cm.RdBu
    colors = [C_NEITHER if not s else cmap(np.clip(t - sa, -0.5, 0.5) + 0.5)
              for s, t, sa in zip(sig, r2T, r2S)]
    axa.barh(y, var, color=colors, edgecolor="black", linewidth=0.6, height=0.74)
    for yi, pc, v, t, sa, s in zip(y, d.index, var, r2T, r2S, sig):
        tag = "neither" if not s else ("temperature" if (t - sa) > 0 else "salt")
        axa.text(v + 0.25, yi, f"PC{pc} · {tag}", va="center", fontsize=11.5,
                 fontweight="bold" if (s and (t - sa) > 0) else "normal")
    axa.set_yticks([]); axa.set_xlabel("variance explained (%)")
    axa.set_xlim(0, max(var) * 1.85)
    axa.text(0.0, 1.04, "a", transform=axa.transAxes, fontsize=18, fontweight="bold",
             va="bottom", ha="left")
    handles = [mpl.patches.Patch(color=cmap(0.95), label="temperature mode"),
               mpl.patches.Patch(color=cmap(0.05), label="salt mode"),
               mpl.patches.Patch(color=C_NEITHER, label="neither")]
    axa.legend(handles=handles, loc="lower right", frameon=False, fontsize=10.5)

    # ---- (b) temperature curves ----
    for c in melt_show + form_show:
        col = C_MELT if c in melt_show else C_FORM
        axb.errorbar(Ts, mean_T[c], yerr=sem_T[c], marker="o", ms=5, lw=1.8,
                     color=col, capsize=3, alpha=0.9, label=nice(c))
    axb.set_xlabel("temperature (K)")
    axb.set_ylabel("contact frequency  (mean $\\pm$ s.e.m. over salts)")
    axb.set_xticks(Ts.astype(int)); axb.set_ylim(-0.05, 1.05)
    axb.text(0.0, 1.04, "b", transform=axb.transAxes, fontsize=18, fontweight="bold",
             va="bottom", ha="left")
    hh, ll = axb.get_legend_handles_labels()
    axb.legend(hh, ll, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.17),
               frameon=False, title="weakens with heat (orange)        strengthens with heat (purple)",
               title_fontsize=11)

    # ---- (c) structure ----
    img_path = config.OUTPUTS / "figures" / "temperature_structure.png"
    if img_path.exists():
        img = mpimg.imread(img_path)
        g = img[..., :3].mean(2) if img.ndim == 3 else img
        rr = np.where((g < 0.97).any(1))[0]; cc = np.where((g < 0.97).any(0))[0]
        if len(rr) and len(cc):
            p = 10
            img = img[max(rr[0]-p, 0):rr[-1]+p, max(cc[0]-p, 0):cc[-1]+p]
        axc.imshow(img)
    axc.text(0.0, 1.0, "c", transform=axc.transAxes, fontsize=18, fontweight="bold",
             va="bottom", ha="left")
    axc.axis("off")
    for txt, xy, xytext in [("ankyrin / pre-S1", (0.30, 0.52), (0.24, -0.05)),
                            ("TRP helix / C-term", (0.66, 0.45), (0.74, -0.05))]:
        axc.annotate(txt, xy=xy, xytext=xytext, xycoords="axes fraction",
                     textcoords="axes fraction", fontsize=12.5, ha="center", va="top",
                     arrowprops=dict(arrowstyle="-", color="0.35", lw=1.0))

    out = config.OUTPUTS / "figures" / "ChACRA_combined.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    print(f"saved {out}")


if __name__ == "__main__":
    main()
