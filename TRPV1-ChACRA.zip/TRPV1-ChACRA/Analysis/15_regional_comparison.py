"""
WARNING (2026-09-08): this script bins CG residues WITHOUT the +198 offset
(CG freq files are numbered 1-556; TYR1 == TYR199 of 8GFA). Its regional
comparison and outputs/figures/regional_comparison.png are therefore wrong.
Use analysis/21_cg_chacra_symfilt.py + materials/reconcile_notes.md instead.

Cross-resolution regional responsiveness comparison.

For each TRPV1 structural region, the fraction of total ChACRA
responsiveness (variance-weighted |loading| summed over significant PCs)
contributed by residues in that region, for CG and atomistic.

Honest cross-resolution read:
  - both flag the ANK/N-terminal cytoplasmic domain (genuine agreement)
  - the TM gating region (S5/pore/S6/TRP) is atomistic-only — the CG
    backbone elastic network restrains that bundle, silencing it.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config

mpl.rcParams.update({"font.family": "sans-serif", "font.size": 10,
                     "axes.spines.top": False, "axes.spines.right": False})

DOMAINS = [(110, 360, "ANK / N-term"), (360, 430, "pre-S1"), (430, 470, "S1–S2"),
           (470, 510, "S2–S3"), (510, 545, "S3–S4"), (545, 575, "S4–S5 linker"),
           (575, 600, "S5"), (600, 640, "pore / SF"), (640, 690, "S6 / gate"),
           (690, 760, "TRP / C-term")]
TM = {"S5", "pore / SF", "S6 / gate", "S4–S5 linker", "TRP / C-term"}


def dom(ri):
    for lo, hi, nm in DOMAINS:
        if lo <= ri < hi:
            return nm
    return "other"


def region_profile(loadings_csv, decomp_csv, n_sig=8):
    L = pd.read_csv(loadings_csv, index_col=0)
    dec = pd.read_csv(decomp_csv, index_col=0)
    pat = re.compile(r"[A-Z]:[A-Z0-9]+:(\d+)-[A-Z]:[A-Z0-9]+:(\d+)")
    reg = {nm: 0.0 for _, _, nm in DOMAINS}
    for pc in range(1, n_sig + 1):
        col = f"PC{pc}"
        if col not in L.columns:
            continue
        w = dec.loc[pc, "var_explained"]
        for c, v in (L[col].abs() * w).items():
            m = pat.match(c)
            if not m:
                continue
            for ri in (int(m.group(1)), int(m.group(2))):
                d = dom(ri)
                if d in reg:
                    reg[d] += v
    s = pd.Series(reg)
    return s / s.sum()


def main():
    cg = region_profile(config.OUTPUTS / "chacras/cg_loadings.csv",
                        config.OUTPUTS / "chacras/cg_decomp.csv") * 100
    at = region_profile(config.OUTPUTS / "chacras/atom_loadings.csv",
                        config.OUTPUTS / "chacras/atom_decomp.csv") * 100
    order = [nm for _, _, nm in DOMAINS]
    y = np.arange(len(order))[::-1]

    fig, ax = plt.subplots(figsize=(8.5, 5.6))
    fig.subplots_adjust(left=0.20, right=0.96, top=0.84, bottom=0.10)
    h = 0.38
    ax.barh(y + h/2, at[order], height=h, color="#2166ac", label="atomistic (400 ns)")
    ax.barh(y - h/2, cg[order], height=h, color="#b2182b", label="CG (Martini, 4 µs)")

    ax.set_yticks(y)
    ax.set_yticklabels(order)
    # shade TM rows
    for yi, nm in zip(y, order):
        if nm in TM:
            ax.axhspan(yi - 0.5, yi + 0.5, color="#fff3cd", zorder=0)
    ax.set_xlabel("share of ChACRA responsiveness (%)")
    ax.legend(loc="lower right", frameon=False, fontsize=9)

    ax.set_title("Where each resolution sees TRPV1's perturbation-responsive contacts",
                 fontsize=11.5, fontweight="bold", loc="left")
    fig.text(0.20, 0.90,
             "Shared: ANK/N-term cytoplasmic domain.  "
             "Divergent: TM gating (shaded) is atomistic-only — the CG elastic "
             "network restrains the TM bundle.",
             fontsize=8.8, color="#555555")
    # annotate the EN-silenced zone
    ax.text(0.5, y[order.index("pore / SF")], "CG ≈ 0 across TM\n(elastic-network restrained)",
            fontsize=8.5, color="#b2182b", style="italic", va="center")

    out = config.OUTPUTS / "figures" / "regional_comparison.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    print(f"saved {out}")


if __name__ == "__main__":
    main()
