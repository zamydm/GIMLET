"""
Single summary figure for the atomistic 2D-ChACRA results.

Layout (2 × 4):
  top row    — PC scores vs T, one line per salt level, for 4 chosen PCs
               (PC2 = canonical T-melting, PC1/PC5/PC4 = three structurally
               distinct salt-modes).
  bottom row — raw contact-frequency curves vs T for the dominant top-loaded
               residue pair of each PC (R617–D655, V595–W616, L598–H614,
               Y454–T612).  Same one-line-per-salt convention.

The top row shows the modes, the bottom row shows the biology.
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import config, frequencies

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 9,
    "axes.titlesize": 9.5,
    "axes.labelsize": 9,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "axes.spines.top": False,
    "axes.spines.right": False,
})

LABEL_COLORS = {
    "T":        "#1f77b4",
    "salt":     "#d62728",
    "coupled":  "#7d3ce8",
    "neither":  "#bbbbbb",
}

# Salt-level colors (sequential): low salt = light blue, high = deep red-purple
SALT_COLORS = {50: "#3b82c4", 100: "#9b59b6", 150: "#c0392b"}


def _by_T(s: pd.Series) -> pd.DataFrame:
    """MultiIndex (T_K, salt_mM) → DataFrame indexed by T, cols by salt."""
    s = s.copy()
    s.index = pd.MultiIndex.from_tuples(s.index, names=["T_K", "salt_mM"])
    return s.unstack("salt_mM").sort_index()


def _arrow(slope: float, thresh: float) -> str:
    return "↑" if slope > thresh else ("↓" if slope < -thresh else "·")


def main():
    decomp = pd.read_csv(config.OUTPUTS / "chacras/atom_decomp.csv", index_col=0)
    scores = pd.read_csv(config.OUTPUTS / "chacras/atom_scores.csv",
                         index_col=[0, 1])
    freqs = frequencies.load_matrix("atom_freqs_symavg")

    # (PC, contact-name, contact-display-label, sketch).  The contact
    # shown is the highest-|loading| pair on that PC.
    pc_picks = [
        (2, "A:THR:597-A:GLY:618", "T597–G618",        "S5/S6 melting"),
        (1, "A:ARG:617-B:ASP:655", "R617–D655 (A↔B)", "salt bridge"),
        (5, "A:LEU:598-A:HSD:614", "L598–H614",        "H614 cluster"),
        (4, "A:TYR:454-B:THR:612", "Y454–T612 (A↔B)", "S2–pore"),
    ]

    # Sign thresholds (re-derived inside the figure)
    bT = decomp["b_T"].iloc[:8].to_numpy()
    bS = decomp["b_salt"].iloc[:8].to_numpy()
    t_thresh = max(np.median(np.abs(bT)), 0.02)
    s_thresh = max(np.median(np.abs(bS)), 0.003)

    fig, axes = plt.subplots(
        2, 4, figsize=(13.0, 7.0),
        sharex=True, sharey="row",
        gridspec_kw=dict(hspace=0.42, wspace=0.18,
                         left=0.07, right=0.985, top=0.87, bottom=0.20),
    )

    # ── top row: PC scores vs T ────────────────────────────────────────
    pc_score_ax = axes[0]
    for ax, (pc, _contact, _clabel, sketch) in zip(pc_score_ax, pc_picks):
        s = _by_T(scores[f"PC{pc}"])
        for salt in s.columns:
            ax.plot(s.index, s[salt], marker="o", linewidth=1.6,
                    markersize=4, color=SALT_COLORS[salt],
                    label=f"{salt} mM")
        ax.axhline(0, color="gray", linewidth=0.5, linestyle=":")
        # title encodes everything: PC#, label, % var, T/S arrows
        lbl = decomp.loc[pc, "label"]
        v = decomp.loc[pc, "var_explained"] * 100
        tA = _arrow(decomp.loc[pc, "b_T"],    t_thresh)
        sA = _arrow(decomp.loc[pc, "b_salt"], s_thresh)
        ax.set_title(
            f"PC{pc}  {lbl}  ({v:.1f}%)   T{tA}  S{sA}\n{sketch}",
            color=LABEL_COLORS.get(lbl, "black"),
            fontsize=9.5, pad=4, fontweight="bold",
        )
        for spine in ax.spines.values():
            spine.set_edgecolor(LABEL_COLORS.get(lbl, "black"))
            spine.set_linewidth(1.0)
    pc_score_ax[0].set_ylabel("PC score (state\nprojection on mode)")
    pc_score_ax[0].legend(title="[salt]", fontsize=7.5, title_fontsize=7.5,
                           loc="best", frameon=False)

    # ── bottom row: contact-frequency vs T ──────────────────────────────
    contact_ax = axes[1]
    for ax, (pc, contact, clabel, _sketch) in zip(contact_ax, pc_picks):
        if contact not in freqs.columns:
            ax.text(0.5, 0.5, f"missing\n{contact}", transform=ax.transAxes,
                    ha="center", va="center")
            continue
        f = _by_T(freqs[contact])
        for salt in f.columns:
            ax.plot(f.index, f[salt], marker="s", linewidth=1.6,
                    markersize=4, color=SALT_COLORS[salt],
                    label=f"{salt} mM")
        ax.set_xlabel("T (K)")
        ax.set_ylim(0, 1.05)
        ax.set_title(clabel, fontsize=9.5, pad=2)

    contact_ax[0].set_ylabel("contact frequency\n(C4 symmetry-averaged)")

    # ── headline ───────────────────────────────────────────────────────
    fig.text(
        0.07, 0.965,
        "TRPV1 contact-frequency PCA (atomistic, 6 T × 3 [salt], C4-averaged):"
        "  salt-driven modes dominate the top of the spectrum",
        fontsize=11.5, fontweight="bold",
    )
    fig.text(0.07, 0.925, "(a)  mode scores", fontsize=10, fontweight="bold")
    fig.text(0.07, 0.51,  "(b)  representative contact frequencies"
             "  —  highest-|loading| pair per PC; 0→1 range is the (T, salt) "
             "modulation that makes these contacts principal components",
             fontsize=9.5, fontweight="bold")

    # Mode-color legend at the bottom
    legend_handles = [
        mpl.patches.Patch(color=LABEL_COLORS["T"],       label="T-mode"),
        mpl.patches.Patch(color=LABEL_COLORS["salt"],    label="salt-mode"),
        mpl.patches.Patch(color=LABEL_COLORS["coupled"], label="coupled"),
        mpl.lines.Line2D([], [], marker="o", color=SALT_COLORS[50],
                         linestyle="-", linewidth=1.5, label="50 mM"),
        mpl.lines.Line2D([], [], marker="o", color=SALT_COLORS[100],
                         linestyle="-", linewidth=1.5, label="100 mM"),
        mpl.lines.Line2D([], [], marker="o", color=SALT_COLORS[150],
                         linestyle="-", linewidth=1.5, label="150 mM"),
        mpl.lines.Line2D([], [], marker=r"$\uparrow$", color="black",
                         markersize=10, linestyle="",
                         label="score rises with axis"),
        mpl.lines.Line2D([], [], marker=r"$\downarrow$", color="black",
                         markersize=10, linestyle="",
                         label="score falls with axis"),
    ]
    fig.legend(handles=legend_handles, ncol=8, frameon=False, fontsize=8.5,
               loc="lower center", bbox_to_anchor=(0.5, 0.04))

    out_png = config.OUTPUTS / "figures" / "atom_summary.png"
    out_pdf = config.OUTPUTS / "figures" / "atom_summary.pdf"
    fig.savefig(out_png, dpi=200, bbox_inches="tight")
    fig.savefig(out_pdf, bbox_inches="tight")
    print(f"saved {out_png}")
    print(f"saved {out_pdf}")


if __name__ == "__main__":
    main()
