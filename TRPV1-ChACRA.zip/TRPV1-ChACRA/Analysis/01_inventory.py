"""
Walk DATA_ROOT and report which (T, salt) production runs are on disk for
both atomistic and CG resolutions.  Writes a CSV to outputs/inventory/.

Run from the project root with:
    python -m analysis.01_inventory
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import config, conditions, trajectory_io


def main():
    rows = []
    for res in ("atom", "cg"):
        for c in conditions.discover(res):
            try:
                ti = trajectory_io.info(c)
                rows.append({
                    "resolution": res, "label": c.label,
                    "T_K": c.T, "salt_mM": c.salt_mM,
                    "n_frames": ti.n_frames, "dt_ps": ti.dt_ps,
                    "total_ns": round(ti.total_ns, 2),
                    "n_atoms": ti.n_atoms,
                    "state_dir": str(c.state_dir),
                })
            except Exception as e:   # don't let one bad state nuke the report
                rows.append({
                    "resolution": res, "label": c.label,
                    "T_K": c.T, "salt_mM": c.salt_mM,
                    "error": repr(e),
                    "state_dir": str(c.state_dir),
                })
    df = pd.DataFrame(rows)
    out = config.OUTPUTS / "inventory" / "trajectory_inventory.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(df.to_string())
    print(f"\nWrote {out}")


if __name__ == "__main__":
    main()
