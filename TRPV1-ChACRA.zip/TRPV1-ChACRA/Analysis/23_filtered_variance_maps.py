"""
Filtered contact-variance maps (input for a C4-filtered Figure 4).

For each resolution and salt, computes the variance of every contact's
probability across the six temperatures, using the symmetry-filtered contact
tables that feed Figure 5, and scatters it into residue x residue matrices in
8GFA numbering (199-754), split into intra- and inter-monomer.

Outputs
  outputs/variance_maps/<res>_<salt>mM_intra.csv   556 x 556 matrix, index/columns = residue number
  outputs/variance_maps/<res>_<salt>mM_inter.csv
  outputs/variance_maps/<res>_<salt>mM_contacts.csv  long form: res_i, res_j, intra, var_T
  outputs/variance_maps/preview.png                  quick look, 150 mM, log colour scale

Run:  python analysis/23_filtered_variance_maps.py
Needs only numpy, pandas, pyarrow, matplotlib.
"""
import re
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "outputs" / "variance_maps"
OUT.mkdir(exist_ok=True)

TABLES = {"atom": ("atom_freqs_symfilt.parquet", 0),     # (file, residue offset to 8GFA numbering)
          "cg":   ("cg_freqs_symfilt.parquet",   198)}   # CG topology numbers residues 1-556; TYR1 = TYR199
RES_MIN, RES_MAX = 199, 754
PAT = re.compile(r"([A-Z]):[A-Z0-9]+:(\d+)-([A-Z]):[A-Z0-9]+:(\d+)")   # e.g. A:ARG:557-A:THR:705


def variance_maps(res):
    fname, off = TABLES[res]
    df = pd.read_parquet(ROOT / "outputs" / "matrices" / fname)
    F = df.drop(columns=["T_K", "salt_mM"])
    parsed = [PAT.match(c) for c in F.columns]
    meta = pd.DataFrame({
        "res_i": [int(m.group(2)) + off for m in parsed],
        "res_j": [int(m.group(4)) + off for m in parsed],
        "intra": [m.group(1) == m.group(3) for m in parsed],
    }, index=F.columns)

    n = RES_MAX - RES_MIN + 1
    idx = np.arange(RES_MIN, RES_MAX + 1)
    for salt in sorted(df["salt_mM"].unique()):
        rows = df["salt_mM"] == salt                      # the six temperatures at this salt
        var_T = F[rows].var(axis=0, ddof=0)               # population variance across temperature, per contact
        long = meta.assign(var_T=var_T.values)
        long.to_csv(OUT / f"{res}_{int(salt)}mM_contacts.csv", index_label="contact")
        for kind, sel in (("intra", long["intra"]), ("inter", ~long["intra"])):
            M = np.zeros((n, n))
            sub = long[sel]
            i = sub["res_i"].values - RES_MIN
            j = sub["res_j"].values - RES_MIN
            M[i, j] += sub["var_T"].values
            M[j, i] += sub["var_T"].values                 # symmetric matrix
            pd.DataFrame(M, index=idx, columns=idx).to_csv(OUT / f"{res}_{int(salt)}mM_{kind}.csv")
        print(f"[{res}] {int(salt)} mM: {len(long)} contacts, total var-across-T = {long['var_T'].sum():.3f}, "
              f"intra share = {long.loc[long['intra'], 'var_T'].sum() / long['var_T'].sum():.2f}")


def preview(salt=150):
    fig, axes = plt.subplots(2, 2, figsize=(10, 10))
    for r, res in enumerate(("atom", "cg")):
        for c, kind in enumerate(("intra", "inter")):
            M = pd.read_csv(OUT / f"{res}_{salt}mM_{kind}.csv", index_col=0).values
            ax = axes[r, c]
            im = ax.imshow(np.where(M > 0, M, np.nan), origin="lower", cmap="plasma",
                           norm=LogNorm(vmin=1e-4, vmax=1e-1),
                           extent=[RES_MIN, RES_MAX, RES_MIN, RES_MAX])
            ax.set_title(f"{'atomistic' if res == 'atom' else 'coarse-grained'}, {kind}-monomer, {salt} mM (filtered)")
            ax.set_xlabel("residue"); ax.set_ylabel("residue")
    fig.colorbar(im, ax=axes, shrink=0.6, label="contact probability variance across T")
    fig.savefig(OUT / "preview.png", dpi=150, bbox_inches="tight")
    print("preview ->", OUT / "preview.png")


if __name__ == "__main__":
    for res in TABLES:
        variance_maps(res)
    preview()
