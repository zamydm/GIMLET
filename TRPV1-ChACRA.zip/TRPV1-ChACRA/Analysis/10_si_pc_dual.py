"""
SI figure: R²-quadrant classification of TRPV1 chacras.

One panel, two axes:
  x  =  R²_T_marginal     (PC vs T after averaging over salt)
  y  =  R²_salt_marginal  (PC vs [salt] after averaging over T)

Each top PC = one labeled dot, sized by variance explained, coloured by
classification.  Quadrant boundaries at the 0.5 marginal-R² threshold
partition the plane into:

  bottom-left   →  neither (the linear marginals explain ≤ 0.5 of variance)
  bottom-right  →  T-mode
  top-left      →  salt-mode
  top-right     →  coupled

This is the entire mode classification on one page; biology written next
to each dot.
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import config

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 11,
    "axes.spines.top": False,
    "axes.spines.right": False,
})

LABEL_COLORS = {
    "T":        "#1f77b4",
    "salt":     "#d62728",
    "coupled":  "#7d3ce8",
    "neither":  "#999999",
}

# Light backgrounds for the 4 quadrants
QUAD_BG = {
    ("low", "low"):   "#f7f7f7",   # neither
    ("high", "low"):  "#dceaf5",   # T
    ("low", "high"):  "#f7d8d8",   # salt
    ("high", "high"): "#e7daf5",   # coupled
}

RESIDUE_ANNOT = {
    1: "R617–D655",
    2: "T597–G618",
    3: "—",
    4: "Y454–T612",
    5: "L598–H614",
    6: "A620–L631",
    7: "V595–W616",
    8: "H614–F660",
}


def main():
    decomp = pd.read_csv(config.OUTPUTS / "chacras/atom_decomp.csv", index_col=0)
    top = decomp.iloc[:8]

    fig, ax = plt.subplots(figsize=(8.8, 7.4))
    fig.subplots_adjust(left=0.10, right=0.97, top=0.91, bottom=0.10)

    # ── Quadrant backgrounds ────────────────────────────────────────────
    THRESH = 0.5
    ax.add_patch(plt.Rectangle((0,      0),      THRESH, THRESH, color=QUAD_BG[("low","low")],   zorder=0))
    ax.add_patch(plt.Rectangle((THRESH, 0),      1-THRESH, THRESH, color=QUAD_BG[("high","low")],  zorder=0))
    ax.add_patch(plt.Rectangle((0,      THRESH), THRESH, 1-THRESH, color=QUAD_BG[("low","high")],  zorder=0))
    ax.add_patch(plt.Rectangle((THRESH, THRESH), 1-THRESH, 1-THRESH, color=QUAD_BG[("high","high")], zorder=0))

    # ── Quadrant labels in the corners ──────────────────────────────────
    ax.text(0.04, 0.04, "neither",  fontsize=14, fontweight="bold",
            color=LABEL_COLORS["neither"], alpha=0.55)
    ax.text(0.96, 0.04, "T-mode",   fontsize=14, fontweight="bold",
            color=LABEL_COLORS["T"],       ha="right", alpha=0.55)
    ax.text(0.04, 0.96, "salt-mode", fontsize=14, fontweight="bold",
            color=LABEL_COLORS["salt"],    va="top",   alpha=0.55)
    ax.text(0.96, 0.96, "coupled",  fontsize=14, fontweight="bold",
            color=LABEL_COLORS["coupled"], ha="right", va="top", alpha=0.55)

    # Threshold lines
    ax.axvline(THRESH, color="grey", linestyle="--", linewidth=0.6, alpha=0.7, zorder=1)
    ax.axhline(THRESH, color="grey", linestyle="--", linewidth=0.6, alpha=0.7, zorder=1)

    # ── PC dots ─────────────────────────────────────────────────────────
    sizes = (top["var_explained"] * 1e4).clip(lower=60)
    colors = [LABEL_COLORS[l] for l in top["label"]]
    ax.scatter(
        top["r2_T_marginal"], top["r2_salt_marginal"],
        s=sizes, c=colors, alpha=0.85, edgecolor="black", linewidth=0.7,
        zorder=3,
    )

    # Annotate each dot with PC label + residue pair
    for pc, row in top.iterrows():
        x = row["r2_T_marginal"]; y = row["r2_salt_marginal"]
        res = RESIDUE_ANNOT.get(pc, "")
        var = row["var_explained"] * 100
        text = f"PC{pc}  ({var:.1f}%)\n{res}"
        # Offset label to the upper-right of the dot, avoid overlaps
        ax.annotate(text, (x, y),
                    xytext=(8, 8), textcoords="offset points",
                    fontsize=9.5, ha="left", va="bottom",
                    fontweight=("bold" if row["label"] in ("T","coupled","salt") else "normal"),
                    color="black")

    # ── axes ────────────────────────────────────────────────────────────
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_aspect("equal")
    ax.set_xlabel("R²(T)   —   how well a linear T-trend alone explains the PC", fontsize=11)
    ax.set_ylabel("R²([salt])   —   how well a linear salt-trend alone explains the PC", fontsize=11)
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.grid(True, color="white", linewidth=0.8, alpha=0.7, zorder=0)

    # ── title ──────────────────────────────────────────────────────────
    fig.text(0.10, 0.955,
             "Mode classification of TRPV1 chacras  —  R²-quadrant view",
             fontsize=13, fontweight="bold")
    fig.text(0.10, 0.925,
             "marginal R² along each axis; threshold 0.5 partitions the plane.  "
             "Dot size = variance explained.",
             fontsize=9.5, color="#555555")

    # Legend for dot size
    var_marks = [(0.05, "5%"), (0.10, "10%")]
    for i, (v, label) in enumerate(var_marks):
        ax.scatter([], [], s=v * 1e4, c="#cccccc", edgecolor="black",
                   linewidth=0.7, label=f"{label} variance")
    ax.legend(loc="lower right", fontsize=8.5, frameon=False,
              labelspacing=1.4, scatterpoints=1, borderpad=0.8,
              bbox_to_anchor=(1.0, 0.08))

    out_png = config.OUTPUTS / "figures" / "atom_si_pc_dual.png"
    out_pdf = config.OUTPUTS / "figures" / "atom_si_pc_dual.pdf"
    fig.savefig(out_png, dpi=200, bbox_inches="tight")
    fig.savefig(out_pdf, bbox_inches="tight")
    print(f"saved {out_png}")
    print(f"saved {out_pdf}")


if __name__ == "__main__":
    main()
