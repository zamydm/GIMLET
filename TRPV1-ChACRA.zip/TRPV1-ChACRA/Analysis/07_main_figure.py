"""
Main-figure-style single-panel summary.

One horizontal bar per top PC.  Bar length = variance explained.  Each bar
is split blue (T axis) / red (salt axis) by marginal-R² share, with grey
"unexplained" tail when the fit is poor.  Each row annotated with the
dominant residue pair.  Eye should land on salt-dominance instantly.
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import config

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 11,
    "axes.spines.top": False,
    "axes.spines.right": False,
})

C_T    = "#1f77b4"      # T-axis  (blue)
C_SALT = "#d62728"      # salt-axis (red)
C_NONE = "#e0e0e0"      # unexplained (light grey)

# Dominant residue-pair annotation per top PC, chosen from the
# highest-|loading| contact in the loadings file.
RESIDUE_ANNOT = {
    1: "R617–D655  inter-subunit salt bridge",
    2: "T597–G618  S5/S6 backbone melting",
    3: "—",
    4: "Y454–T612  S2 ↔ pore helix",
    5: "L598–H614  pore-helix His hub",
    6: "A620–L631  S6 gate",
    7: "V595–W616  S5/S6 packing",
    8: "H614–F660  pore helix",
}


def main():
    decomp = pd.read_csv(config.OUTPUTS / "chacras/atom_decomp.csv", index_col=0)

    top_n = 8
    dec = decomp.iloc[:top_n]
    pc_idx = dec.index.to_numpy()
    var_pct = dec["var_explained"].to_numpy() * 100
    r2T = dec["r2_T_marginal"].to_numpy()
    r2S = dec["r2_salt_marginal"].to_numpy()

    # Proportional shares.  Use max(R²_T, R²_S, 0) so neither-class PCs
    # show a grey tail rather than spurious dominance.
    total = r2T + r2S
    share_T = np.where(total > 0, r2T / np.maximum(total, 1e-9), 0)
    # Length of the "explained" portion = max(R²_T, R²_S) × var
    explained_frac = np.maximum(r2T, r2S)   # using the larger marginal fit
    explained_len = explained_frac * var_pct
    seg_T = share_T * explained_len
    seg_S = explained_len - seg_T
    seg_none = var_pct - explained_len

    fig, ax = plt.subplots(figsize=(11.5, 5.8))
    fig.subplots_adjust(left=0.07, right=0.62, top=0.85, bottom=0.13)

    y = np.arange(len(pc_idx))[::-1]
    # Stacked bars: T  | salt | unexplained
    ax.barh(y, seg_T,    color=C_T,    edgecolor="white", linewidth=0.5)
    ax.barh(y, seg_S,    left=seg_T,                  color=C_SALT, edgecolor="white", linewidth=0.5)
    ax.barh(y, seg_none, left=seg_T + seg_S,          color=C_NONE, edgecolor="white", linewidth=0.5)

    # Per-row annotation OUTSIDE the bar
    for yi, (pc, v) in enumerate(zip(pc_idx, var_pct)):
        ax.text(v + 0.15, y[yi],
                f"  {RESIDUE_ANNOT.get(pc, '—')}",
                va="center", fontsize=10.5)

    ax.set_yticks(y)
    ax.set_yticklabels([f"PC{p}" for p in pc_idx], fontsize=11)
    ax.set_xlabel("variance explained  (%)", fontsize=11)
    ax.set_xlim(0, max(var_pct) * 2.0)
    # Tidy x ticks: 0, 2, 4, … up to slightly above max var
    xmax = int(np.ceil(max(var_pct)))
    ax.set_xticks(range(0, xmax + 2, 2))
    ax.set_xticklabels([f"{x}%" for x in range(0, xmax + 2, 2)])

    # Hide y-axis spine for a clean look
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)

    # Headline title + subtitle
    fig.text(
        0.07, 0.94,
        "Salt-driven contact rearrangements dominate the top of the TRPV1 PCA spectrum",
        fontsize=14, fontweight="bold",
    )
    fig.text(
        0.07, 0.895,
        "Each bar = variance explained by that mode, split by which axis "
        "(T or [salt]) explains the score pattern.",
        fontsize=10, color="#555555",
    )

    # Legend
    handles = [
        mpl.patches.Patch(color=C_T,    label="T-axis variance"),
        mpl.patches.Patch(color=C_SALT, label="salt-axis variance"),
        mpl.patches.Patch(color=C_NONE, label="unexplained by either axis"),
    ]
    ax.legend(handles=handles, fontsize=9.5, frameon=False,
              loc="lower right", bbox_to_anchor=(1.62, 0.0))

    out_png = config.OUTPUTS / "figures" / "atom_main.png"
    out_pdf = config.OUTPUTS / "figures" / "atom_main.pdf"
    fig.savefig(out_png, dpi=220, bbox_inches="tight")
    fig.savefig(out_pdf, bbox_inches="tight")
    print(f"saved {out_png}")
    print(f"saved {out_pdf}")


if __name__ == "__main__":
    main()
