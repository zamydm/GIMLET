"""
Generate a PyMOL script that loads 8GFARepairCenter.pdb and highlights
the residues that drive the top T-, salt-, and coupled chacras.

For each significant PC, we extract the union of residues appearing in
its top-N contacts.  A residue is classified:

  T-sensitive    — appears in a T-classified or coupled PC's top loadings
                   AND does *not* appear in a salt-classified PC top set
  salt-sensitive — only in salt PCs
  coupled        — appears in both

These colour categories let the eye separate gating residues that respond
purely to ionic strength from those that also respond to temperature.

Output: ``outputs/pymol/chacra_residues.pml`` — load this from PyMOL with
the reference structure (the script loads it automatically if the path
in ``REF_PDB`` is reachable from the PyMOL session).
"""
from __future__ import annotations

import re
import sys
from collections import defaultdict
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import config

TOP_PER_PC = 12     # number of top |loading| contacts to scan per PC
SIG_VAR    = 0.05   # consider PCs explaining ≥ 5% variance

CONTACT_RE = re.compile(r"^([A-Z]):([A-Z]+):(\d+)-([A-Z]):([A-Z]+):(\d+)$")


def parse_contact(s: str):
    m = CONTACT_RE.match(s)
    if not m:
        return None
    return m.groups()       # (chA, rnA, riA, chB, rnB, riB)


def main():
    decomp   = pd.read_csv(config.OUTPUTS / "chacras/atom_decomp.csv", index_col=0)
    loadings = pd.read_csv(config.OUTPUTS / "chacras/atom_loadings.csv", index_col=0)

    # Only meaningful PCs
    sig = decomp[decomp["var_explained"] >= SIG_VAR]

    # For each PC, harvest the residues touched by its top |loading| contacts
    residues_by_class: dict[str, set[tuple[str, int]]] = defaultdict(set)
    for pc, row in sig.iterrows():
        label = row["label"]
        pc_col = f"PC{pc}"
        top = loadings[pc_col].abs().sort_values(ascending=False).head(TOP_PER_PC)
        for contact in top.index:
            p = parse_contact(contact)
            if p is None:
                continue
            _, rnA, riA, _, rnB, riB = p
            for resn, resid in [(rnA, int(riA)), (rnB, int(riB))]:
                residues_by_class[label].add((resn, resid))

    salt_res    = residues_by_class.get("salt", set())
    T_res       = residues_by_class.get("T", set()) | residues_by_class.get("coupled", set())
    coupled_res = salt_res & T_res
    salt_only   = salt_res - T_res
    T_only      = T_res - salt_res

    def fmt_resi(s: set[tuple[str, int]]) -> str:
        return "+".join(str(r[1]) for r in sorted(s, key=lambda r: r[1])) or "0"

    # Headline contacts to draw as dashes
    headline_contacts = [
        ("ARG", 617, "A", "ASP", 655, "B", "R617–D655 inter-sub salt bridge"),
        ("THR", 597, "A", "GLY", 618, "A", "T597–G618 S5/S6 backbone"),
        ("LEU", 598, "A", "HSD", 614, "A", "L598–H614 H614 hub"),
        ("TYR", 454, "A", "THR", 612, "B", "Y454–T612 S2-pore"),
    ]

    pml_lines: list[str] = []
    pml_lines.append("# TRPV1 ChACRA residue-classification view")
    pml_lines.append("# Loads the reference structure and highlights residues")
    pml_lines.append("# that drive the top T-, salt-, and coupled chacras.")
    pml_lines.append("")
    pml_lines.append("# ── load structure ──────────────────────────────────────")
    pml_lines.append(f'load {config.REF_PDB}, trpv1')
    pml_lines.append("hide everything")
    pml_lines.append("show cartoon, trpv1")
    pml_lines.append("color grey80, trpv1")
    pml_lines.append("set cartoon_transparency, 0.10")
    pml_lines.append("bg_color white")
    pml_lines.append("set ray_shadows, 0")
    pml_lines.append("set ambient, 0.4")
    pml_lines.append("set ray_trace_mode, 1")
    pml_lines.append("")

    pml_lines.append("# ── classification selections ───────────────────────────")
    pml_lines.append(f"select T_only,      resi {fmt_resi(T_only)}")
    pml_lines.append(f"select salt_only,   resi {fmt_resi(salt_only)}")
    pml_lines.append(f"select coupled_res, resi {fmt_resi(coupled_res)}")
    pml_lines.append("")

    pml_lines.append("# ── colours: T = blue, salt = red, coupled = purple ─────")
    pml_lines.append("color marine, T_only")
    pml_lines.append("color firebrick, salt_only")
    pml_lines.append("color purpleblue, coupled_res")
    pml_lines.append("show sticks, T_only and not (name C+N+O)")
    pml_lines.append("show sticks, salt_only and not (name C+N+O)")
    pml_lines.append("show sticks, coupled_res and not (name C+N+O)")
    pml_lines.append("show spheres, (T_only or salt_only or coupled_res) and name CA")
    pml_lines.append("set sphere_scale, 0.45, name CA")
    pml_lines.append("")

    pml_lines.append("# ── headline contact distances ──────────────────────────")
    for resnA, riA, chA, resnB, riB, chB, comment in headline_contacts:
        sel_a = f"chain {chA} and resi {riA} and name CA"
        sel_b = f"chain {chB} and resi {riB} and name CA"
        name = f"d_{resnA}{riA}_{resnB}{riB}"
        pml_lines.append(f"distance {name}, ({sel_a}), ({sel_b})  # {comment}")
    pml_lines.append("color black, d_*")
    pml_lines.append("set dash_width, 2.5")
    pml_lines.append("set dash_radius, 0.07")
    pml_lines.append("hide labels, d_*")
    pml_lines.append("")

    pml_lines.append("# ── residue labels for the headline residues ────────────")
    headline_resids = sorted({(r[1], r[2]) for r in headline_contacts} | {(r[4], r[5]) for r in headline_contacts})
    for resi, chain in headline_resids:
        # PyMOL: resi is a *string* attribute, so we concatenate instead of %d
        pml_lines.append(
            f"label chain {chain} and resi {resi} and name CA, resn+resi"
        )
    pml_lines.append("set label_size, 12")
    pml_lines.append("set label_color, black")
    pml_lines.append("set label_outline_color, white")
    pml_lines.append("")

    pml_lines.append("# ── orient view: down the pore axis, zoomed to gating ──")
    pml_lines.append("orient (resi 590-660)")
    pml_lines.append("zoom (resi 590-660), 5")
    pml_lines.append("turn x, -20")
    pml_lines.append("")

    pml_lines.append("# Render a high-quality PNG next to this script")
    pml_lines.append(f'ray 1600, 1200')
    pml_lines.append(f'png {config.OUTPUTS / "figures" / "atom_structure.png"}, dpi=220')

    out = config.OUTPUTS / "pymol" / "chacra_residues.pml"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(pml_lines) + "\n")
    print(f"saved {out}")
    print()
    print("residue inventory:")
    print(f"  T-only       ({len(T_only)}): {sorted({r[1] for r in T_only})}")
    print(f"  salt-only    ({len(salt_only)}): {sorted({r[1] for r in salt_only})}")
    print(f"  coupled      ({len(coupled_res)}): {sorted({r[1] for r in coupled_res})}")


if __name__ == "__main__":
    main()
