"""
Lead ChACRA figure for the main text.

A unifying view across resolutions:
  (a) CG (4 µs) mode spectrum      — temperature mode dominates (PC1, 24%)
  (b) atomistic (400 ns) spectrum  — salt-led, T-mode at PC2 (complementary)
  (c) structural localization      — the mode-driving residues cluster in the
                                     S5/S6 gating region + pore mouth
Message: ChACRA decomposes TRPV1's contact network into temperature- and
salt-responsive collective modes that localize to the gating machinery;
coarse-grained and atomistic simulations give a consistent picture.
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpec

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src import config

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
})

C = {"T": "#2166ac", "salt": "#b2182b", "coupled": "#762a83", "neither": "#cccccc"}
NICE = {"T": "temperature", "salt": "salt", "coupled": "coupled", "neither": "—"}


SALT_C = {50: "#74add1", 100: "#7d3ce8", 150: "#b2182b"}


def profile(ax, scores, pc, title, var_pct, r2T, flip=False):
    """PC score vs temperature, one point per salt level + mean trend line."""
    s = scores[pc].copy()
    s.index = pd.MultiIndex.from_tuples(s.index, names=["T", "salt"])
    if flip:
        s = -s
    g = s.unstack("salt").sort_index()      # rows T, cols salt
    Ts = g.index.to_numpy(dtype=float)
    # per-salt points
    for salt in g.columns:
        ax.scatter(Ts, g[salt], s=34, color=SALT_C.get(salt, "grey"),
                   edgecolor="black", linewidth=0.4, zorder=3,
                   label=f"{salt} mM")
    # mean trend
    mean = g.mean(axis=1)
    ax.plot(Ts, mean, color="black", lw=1.6, zorder=2)
    # linear fit line
    b = np.polyfit(Ts, mean, 1)
    ax.plot(Ts, np.polyval(b, Ts), "--", color="grey", lw=1.0, zorder=1)
    ax.axhline(0, color="grey", lw=0.5, ls=":")
    ax.set_xlabel("temperature (K)")
    ax.set_ylabel("PC score")
    ax.set_title(title, fontsize=10.5, fontweight="bold", loc="left")
    ax.text(0.03, 0.06, f"{var_pct:.0f}% variance · R²(T) = {r2T:.2f}",
            transform=ax.transAxes, fontsize=8.5, color="#333333")
    ax.set_xticks(Ts.astype(int))


def main():
    cg_s = pd.read_csv(config.OUTPUTS / "chacras/cg_scores.csv", index_col=[0, 1])
    at_s = pd.read_csv(config.OUTPUTS / "chacras/atom_scores.csv", index_col=[0, 1])

    fig = plt.figure(figsize=(12.5, 6.2))
    gs = GridSpec(2, 2, width_ratios=[1.0, 1.25], height_ratios=[1, 1],
                  left=0.07, right=0.985, top=0.86, bottom=0.11,
                  wspace=0.20, hspace=0.60)

    ax_cg = fig.add_subplot(gs[0, 0])
    ax_at = fig.add_subplot(gs[1, 0])
    ax_st = fig.add_subplot(gs[:, 1])

    # Temperature-mode profiles. Signs aligned (arbitrary in PCA) so both
    # read as "score decreases with temperature".
    profile(ax_cg, cg_s, "PC1", "(a)  CG temperature mode  (Martini, 4 µs)",
            var_pct=24.3, r2T=0.55, flip=False)
    profile(ax_at, at_s, "PC2", "(b)  atomistic temperature mode  (400 ns)",
            var_pct=9.9, r2T=0.85, flip=True)

    ax_cg.legend(title="[salt]", fontsize=7.5, title_fontsize=7.5,
                 loc="upper right", frameon=False, ncol=3,
                 columnspacing=0.8, handletextpad=0.3)

    # structure panel — crop surrounding whitespace
    img_path = config.OUTPUTS / "figures" / "lead_structure.png"
    if img_path.exists():
        img = mpimg.imread(img_path)
        # crop near-white margins
        gray = img[..., :3].mean(2) if img.ndim == 3 else img
        rows = np.where((gray < 0.97).any(1))[0]
        cols = np.where((gray < 0.97).any(0))[0]
        if len(rows) and len(cols):
            pad = 20
            img = img[max(rows[0]-pad,0):rows[-1]+pad,
                      max(cols[0]-pad,0):cols[-1]+pad]
        ax_st.imshow(img)
    ax_st.axis("off")
    ax_st.set_title("(c)  mode residues localize to the S5/S6 gate + pore mouth",
                    fontsize=10.5, fontweight="bold", loc="left")

    fig.text(0.07, 0.95,
             "TRPV1's dominant contact mode weakens with temperature in both "
             "resolutions and localizes to the gating machinery",
             fontsize=12.5, fontweight="bold")
    fig.text(0.07, 0.915,
             "Each point is one (T, salt) simulation; spread across salt at "
             "fixed T reflects ionic modulation. Signs aligned (arbitrary in PCA).",
             fontsize=9.5, color="#555555")

    out = config.OUTPUTS / "figures" / "lead_chacra_profiles.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    print(f"saved {out}")


if __name__ == "__main__":
    main()
