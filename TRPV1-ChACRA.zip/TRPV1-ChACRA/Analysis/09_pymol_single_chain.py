"""
Single-chain PyMOL view of the TRPV1 ChACRA classification.

Same residue partitioning as analysis.08_pymol_script (T-only / salt-only /
coupled) but only chain A is drawn in full detail; chains B/C/D are kept
as semi-transparent cartoon for spatial context.  The view is rotated to
a "side-on" angle where the S5/S6/pore-helix bundle runs roughly
vertically so the membrane-spanning geometry is obvious.

Inter-subunit contacts (e.g. R617_A – D655_B) still draw a dashed line to
the partner chain so you can see across-subunit links explicitly.
"""
from __future__ import annotations

import re
import sys
from collections import defaultdict
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import config

TOP_PER_PC = 12
SIG_VAR    = 0.05

CONTACT_RE = re.compile(r"^([A-Z]):([A-Z]+):(\d+)-([A-Z]):([A-Z]+):(\d+)$")


def parse_contact(s: str):
    m = CONTACT_RE.match(s)
    return m.groups() if m else None


def main():
    decomp   = pd.read_csv(config.OUTPUTS / "chacras/atom_decomp.csv", index_col=0)
    loadings = pd.read_csv(config.OUTPUTS / "chacras/atom_loadings.csv", index_col=0)

    sig = decomp[decomp["var_explained"] >= SIG_VAR]
    by_class: dict[str, set[int]] = defaultdict(set)
    for pc, row in sig.iterrows():
        label = row["label"]
        top = loadings[f"PC{pc}"].abs().sort_values(ascending=False).head(TOP_PER_PC)
        for contact in top.index:
            p = parse_contact(contact)
            if p is None:
                continue
            _, _, riA, _, _, riB = p
            by_class[label].add(int(riA))
            by_class[label].add(int(riB))

    salt_res    = by_class.get("salt", set())
    T_res       = by_class.get("T", set()) | by_class.get("coupled", set())
    coupled_res = salt_res & T_res
    salt_only   = salt_res - T_res
    T_only      = T_res - salt_res

    def fmt(s: set[int]) -> str:
        return "+".join(str(r) for r in sorted(s)) or "0"

    # Headline contacts — (chA, resi_A, chB, resi_B, comment)
    headline = [
        ("A", 617, "B", 655, "R617–D655 salt bridge"),
        ("A", 597, "A", 618, "T597–G618 S5/S6"),
        ("A", 598, "A", 614, "L598–H614 H614 hub"),
        ("A", 454, "B", 612, "Y454–T612 S2–pore"),
    ]

    lines: list[str] = []
    lines.append("# TRPV1 ChACRA — single-chain (A) view with B/C/D as context")
    lines.append("")
    lines.append("# ── load + global style ─────────────────────────────────")
    lines.append(f'load {config.REF_PDB}, trpv1')
    lines.append("hide everything")
    lines.append("bg_color white")
    lines.append("set ray_shadows, 0")
    lines.append("set ambient, 0.45")
    lines.append("set ray_trace_mode, 1")
    lines.append("set cartoon_fancy_helices, 1")
    lines.append("")

    lines.append("# ── context chains B/C/D: faded cartoon only ─────────────")
    lines.append("show cartoon, trpv1 and chain B+C+D")
    lines.append("color grey90, trpv1 and chain B+C+D")
    lines.append("set cartoon_transparency, 0.65, chain B+C+D")
    lines.append("")

    lines.append("# ── focus chain A: solid cartoon + classified sidechains ─")
    lines.append("show cartoon, trpv1 and chain A")
    lines.append("color grey70, trpv1 and chain A")
    lines.append("set cartoon_transparency, 0.0, chain A")
    lines.append("")

    lines.append("# Classified residues on chain A only")
    lines.append(f"select T_A,     chain A and resi {fmt(T_only)}")
    lines.append(f"select salt_A,  chain A and resi {fmt(salt_only)}")
    lines.append(f"select coup_A,  chain A and resi {fmt(coupled_res)}")
    lines.append("")
    lines.append("color marine,     T_A")
    lines.append("color firebrick,  salt_A")
    lines.append("color purpleblue, coup_A")
    lines.append("show sticks, (T_A or salt_A or coup_A) and not (name C+N+O)")
    lines.append("show spheres, (T_A or salt_A or coup_A) and name CA")
    lines.append("set sphere_scale, 0.5, name CA")
    lines.append("")

    # For inter-subunit headline contacts, also draw the partner sidechain
    # on chain B (since chain A's residue contacts chain B's residue)
    partner_residues_B = {(chB, resB) for (chA, resA, chB, resB, _) in headline if chB != "A"}
    if partner_residues_B:
        partner_sel = " or ".join(
            f"(chain {chB} and resi {resB})" for chB, resB in partner_residues_B
        )
        lines.append("# Inter-subunit partner residues drawn on chain B for context")
        lines.append(f"select partners_B, {partner_sel}")
        lines.append("# Tint partner by the class of its A-chain interactor")
        # All partner residues here are paired with chain-A residues; for
        # the headline set R617(A)-D655(B), Y454(A)-T612(B), both A-side
        # residues are coupled, so colour partners as coupled too.
        lines.append("color purpleblue, partners_B")
        lines.append("set cartoon_transparency, 0.0, partners_B")
        lines.append("show sticks, partners_B and not (name C+N+O)")
        lines.append("show spheres, partners_B and name CA")
        lines.append("")

    lines.append("# ── headline contact dashes ─────────────────────────────")
    for chA, riA, chB, riB, comment in headline:
        name = f"d_{chA}{riA}_{chB}{riB}"
        sel_a = f"chain {chA} and resi {riA} and name CA"
        sel_b = f"chain {chB} and resi {riB} and name CA"
        lines.append(f"distance {name}, ({sel_a}), ({sel_b})  # {comment}")
    lines.append("color black, d_*")
    lines.append("set dash_width, 2.5")
    lines.append("set dash_radius, 0.08")
    lines.append("hide labels, d_*")
    lines.append("")

    lines.append("# ── residue labels for the 8 headline endpoints ─────────")
    headline_endpoints = set()
    for chA, riA, chB, riB, _ in headline:
        headline_endpoints.add((chA, riA))
        headline_endpoints.add((chB, riB))
    for ch, ri in sorted(headline_endpoints):
        lines.append(f"label chain {ch} and resi {ri} and name CA, resn+resi")
    lines.append("set label_size, 13")
    lines.append("set label_color, black")
    lines.append("set label_outline_color, white")
    lines.append("set label_font_id, 7")
    lines.append("")

    lines.append("# ── orient: focus tightly on the classified residue cluster ─")
    lines.append("# Orient on just the highlighted atoms (not the whole helix range)")
    lines.append("orient (T_A or salt_A or coup_A or partners_B)")
    lines.append("zoom (T_A or salt_A or coup_A or partners_B), 4")
    lines.append("# Slight tilt so the inter-subunit dash (R617-D655) is in view")
    lines.append("turn y, 15")
    lines.append("turn x, -10")
    lines.append("")

    lines.append("# ── render ──────────────────────────────────────────────")
    lines.append(f'ray 1600, 1400')
    lines.append(f'png {config.OUTPUTS / "figures" / "atom_structure_chainA.png"}, dpi=220')

    out = config.OUTPUTS / "pymol" / "chacra_residues_chainA.pml"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n")
    print(f"saved {out}")


if __name__ == "__main__":
    main()
