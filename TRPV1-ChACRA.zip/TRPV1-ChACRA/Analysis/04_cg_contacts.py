"""
Distance-cutoff contact frequencies for every CG (T, salt) state.

CG runs are 4.7 GB / state and last ~µs; default stride is 5 and we drop
the first 100 ns before counting.  Tune ``--cutoff`` (Martini convention is
6 Å between any pair of beads) or ``--stride`` as needed.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import conditions, cg_contacts, config


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoff", type=float, default=6.0)
    ap.add_argument("--stride", type=int, default=5)
    ap.add_argument("--drop_ns", type=float, default=100.0)
    ap.add_argument("--only", nargs="*", default=None)
    args = ap.parse_args()

    todo = conditions.discover("cg")
    if args.only:
        todo = [c for c in todo if c.label in set(args.only)]
    if not todo:
        sys.exit("No CG states found on disk.")

    for c in todo:
        out = config.OUTPUTS / "freqs" / "cg" / f"freqs_{c.label}.tsv"
        if out.exists():
            print(f"[skip] {c.label} — {out}")
            continue
        print(f"[run ] {c.label}")
        cg_contacts.write_state_freqs(
            c, cutoff_A=args.cutoff, stride=args.stride, drop_ns=args.drop_ns,
        )
        print(f"[done] {c.label} → {out}")


if __name__ == "__main__":
    main()
