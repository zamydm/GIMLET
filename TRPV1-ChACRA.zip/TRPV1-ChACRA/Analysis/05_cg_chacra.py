"""
Run 2D-ChACRA on the CG (T, salt) grid.  Same pipeline as the atomistic
script, just pointing at the CG matrix.
"""
from __future__ import annotations

import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_root))
sys.path.insert(0, str(_root / "ChACRA"))   # vendored chacra package

from src import chacra2d, conditions, config, frequencies, plot


def main():
    conds = conditions.discover("cg")
    df = frequencies.build_matrix(conds, resolution="cg", symmetry_average=True)
    frequencies.save_matrix(df, "cg_freqs_symavg")
    print(f"[matrix] {df.shape[0]} states × {df.shape[1]} C4-symmetry-averaged contacts")

    res = chacra2d.run(df, n_permutations=1000, n_jobs=4, r2_thresh=0.5)
    out = config.OUTPUTS / "chacras"
    res["scores"].to_csv(out / "cg_scores.csv")
    res["loadings"].to_csv(out / "cg_loadings.csv")
    res["decomp"].to_csv(out / "cg_decomp.csv")
    print(res["decomp"])

    fig_dir = config.OUTPUTS / "figures"
    pcs = [f"PC{i+1}" for i in range(min(4, res["scores"].shape[1]))]
    plot.plot_pc_grid(res["scores"], pcs=pcs).savefig(fig_dir / "cg_pc_grid.png", dpi=160)
    plot.plot_decomp_bars(res["decomp"]).savefig(fig_dir / "cg_decomp.png", dpi=160)
    for pc in pcs:
        plot.plot_top_loadings(res["loadings"], pc=pc).savefig(
            fig_dir / f"cg_top_loadings_{pc}.png", dpi=160)


if __name__ == "__main__":
    main()
