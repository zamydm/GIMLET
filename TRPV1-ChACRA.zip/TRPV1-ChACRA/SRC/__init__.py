"""TRPV1 ChACRA-style analysis over (temperature, salt) grid."""
