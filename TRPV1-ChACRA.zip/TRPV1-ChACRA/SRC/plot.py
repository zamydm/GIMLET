"""
Plotting helpers for 2D-ChACRA results.

Two views are most useful:

1. **PC-score grid**: heatmap of each PC's score over the (T, salt) grid.
   T-modes show vertical stripes, salt-modes show horizontal stripes,
   coupled modes show diagonal / curved structure.
2. **Loading rank plot**: top-loaded contacts per PC, coloured by sign.

For per-residue PyMOL projection the existing
``chacra.visualize.pymol.to_pymol`` works directly on the ContactPCA object
returned by ``chacra2d.run``.
"""
from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _grid_pivot(scores: pd.DataFrame, pc: str) -> pd.DataFrame:
    """MultiIndex(T_K, salt_mM) → 2D (T × salt) frame for one PC."""
    s = scores[pc].copy()
    s.index = pd.MultiIndex.from_tuples(s.index, names=["T_K", "salt_mM"])
    return s.unstack("salt_mM").sort_index()


def plot_pc_grid(scores: pd.DataFrame, pcs=("PC1", "PC2", "PC3", "PC4"),
                 cmap: str = "RdBu_r", figsize=(12, 3)):
    """One subplot per PC; cells coloured by score on (T × salt) grid."""
    fig, axes = plt.subplots(1, len(pcs), figsize=figsize, sharey=True)
    if len(pcs) == 1:
        axes = [axes]
    for ax, pc in zip(axes, pcs):
        g = _grid_pivot(scores, pc)
        vmax = float(np.max(np.abs(g.values))) or 1.0
        im = ax.imshow(g.values, aspect="auto", cmap=cmap, vmin=-vmax, vmax=vmax,
                       origin="lower")
        ax.set_xticks(range(g.shape[1])); ax.set_xticklabels(g.columns)
        ax.set_yticks(range(g.shape[0])); ax.set_yticklabels(g.index)
        ax.set_title(pc); ax.set_xlabel("[salt] (mM)")
        fig.colorbar(im, ax=ax, fraction=0.04, pad=0.04)
    axes[0].set_ylabel("T (K)")
    fig.tight_layout()
    return fig


def plot_pc_vs_axis(scores: pd.DataFrame, axis: str = "T_K",
                    pcs=("PC1", "PC2", "PC3", "PC4"), figsize=(7, 4)):
    """Classical ChACRA-style line plot, but with one line per *other* axis
    (e.g. one line per salt level if axis='T_K')."""
    other = "salt_mM" if axis == "T_K" else "T_K"
    fig, ax = plt.subplots(1, 1, figsize=figsize)
    for pc in pcs:
        s = scores[pc].copy()
        s.index = pd.MultiIndex.from_tuples(s.index, names=["T_K", "salt_mM"])
        for level, sub in s.groupby(other):
            sub = sub.droplevel(other).sort_index()
            ax.plot(sub.index, sub.values, marker="o", linewidth=1,
                    label=f"{pc} | {other}={level}")
    ax.set_xlabel(axis); ax.set_ylabel("PC score")
    ax.legend(fontsize=7, ncol=2, loc="best")
    fig.tight_layout()
    return fig


def plot_top_loadings(loadings: pd.DataFrame, pc: str, n: int = 20, figsize=(7, 5)):
    s = loadings[pc].sort_values(key=lambda x: x.abs(), ascending=False).head(n)
    fig, ax = plt.subplots(1, 1, figsize=figsize)
    colors = ["#2b6cb0" if v > 0 else "#c53030" for v in s.values]
    ax.barh(range(len(s)), s.values, color=colors)
    ax.set_yticks(range(len(s))); ax.set_yticklabels(s.index, fontsize=7)
    ax.invert_yaxis(); ax.set_xlabel(f"{pc} loading")
    ax.axvline(0, color="k", linewidth=0.5)
    fig.tight_layout()
    return fig


def plot_decomp_bars(decomp: pd.DataFrame, figsize=(8, 4)):
    """Stacked bar of partial R² (T) and partial R² (salt) per PC."""
    fig, ax = plt.subplots(1, 1, figsize=figsize)
    x = decomp.index.to_numpy()
    ax.bar(x, decomp["r2_T_partial"], label="R²_T (partial)", color="#2b6cb0")
    ax.bar(x, decomp["r2_salt_partial"], bottom=decomp["r2_T_partial"],
           label="R²_salt (partial)", color="#c53030")
    ax.set_xticks(x); ax.set_xlabel("PC"); ax.set_ylabel("Partial R²")
    ax.set_ylim(0, 1.05); ax.legend()
    for xi, lab in zip(x, decomp["label"]):
        ax.text(xi, 1.02, lab, ha="center", fontsize=8)
    fig.tight_layout()
    return fig
