"""
Distance-based contact frequencies for Martini 3 coarse-grained trajectories.

getcontacts assumes atomistic interaction types (H-bonds, salt bridges, …)
which Martini doesn't expose; for CG we use a bead-distance cutoff: a residue
pair is "in contact" in a frame if any qualifying pair of beads between the
two residues is within ``cutoff_A``.

Elastic-network awareness
-------------------------
These TRPV1 CG models were built with ``martinize2 -elastic -p backbone``:
a backbone (BB) elastic network (≈6 springs/residue, k=700 kJ/mol/nm²,
0.9 nm cutoff) holds the tertiary fold.  BB–BB tertiary contacts are
therefore *spring-frozen* and carry no ChACRA signal.

We sidestep this by counting only **side-chain-involving** contacts: a bead
pair qualifies if at least one of the two beads is a side-chain bead (name
starts with ``SC``).  This captures the free, salt-responsive degrees of
freedom (side-chain packing, charged salt bridges) and excludes the frozen
BB scaffold.  Set ``sidechain_only=False`` to count all beads (not advised
for elastic-network models).

Output schema matches the atomistic ``freqs_<state>.tsv`` so downstream
``frequencies.py`` aggregation is identical for both resolutions.
"""
from __future__ import annotations

import time
from pathlib import Path

import MDAnalysis as mda
import numpy as np
import pandas as pd
from MDAnalysis.lib.distances import self_capped_distance

from .conditions import Condition
from . import config, trajectory_io


def _residue_id(res) -> str:
    """ChACRA-style residue id: ``CHAIN:RESN:RESID``."""
    return f"{res.segid}:{res.resname}:{res.resid}"


def cg_contact_freqs(
    cond: Condition,
    cutoff_A: float = 6.0,
    stride: int = 5,
    drop_ns: float = 200.0,
    min_seq_sep: int = 2,
    sidechain_only: bool = True,
    verbose: bool = True,
    universe_override: "mda.Universe | None" = None,
) -> pd.DataFrame:
    """
    Compute residue-pair contact frequencies for a CG trajectory.

    Parameters
    ----------
    cutoff_A : float
        Bead-bead distance cutoff defining "in contact" (default 6 Å).
    stride : int
        Frame stride.  CG runs are 20001 frames (4 µs); stride 5 → 4000 frames.
    drop_ns : float
        Equilibration drop.  CG runs are 4 µs; default 200 ns.
    min_seq_sep : int
        Skip same-chain pairs with |i − j| < min_seq_sep.
    sidechain_only : bool
        If True (default), a contact requires ≥1 side-chain bead, excluding
        the elastic-network-frozen BB–BB scaffold.

    Returns
    -------
    pd.DataFrame indexed by ``"resA-resB"`` with one ``contact_frequency`` col.
    """
    t0 = time.time()
    u = universe_override if universe_override is not None \
        else trajectory_io.universe(cond, centered=True)
    prot = u.select_atoms("protein")
    residues = list(prot.residues)
    res_ids = [_residue_id(r) for r in residues]
    n_res = len(residues)

    base = prot.atoms.indices[0]
    bead_to_res = np.empty(prot.n_atoms, dtype=np.int32)
    is_sc = np.zeros(prot.n_atoms, dtype=bool)
    for i, r in enumerate(residues):
        local = r.atoms.indices - base
        bead_to_res[local] = i
        for li, nm in zip(local, r.atoms.names):
            is_sc[li] = nm.startswith("SC")

    counts = np.zeros((n_res, n_res), dtype=np.int64)
    start = trajectory_io.equil_cut(cond, drop_ns=drop_ns)
    n_used = 0
    for ts in u.trajectory[start::stride]:
        pairs = self_capped_distance(
            prot.positions, max_cutoff=cutoff_A,
            box=ts.dimensions, return_distances=False,
        )
        n_used += 1
        if len(pairs) == 0:
            continue
        bi, bj = pairs[:, 0], pairs[:, 1]
        ri = bead_to_res[bi]; rj = bead_to_res[bj]
        mask = ri != rj
        if sidechain_only:
            # keep pair if at least one bead is a side-chain bead
            mask &= (is_sc[bi] | is_sc[bj])
        if not mask.any():
            continue
        ri, rj = ri[mask], rj[mask]
        lo = np.minimum(ri, rj); hi = np.maximum(ri, rj)
        flat = np.unique(lo.astype(np.int64) * n_res + hi.astype(np.int64))
        counts[flat // n_res, flat % n_res] += 1
        if verbose and n_used % 1000 == 0:
            print(f"    {cond.label}  {n_used} frames  ({time.time()-t0:.0f}s)",
                  flush=True)

    freqs = counts / max(n_used, 1)
    pi, pj = np.where(freqs > 0)
    rows = []
    for i, j in zip(pi, pj):
        ra, rb = residues[i], residues[j]
        if ra.segid == rb.segid and abs(ra.resid - rb.resid) < min_seq_sep:
            continue
        rows.append((res_ids[i], res_ids[j], float(freqs[i, j])))
    df = pd.DataFrame(rows, columns=["residue_1", "residue_2", "contact_frequency"])
    df["pair"] = df["residue_1"] + "-" + df["residue_2"]
    if verbose:
        print(f"  [done] {cond.label}: {n_used} frames, {len(df)} contacts "
              f"in {time.time()-t0:.0f}s", flush=True)
    return df.set_index("pair")[["contact_frequency"]]


def write_state_freqs(cond: Condition, **kwargs) -> Path:
    """Write a freqs_<state>.tsv compatible with the atomistic pipeline."""
    out = config.OUTPUTS / "freqs" / "cg" / f"freqs_{cond.label}.tsv"
    if out.exists():
        return out
    df = cg_contact_freqs(cond, **kwargs)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w") as fh:
        fh.write(f"# CG side-chain bead contacts ({cond.label}); "
                 f"elastic-network BB scaffold excluded\n")
        fh.write("# residue_1\tresidue_2\tcontact_frequency\n")
        d = df.copy()
        d["residue_1"] = [p.split("-", 1)[0] for p in df.index]
        d["residue_2"] = [p.split("-", 1)[1] for p in df.index]
        d[["residue_1", "residue_2", "contact_frequency"]].to_csv(
            fh, sep="\t", header=False, index=False
        )
    return out
