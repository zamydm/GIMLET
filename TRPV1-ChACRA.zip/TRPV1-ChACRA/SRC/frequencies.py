"""
Aggregate per-state contact-frequency files into a single (state × pair)
matrix that ChACRA's ``ContactFrequencies`` can consume.

We carry both resolutions through the same code path; the only difference is
which folder under ``outputs/freqs/`` we read from.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from . import config
from .conditions import Condition


def _load_one(path: Path) -> pd.Series:
    """Mirror chacra.ContactFrequencies.load_contact_file (skiprows=2)."""
    df = pd.read_csv(
        path, sep="\t", skiprows=2, header=None,
        names=["residue_1", "residue_2", "contact_frequency"],
        skipinitialspace=True,
    )
    df["pair"] = df["residue_1"] + "-" + df["residue_2"]
    return df.set_index("pair")["contact_frequency"]


def build_matrix(
    conditions: list[Condition],
    resolution: str | None = None,
    symmetry_average: bool = True,
    structure: str | None = None,
    representative_chains: list[str] | None = None,
) -> pd.DataFrame:
    """
    Build a (state × contact-pair) DataFrame.

    Index is a MultiIndex (T, salt_mM); columns are residue-pair strings.
    Missing pairs in any state are filled with 0 (ChACRA convention).

    Parameters
    ----------
    conditions : list[Condition]
        States to include.  Order is preserved → caller controls row ordering.
    resolution : str, optional
        ``"atom"`` or ``"cg"``.  If None, taken from the first condition.
    symmetry_average : bool
        If True (default for this project), collapse the 4 chains of the
        TRPV1 tetramer into a single representative set of contacts using
        ``chacra.average.average_multimer``.  This boosts statistical power
        ~4× on the chacras and is the right default for any homomultimer.
    structure : str, optional
        PDB used by the symmetry averager.  Defaults to ``config.REF_PDB``.
    representative_chains : list[str], optional
        Chain(s) to keep in the averaged DataFrame.  Defaults to ``["A"]``.
    """
    if not conditions:
        raise ValueError("No conditions supplied")
    res = resolution or conditions[0].resolution
    sub = "atom" if res == "atom" else "cg"
    series_list, index = [], []
    for c in conditions:
        f = config.OUTPUTS / "freqs" / sub / f"freqs_{c.label}.tsv"
        if not f.exists():
            raise FileNotFoundError(f"Missing freq file for {c.label}: {f}")
        series_list.append(_load_one(f))
        index.append((c.T, c.salt_mM))
    df = pd.DataFrame(series_list).fillna(0.0)
    df.index = pd.MultiIndex.from_tuples(index, names=["T_K", "salt_mM"])
    df.columns.name = None

    if symmetry_average:
        df = symmetry_average_chains(
            df, method="c4",   # fast path; structure not needed for C4
        )
    return df


def symmetry_average_chains(
    df: pd.DataFrame,
    structure: str | None = None,
    representative_chains: list[str] | None = None,
    method: str = "c4",
) -> pd.DataFrame:
    """
    Collapse chain-redundant contacts using TRPV1's 4-fold symmetry.

    Two methods:
      * ``method="c4"`` (default, fast): exploits C4 symmetry directly via
        ``c4_average.c4_symmetry_average``.  No structure file needed,
        seconds for ~15k contacts.
      * ``method="chacra"``: ChACRA's ``average_multimer``, which does
        rotation-matrix matching to identify equivalent chain pairs.
        Robust for general homomultimers but O(N²) in pandas drops, so
        slow for our ~15k contacts.

    Preserves the (T, salt_mM) MultiIndex.
    """
    saved_index = df.index
    if method == "c4":
        from .c4_average import c4_symmetry_average
        avg = c4_symmetry_average(df)
    elif method == "chacra":
        if structure is None:
            raise ValueError("method='chacra' needs a structure file path")
        from chacra.average import average_multimer
        avg = average_multimer(
            structure=structure, df=df,
            representative_chains=representative_chains or ["A"],
        )
    else:
        raise ValueError(f"Unknown symmetry-averaging method: {method!r}")
    avg.index = saved_index
    avg.columns.name = None
    return avg


def save_matrix(df: pd.DataFrame, name: str) -> Path:
    out = config.OUTPUTS / "matrices" / f"{name}.parquet"
    out.parent.mkdir(parents=True, exist_ok=True)
    # Parquet doesn't love MultiIndex; flatten to a column pair.
    df_out = df.copy()
    df_out.reset_index().to_parquet(out, index=False)
    return out


def load_matrix(name: str) -> pd.DataFrame:
    out = config.OUTPUTS / "matrices" / f"{name}.parquet"
    df = pd.read_parquet(out)
    df = df.set_index(["T_K", "salt_mM"])
    return df
