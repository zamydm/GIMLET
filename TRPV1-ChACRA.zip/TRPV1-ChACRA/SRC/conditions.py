"""
Parse and enumerate (temperature, salt) conditions.

Folder names follow the convention ``<T>K<SS>`` where T is the integer Kelvin
target and SS is a 2-char salt code (00, 05, 10, 15).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from . import config

_PAT = re.compile(r"^(\d{3})K(\d{2})$")


@dataclass(frozen=True)
class Condition:
    T: int            # Kelvin
    salt_code: str    # "00", "05", "10", "15"
    resolution: str   # "atom" or "cg"

    @property
    def label(self) -> str:
        return f"{self.T}K{self.salt_code}"

    @property
    def salt_mM(self) -> int:
        return config.SALT_MM[self.salt_code]

    @property
    def state_dir(self) -> Path:
        roots = config.ATOM_DIRS if self.resolution == "atom" else config.CG_DIRS
        for r in roots:
            d = config.DATA_ROOT / r / self.label
            if (d / config.PROD_XTC).exists():
                return d
        # Fall back to first root even if production not present (caller checks).
        return config.DATA_ROOT / roots[0] / self.label

    def files(self) -> dict[str, Path]:
        d = self.state_dir
        return {
            "xtc": d / config.PROD_XTC,
            "xtc_centered": d / config.PROD_XTC_CENTERED,
            "tpr": d / config.PROD_TPR,
            "gro": d / config.PROD_GRO,
            # Pre-extracted protein-only files (current Atomistic/ dataset).
            "prot_xtc": d / config.PROT_XTC,
            "prot_pdb": d / config.PROT_PDB,
            "prot_gro": d / config.PROT_GRO,
        }

    def has_protein_only(self) -> bool:
        """True if NPTProteinCenter.{xtc,pdb} are pre-extracted for this state."""
        f = self.files()
        return f["prot_xtc"].exists() and f["prot_pdb"].exists()


def parse_label(label: str) -> tuple[int, str]:
    """``"310K10"`` → ``(310, "10")``."""
    m = _PAT.match(label)
    if not m:
        raise ValueError(f"Bad condition label: {label!r}")
    return int(m.group(1)), m.group(2)


def grid(resolution: str) -> list[Condition]:
    """Return the expected condition list for a resolution."""
    spec = config.ATOM_GRID_EXPECTED if resolution == "atom" else config.CG_GRID_EXPECTED
    return [
        Condition(T=T, salt_code=s, resolution=resolution)
        for T in spec["T"] for s in spec["salt"]
    ]


def discover(resolution: str) -> list[Condition]:
    """Walk DATA_ROOT and return every Condition with a production NPT.xtc on disk."""
    roots = config.ATOM_DIRS if resolution == "atom" else config.CG_DIRS
    found: dict[tuple[int, str], Condition] = {}
    for r in roots:
        base = config.DATA_ROOT / r
        if not base.exists():
            continue
        for sub in base.iterdir():
            if not sub.is_dir():
                continue
            try:
                T, salt = parse_label(sub.name)
            except ValueError:
                continue
            if (sub / config.PROD_XTC).exists():
                key = (T, salt)
                if key not in found:
                    found[key] = Condition(T=T, salt_code=salt, resolution=resolution)
    return sorted(found.values(), key=lambda c: (c.T, c.salt_code))


def to_state_index(conds: Iterable[Condition]) -> dict[Condition, int]:
    """Stable mapping Condition → integer state index (sorted by T then salt)."""
    return {c: i for i, c in enumerate(sorted(conds, key=lambda c: (c.T, c.salt_code)))}
