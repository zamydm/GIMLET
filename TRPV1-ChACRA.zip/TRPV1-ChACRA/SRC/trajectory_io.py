"""
Trajectory loading + light QC.

Production trajectories live on a SMB-mounted volume (~2.6 GB atomistic,
~4.7 GB CG per state), so we never copy them — we open with MDAnalysis and
stream.  Use ``stride`` to skip frames during contact analysis.

SMB caveat: macOS SMB doesn't fully support ``fcntl.flock``, which MDA
uses to lock its offsets-cache sidecar.  We pre-emptively neuter the
``filelock`` release path so the universe-open never fails on SMB.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import MDAnalysis as mda
import numpy as np

from .conditions import Condition

# ── SMB filelock workaround ──────────────────────────────────────────────
# `MDAnalysis.coordinates.XDR._load_offsets` wraps the offsets-cache write
# in a `filelock.FileLock`.  On SMB the fd returned by `os.open` for the
# lock file is invalidated by the time `flock(fd, LOCK_UN)` is called on
# release, raising OSError(EBADF=9).  This makes Universe construction
# unreliable.  Patch _release to swallow EBADF — no other process is
# touching the lock so dropping it silently is safe.
try:
    import errno
    import fcntl
    from filelock._unix import UnixFileLock

    _orig_release = UnixFileLock._release

    def _smb_safe_release(self):
        try:
            _orig_release(self)
        except OSError as e:
            if e.errno != errno.EBADF:
                raise

    UnixFileLock._release = _smb_safe_release  # type: ignore[assignment]
except ImportError:
    pass


@dataclass
class TrajInfo:
    n_frames: int
    n_atoms: int
    dt_ps: float
    total_ns: float


def universe(cond: Condition, centered: bool = True,
             protein_only: bool | None = None,
             retries: int = 3, retry_wait_s: float = 5.0) -> mda.Universe:
    """Build an MDAnalysis Universe for one (T, salt) condition.

    If ``protein_only`` is None (default), use the pre-extracted
    ``NPTProteinCenter.{xtc,pdb}`` files when they exist (they're 15× faster
    to stream over SMB than the full-system XTC). Set ``protein_only=False``
    to force loading the full system (e.g. if you need lipids or ions).

    SMB caveat: the first frame read inside MDA's reader sometimes returns
    StopIteration on a transiently slow SMB share.  We retry up to
    ``retries`` times before giving up.
    """
    import time
    f = cond.files()
    if protein_only is None:
        protein_only = cond.has_protein_only()
    if protein_only:
        top = str(f["prot_pdb"])
        traj = str(f["prot_xtc"])
    else:
        topf = f["tpr"] if f["tpr"].exists() else f["gro"]
        trajf = f["xtc_centered"] if (centered and f["xtc_centered"].exists()) else f["xtc"]
        if not trajf.exists():
            raise FileNotFoundError(f"No production trajectory at {trajf}")
        top, traj = str(topf), str(trajf)

    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            return mda.Universe(top, traj)
        except (StopIteration, OSError) as e:
            last_exc = e
            print(f"  [retry] universe open failed for {cond.label} "
                  f"(attempt {attempt+1}/{retries}): {type(e).__name__}: {e}",
                  flush=True)
            time.sleep(retry_wait_s)
    raise RuntimeError(
        f"Failed to open Universe for {cond.label} after {retries} attempts"
    ) from last_exc


def info(cond: Condition, centered: bool = True) -> TrajInfo:
    u = universe(cond, centered=centered)
    n = u.trajectory.n_frames
    dt = float(u.trajectory.dt)        # ps
    return TrajInfo(
        n_frames=n,
        n_atoms=u.atoms.n_atoms,
        dt_ps=dt,
        total_ns=n * dt / 1000.0,
    )


def equil_cut(cond: Condition, drop_ns: float = 50.0) -> int:
    """First frame index to KEEP — i.e. drop the first ``drop_ns`` of the run.

    ChACRA-style analysis assumes equilibrated contact statistics.  Discarding
    the first ~50 ns of each NPT run is a safe default for this membrane-
    protein system; tighten or loosen per-state after looking at NPT-RMSD.xvg.
    """
    u = universe(cond)
    dt_ps = float(u.trajectory.dt)
    return max(0, int(round(drop_ns * 1000.0 / dt_ps)))


def write_protein_xtc(cond: Condition, out: Path, stride: int = 1, drop_ns: float = 50.0):
    """Stream a protein-only XTC suitable for getcontacts (atomistic) or
    distance contact analysis (CG).  Drops first ``drop_ns`` and applies
    ``stride``.
    """
    u = universe(cond, centered=True)
    sel = u.select_atoms("protein")
    start = equil_cut(cond, drop_ns=drop_ns)
    out.parent.mkdir(parents=True, exist_ok=True)
    with mda.Writer(str(out), n_atoms=sel.n_atoms) as w:
        for ts in u.trajectory[start::stride]:
            w.write(sel)


def write_protein_pdb(cond: Condition, out: Path):
    """Single-frame protein PDB — needed as the topology argument to getcontacts."""
    u = universe(cond, centered=True)
    sel = u.select_atoms("protein")
    out.parent.mkdir(parents=True, exist_ok=True)
    sel.write(str(out))
