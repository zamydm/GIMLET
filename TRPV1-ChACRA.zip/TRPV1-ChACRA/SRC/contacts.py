"""
Per-state contact extraction for atomistic trajectories.

Uses the ``getcontacts`` toolset (already a dependency of ChACRA) to compute
dynamic contacts and convert them to per-pair frequencies.  One TSV per
(T, salt) state lands in ``outputs/freqs/atom/freqs_<state>.tsv``.

This mirrors what ``chacra/scripts/get_state_contacts.py`` does for HREMD
states — just keyed on our (T, salt) labels instead of replica index.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from .conditions import Condition
from . import config, trajectory_io


def have_getcontacts() -> bool:
    return shutil.which("get-dynamic-contacts") is not None and \
           shutil.which("get-contact-frequencies") is not None


def state_outputs(cond: Condition) -> dict[str, Path]:
    base = config.OUTPUTS
    sub = "atom" if cond.resolution == "atom" else "cg"
    return {
        "protein_pdb": base / "contacts" / sub / f"{cond.label}_protein.pdb",
        "protein_xtc": base / "contacts" / sub / f"{cond.label}_protein.xtc",
        "contacts": base / "contacts" / sub / f"cont_{cond.label}.tsv",
        "freqs":    base / "freqs"    / sub / f"freqs_{cond.label}.tsv",
    }


def prepare_inputs(cond: Condition, stride: int = 1, drop_ns: float = 50.0) -> dict[str, Path]:
    """Write per-state protein-only PDB + XTC if not already present."""
    out = state_outputs(cond)
    if not out["protein_pdb"].exists():
        trajectory_io.write_protein_pdb(cond, out["protein_pdb"])
    if not out["protein_xtc"].exists():
        trajectory_io.write_protein_xtc(cond, out["protein_xtc"], stride=stride, drop_ns=drop_ns)
    return out


def run_dynamic_contacts(cond: Condition, n_jobs: int = 8, itypes: str = "all") -> Path:
    """Run get-dynamic-contacts on the protein-only XTC for one state."""
    if not have_getcontacts():
        raise RuntimeError("getcontacts CLI not on PATH — activate the chacra-env conda env.")
    out = state_outputs(cond)
    out["contacts"].parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "get-dynamic-contacts",
        "--topology", str(out["protein_pdb"]),
        "--trajectory", str(out["protein_xtc"]),
        "--output", str(out["contacts"]),
        "--cores", str(n_jobs),
        "--itypes", itypes,
        "--sele", "protein",
        "--sele2", "protein",
    ]
    subprocess.run(cmd, check=True)
    return out["contacts"]


def run_contact_frequencies(cond: Condition) -> Path:
    out = state_outputs(cond)
    out["freqs"].parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "get-contact-frequencies",
        "--input_files", str(out["contacts"]),
        "--output_file", str(out["freqs"]),
    ]
    subprocess.run(cmd, check=True)
    return out["freqs"]


def process_state(cond: Condition, stride: int = 1, drop_ns: float = 50.0,
                  n_jobs: int = 8) -> Path:
    """End-to-end per-state pipeline: inputs → dynamic contacts → frequencies."""
    prepare_inputs(cond, stride=stride, drop_ns=drop_ns)
    if not state_outputs(cond)["contacts"].exists():
        run_dynamic_contacts(cond, n_jobs=n_jobs)
    return run_contact_frequencies(cond)
