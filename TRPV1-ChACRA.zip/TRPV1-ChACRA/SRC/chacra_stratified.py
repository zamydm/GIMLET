"""
Salt-stratified ChACRA.

Instead of one PCA over the full 2D (T × salt) grid, run *three* independent
ChACRAs — one per salt level — each a proper temperature-axis PCA over the
6 temperatures at that fixed ionic strength.

Why this framing
----------------
With only 3 salt levels a 2D PCA's "salt axis" is statistically thin (any
monotonic 3-point trend fits R²~1).  But 6 temperatures per salt slice is a
well-sampled ChACRA in its own right.  Stratifying lets us ask the more
defensible question:

    *How does salt modulate the temperature-sensitive contact mode?*

ChACRA's ``ContactPCA`` orients PC1 to a negative-slope (melting) trend, so
PC1 loadings are sign-consistent across the three slices and directly
comparable.

Outputs
-------
``run`` returns a dict keyed by salt_mM with, per slice:
  - ``cpca``      : the ContactPCA object
  - ``loadings``  : PC1..PCn loadings (contacts × PC)
  - ``pc1_proj``  : PC1 projection vs temperature (6 values)
  - ``pc1_var``   : variance fraction on PC1
  - ``pc1_r2T``   : R² of PC1 projection vs T (linear)
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import linregress

from . import config, frequencies
from .conditions import Condition, discover


def _slice_conditions(salt_code: str) -> list[Condition]:
    """All atomistic conditions at one salt level, sorted by T."""
    conds = [c for c in discover("atom") if c.salt_code == salt_code]
    return sorted(conds, key=lambda c: c.T)


def run(salt_codes: list[str] | None = None,
        n_permutations: int = 1000, n_jobs: int = 4) -> dict:
    """
    Run a temperature-axis ChACRA at each salt level.

    Parameters
    ----------
    salt_codes : list[str] | None
        Which salt levels to process.  Default: all present on disk.
    n_permutations, n_jobs : passed to ContactPCA significance test.

    Returns
    -------
    dict[int, dict]   keyed by salt_mM
    """
    from chacra.ContactFrequencies import ContactPCA

    if salt_codes is None:
        salt_codes = sorted({c.salt_code for c in discover("atom")})

    results: dict[int, dict] = {}
    for salt_code in salt_codes:
        conds = _slice_conditions(salt_code)
        if len(conds) < 3:
            print(f"[skip] salt {salt_code}: only {len(conds)} temperatures")
            continue
        salt_mM = conds[0].salt_mM
        temps = [c.T for c in conds]

        # Build C4-symmetry-averaged matrix for this salt slice only.
        df = frequencies.build_matrix(conds, resolution="atom", symmetry_average=True)
        # df index is MultiIndex(T, salt); flatten to a 1-D T index.
        df = df.copy()
        df.index = temps

        cpca = ContactPCA(df, significance_test=True,
                          N_permutations=n_permutations, n_jobs=n_jobs)

        pc1_proj = cpca._transform[:, 0]
        lr = linregress(temps, pc1_proj)
        pc1_var = float(cpca.pca.explained_variance_ratio_[0])

        results[salt_mM] = {
            "salt_code": salt_code,
            "temps": temps,
            "cpca": cpca,
            "loadings": cpca.loadings.copy(),
            "pc1_proj": pc1_proj,
            "pc1_var": pc1_var,
            "pc1_r2T": float(lr.rvalue ** 2),
            "pc1_slope": float(lr.slope),
            "freqs": df,
        }
        print(f"[salt {salt_mM:>3} mM]  PC1 var={pc1_var:.1%}  "
              f"R²(T)={lr.rvalue**2:.2f}  slope={lr.slope:+.3f}  "
              f"({df.shape[1]} contacts)")

    return results


def aligned_pc1_loadings(results: dict, pc: int = 1) -> pd.DataFrame:
    """
    Build a (contact × salt) DataFrame of PC loadings, aligned on the union
    of contacts across all salt slices.  Missing contacts → NaN.
    """
    series = {}
    for salt_mM, r in results.items():
        col = f"PC{pc}"
        if col in r["loadings"].columns:
            series[salt_mM] = r["loadings"][col]
    df = pd.DataFrame(series)
    df.columns = [f"{s}mM" for s in df.columns]
    return df


def residue_sensitivity(results: dict, pc: int = 1,
                        agg: str = "max") -> pd.DataFrame:
    """
    Aggregate contact PC-loadings to per-residue temperature-sensitivity at
    each salt level.

    For each residue, take ``agg`` (max or sum) of |loading| over all
    contacts that residue participates in, at each salt.

    Returns
    -------
    pd.DataFrame  index = residue id ("CHAIN:RESN:RESID"), columns = salts.
    """
    import re
    pat = re.compile(r"^([A-Z]:[A-Z]+:\d+)-([A-Z]:[A-Z]+:\d+)$")

    per_salt = {}
    for salt_mM, r in results.items():
        col = f"PC{pc}"
        load = r["loadings"][col].abs()
        res_vals: dict[str, list[float]] = {}
        for contact, val in load.items():
            m = pat.match(contact)
            if not m:
                continue
            for res in m.groups():
                res_vals.setdefault(res, []).append(val)
        if agg == "max":
            per_salt[f"{salt_mM}mM"] = {k: max(v) for k, v in res_vals.items()}
        else:
            per_salt[f"{salt_mM}mM"] = {k: sum(v) for k, v in res_vals.items()}
    return pd.DataFrame(per_salt).fillna(0.0)
