"""
Pure-MDAnalysis residue-pair contact frequencies.

Drop-in replacement for ``getcontacts`` when (a) the chacra-env install
isn't available, and (b) we don't need atom-typed interaction tags
(H-bond / salt-bridge / vdW); ChACRA's PCA only consumes contact
*frequencies*, so a distance-cutoff definition is fine.

A residue pair is "in contact" in a frame if any pair of selected atoms
between the two residues is within ``cutoff_A``.  Default selections:

  - atomistic: heavy atoms (``not name H*``), 4.5 Å cutoff
  - CG (Martini): all beads, 6.0 Å cutoff

Output schema matches the getcontacts ``freqs_<state>.tsv`` (pair string
``CHAIN:RESN:RESID-CHAIN:RESN:RESID`` with one frequency value), so the
downstream aggregation/PCA code is identical for both backends.
"""
from __future__ import annotations

import time
from pathlib import Path

import MDAnalysis as mda
import numpy as np
import pandas as pd
from MDAnalysis.lib.distances import self_capped_distance

from .conditions import Condition
from . import config, trajectory_io


def _residue_id(res) -> str:
    return f"{res.segid}:{res.resname}:{res.resid}"


def compute_contact_freqs(
    cond: Condition,
    *,
    selection: str,
    cutoff_A: float,
    stride: int = 1,
    drop_ns: float = 50.0,
    min_seq_sep: int = 2,
    verbose: bool = True,
) -> pd.DataFrame:
    """
    Stream the (protein-only, centered) trajectory and return a DataFrame
    of residue-pair contact frequencies.

    Returns a DataFrame indexed by ``"resA-resB"`` with one
    ``contact_frequency`` column.
    """
    t0 = time.time()
    u = trajectory_io.universe(cond)            # auto-uses NPTProteinCenter.* if present
    sel = u.select_atoms(selection)
    if sel.n_atoms == 0:
        raise ValueError(f"selection '{selection}' returned 0 atoms for {cond.label}")
    residues = list(sel.residues)
    res_ids = [_residue_id(r) for r in residues]
    n_res = len(residues)

    # Map sel-local atom index → residue index in the residues list above.
    atom_to_res = np.empty(sel.n_atoms, dtype=np.int32)
    for i, r in enumerate(residues):
        local_idx = np.searchsorted(sel.indices, r.atoms.indices)
        atom_to_res[local_idx] = i

    counts = np.zeros((n_res, n_res), dtype=np.int64)
    start = trajectory_io.equil_cut(cond, drop_ns=drop_ns)
    n_used = 0
    for ts in u.trajectory[start::stride]:
        pairs = self_capped_distance(
            sel.positions, max_cutoff=cutoff_A,
            box=ts.dimensions, return_distances=False,
        )
        n_used += 1
        if len(pairs) == 0:
            continue
        ri = atom_to_res[pairs[:, 0]]
        rj = atom_to_res[pairs[:, 1]]
        mask = ri != rj
        if not mask.any():
            continue
        ri, rj = ri[mask], rj[mask]
        lo = np.minimum(ri, rj); hi = np.maximum(ri, rj)
        flat = lo.astype(np.int64) * n_res + hi.astype(np.int64)
        flat = np.unique(flat)
        lo = flat // n_res; hi = flat % n_res
        counts[lo, hi] += 1
        if verbose and n_used % 1000 == 0:
            print(f"    {cond.label}  {n_used} frames processed  "
                  f"({(time.time()-t0):.0f}s)", flush=True)

    freqs = counts / max(n_used, 1)
    pi, pj = np.where(freqs > 0)
    rows = []
    for i, j in zip(pi, pj):
        ra, rb = residues[i], residues[j]
        if ra.segid == rb.segid and abs(ra.resid - rb.resid) < min_seq_sep:
            continue
        rows.append((res_ids[i], res_ids[j], float(freqs[i, j])))
    df = pd.DataFrame(rows, columns=["residue_1", "residue_2", "contact_frequency"])
    df["pair"] = df["residue_1"] + "-" + df["residue_2"]
    if verbose:
        elapsed = time.time() - t0
        print(f"  [done] {cond.label}: {n_used} frames, "
              f"{len(df)} contacts in {elapsed:.0f}s "
              f"({n_used/max(elapsed,1):.0f} fps)", flush=True)
    return df.set_index("pair")[["contact_frequency"]]


def write_freqs_tsv(df: pd.DataFrame, path: Path, header: str = ""):
    """ChACRA's ``load_contact_file`` skips 2 header lines, then expects
    tab-separated ``residue_1, residue_2, contact_frequency``."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as fh:
        fh.write(f"# {header}\n")
        fh.write("# residue_1\tresidue_2\tcontact_frequency\n")
        d = df.copy()
        d["residue_1"] = [p.split("-", 1)[0] for p in d.index]
        d["residue_2"] = [p.split("-", 1)[1] for p in d.index]
        d[["residue_1", "residue_2", "contact_frequency"]].to_csv(
            fh, sep="\t", header=False, index=False,
        )


def write_state_freqs_atom(cond: Condition, **kwargs) -> Path:
    """Atomistic defaults: heavy atoms within 4.5 Å."""
    out = config.OUTPUTS / "freqs" / "atom" / f"freqs_{cond.label}.tsv"
    if out.exists():
        return out
    df = compute_contact_freqs(
        cond,
        selection=kwargs.pop("selection", "protein and not name H*"),
        cutoff_A=kwargs.pop("cutoff_A", 4.5),
        drop_ns=kwargs.pop("drop_ns", 50.0),
        **kwargs,
    )
    write_freqs_tsv(df, out, header=f"atom heavy-atom 4.5A contacts for {cond.label}")
    return out


def write_state_freqs_cg(cond: Condition, **kwargs) -> Path:
    """CG (Martini) defaults: all beads within 6.0 Å."""
    out = config.OUTPUTS / "freqs" / "cg" / f"freqs_{cond.label}.tsv"
    if out.exists():
        return out
    df = compute_contact_freqs(
        cond,
        selection=kwargs.pop("selection", "protein"),
        cutoff_A=kwargs.pop("cutoff_A", 6.0),
        drop_ns=kwargs.pop("drop_ns", 100.0),
        **kwargs,
    )
    write_freqs_tsv(df, out, header=f"CG bead 6A contacts for {cond.label}")
    return out
