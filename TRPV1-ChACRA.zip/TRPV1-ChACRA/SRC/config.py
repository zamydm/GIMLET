"""
Project-wide paths and the (T, salt) grid we know is on disk.

DATA_PATH.txt at the project root holds the absolute path to the simulation
root (the SMB-mounted lab volume), so the rest of the code stays portable
across machines.
"""
from __future__ import annotations

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_ROOT = Path((PROJECT_ROOT / "DATA_PATH.txt").read_text().strip())

OUTPUTS = PROJECT_ROOT / "outputs"
MATERIALS = PROJECT_ROOT / "materials"

# Sub-trees under DATA_ROOT that hold completed production runs.
ATOM_DIRS = ["Atomistic", "AtomisticCompletedV1"]   # Atomistic = current 18-state dataset
CG_DIRS = ["Coarse"]   # Martini 3, 4 us/state, 18 conditions (tree reorganized 2026-05)

# Per-state file naming inside each <DATA_ROOT>/<set>/<TKkSS>/.
PROD_XTC = "NPT.xtc"                     # full system trajectory
PROD_XTC_CENTERED = "NPT-Center.xtc"     # legacy V1 centered name
PROD_TPR = "NPT.tpr"
PROD_GRO = "NPT.gro"

# The current Atomistic/ tree ships pre-extracted protein-only centered files
# alongside the system trajectory.  Vastly faster to stream over SMB.
PROT_XTC = "NPTProteinCenter.xtc"
PROT_PDB = "NPTProteinCenter.pdb"
PROT_GRO = "NPTProteinCenter.gro"

# Salt-code → nominal mM (from comparing topology ion counts; verify with student).
SALT_MM = {"00": 0, "05": 50, "10": 100, "15": 150}

# Expected grid (verified on-disk via stat at project setup). ``discover()``
# is the source of truth at runtime.
#
# Atomistic/ (current dataset, pre-extracted protein-only XTCs):
#   6 T × 3 salt = 18 states, uniform 5 K spacing.
ATOM_GRID_EXPECTED = {
    "T": [305, 310, 315, 320, 325, 330],
    "salt": ["05", "10", "15"],
}
# CG (Martini 3) — same 6 T × 3 salt grid as atomistic, but 4 us/state.
CG_GRID_EXPECTED = {
    "T": [305, 310, 315, 320, 325, 330],
    "salt": ["05", "10", "15"],
}

# Reference structure (atomistic) for visualization & residue mapping.
# Use the per-state protein PDB if the central reference is unavailable.
REF_PDB = DATA_ROOT / "Protein" / "8GFARepairCenter.pdb"
REF_PDB_FALLBACK = "NPTProteinCenter.pdb"   # exists in every Atomistic/<state>/

# TRPV1 chains.  4-fold symmetric homotetramer (PROA/B/C/D in the topology).
CHAINS = ["A", "B", "C", "D"]
