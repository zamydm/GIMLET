"""
Fast C4 chain-symmetry averaging for TRPV1 (and any C4 homotetramer with
chains labelled A, B, C, D in cyclic order around the symmetry axis).

For ChACRA's full ``average_multimer`` we'd determine chain equivalence by
inertial-axis rotation matching, which is general but slow on ~15k contacts.
For a tetramer with ideal C4 symmetry, chain equivalence is fixed by topology:

  * **Self contacts** (intra-subunit, both endpoints in the same chain):
    {A-A, B-B, C-C, D-D}.  4 equivalent copies.
  * **Adjacent inter-subunit** (one chain pair removed in the C4 cycle):
    {(A,B), (B,C), (C,D), (D,A)}.  4 equivalent copies.
  * **Diagonal inter-subunit** (across the channel):
    {(A,C), (B,D)}.  2 equivalent copies.

Anything else (e.g. (A,B) where the structure is C2 rather than C4) won't
produce a clean tetramer, but for TRPV1 (PDB 8GFA) C4 is the textbook
arrangement.
"""
from __future__ import annotations

import re
from collections import defaultdict

import pandas as pd

# Cyclic order around the channel axis (looking down the pore from outside).
_C4_ORDER = ["A", "B", "C", "D"]

_CONTACT_RE = re.compile(
    r"^([A-Z]):([A-Z]+):(\d+)-([A-Z]):([A-Z]+):(\d+)$"
)


def _parse(pair: str):
    m = _CONTACT_RE.match(pair)
    if not m:
        return None
    chA, rnA, riA, chB, rnB, riB = m.groups()
    return chA, rnA, int(riA), chB, rnB, int(riB)


def _chain_class(chA: str, chB: str) -> str | None:
    """Return one of 'self', 'adj', 'diag' or None for a chain pair."""
    if chA not in _C4_ORDER or chB not in _C4_ORDER:
        return None
    if chA == chB:
        return "self"
    iA, iB = _C4_ORDER.index(chA), _C4_ORDER.index(chB)
    sep = abs(iA - iB) % 4
    if sep == 1 or sep == 3:
        return "adj"
    if sep == 2:
        return "diag"
    return None


def _canonicalize(chA, rnA, riA, chB, rnB, riB) -> str:
    """Map a contact to its canonical chain-A representative.

    For a C4 tetramer with cyclic order A→B→C→D→A:

      - **self** contacts (chA == chB): canonical pair = ``A:rnA:riA-A:rnB:riB``
      - **adjacent** (sep=1 or 3): canonical pair = ``A:?:?-B:?:?`` where the
        residue named first is the one whose chain is "earlier" in the cycle.
      - **diagonal** (sep=2): canonical pair = ``A:?:?-C:?:?``.

    The residue order within a pair is set so that the canonical chain (A)
    holds the resname/resid coming from whichever chain mapped to A under
    the rotation.
    """
    cls = _chain_class(chA, chB)
    if cls is None:
        return None

    if cls == "self":
        # Both endpoints in same chain.  Sort by (resid, resname).
        key1 = (riA, rnA)
        key2 = (riB, rnB)
        if key1 <= key2:
            return f"A:{rnA}:{riA}-A:{rnB}:{riB}"
        else:
            return f"A:{rnB}:{riB}-A:{rnA}:{riA}"

    if cls == "diag":
        # (A,C), (B,D) → canonical (A,C).  Pick the AB-side residue first.
        # The residue in the "earlier" chain in the cycle goes onto A.
        iA, iB = _C4_ORDER.index(chA), _C4_ORDER.index(chB)
        if iA < iB:
            return f"A:{rnA}:{riA}-C:{rnB}:{riB}"
        else:
            return f"A:{rnB}:{riB}-C:{rnA}:{riA}"

    # Adjacent: cycle indices differ by 1 (mod 4).  Order so that the
    # "lower" cycle index goes onto A, the next one onto B.
    iA, iB = _C4_ORDER.index(chA), _C4_ORDER.index(chB)
    # The pair (A,B), (B,C), (C,D), (D,A) all have one direction going
    # +1 mod 4 and the other -1.  Use whichever direction is +1 mod 4 so
    # the "first" residue is the +1-step source.
    if (iB - iA) % 4 == 1:        # chA→chB is forward
        return f"A:{rnA}:{riA}-B:{rnB}:{riB}"
    elif (iA - iB) % 4 == 1:      # chB→chA is forward
        return f"A:{rnB}:{riB}-B:{rnA}:{riA}"
    else:
        # Shouldn't happen in a true C4 tetramer.
        return None


def c4_symmetry_average(df: pd.DataFrame) -> pd.DataFrame:
    """
    Collapse every contact across the 4 chains into its C4-equivalence
    representative.  Each averaged contact is the mean of the 2 or 4
    chain-equivalent copies that exist in the input.

    Parameters
    ----------
    df : pd.DataFrame
        rows = states, columns = contact pairs ``CHAIN:RESN:RESID-CHAIN:RESN:RESID``.

    Returns
    -------
    pd.DataFrame with the same rows and reduced columns (~4× fewer for an
    ideal tetramer).  Contact frequencies in any state that is missing the
    contact are treated as 0 (matching ChACRA convention).
    """
    groups: dict[str, list[str]] = defaultdict(list)
    skipped = 0
    for col in df.columns:
        parts = _parse(col)
        if parts is None:
            skipped += 1
            continue
        canon = _canonicalize(*parts)
        if canon is None:
            skipped += 1
            continue
        groups[canon].append(col)

    out = {
        canon: df[cols].mean(axis=1)
        for canon, cols in groups.items()
    }
    avg = pd.DataFrame(out)
    avg.index = df.index
    avg.columns.name = None
    if skipped:
        print(f"[c4_avg] skipped {skipped} contacts that didn't match the C4 chain pattern")
    return avg


def c4_class_counts(df: pd.DataFrame) -> dict[str, int]:
    """Diagnostic: count how many input columns fall in each chain class."""
    cnt = defaultdict(int)
    for col in df.columns:
        parts = _parse(col)
        if parts is None:
            cnt["unparsable"] += 1
            continue
        cls = _chain_class(parts[0], parts[3])
        cnt[cls or "other"] += 1
    return dict(cnt)
