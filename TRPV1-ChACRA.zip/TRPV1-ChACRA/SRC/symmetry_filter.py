"""
C4-symmetry consistency filter for tetrameric-channel contact data.

Rationale
---------
TRPV1 is a C4 homotetramer, so every contact has 2 (diagonal) or 4
(self / adjacent) symmetry-equivalent copies that *must* have the same
frequency in a converged ensemble.  Single-trajectory straight-MD runs can
get kinetically trapped so that one subunit interface forms a contact the
other three don't — broken C4 symmetry.  Such contacts (e.g. R617–D655,
which appears in only 1 of 4 interfaces) are sampling artifacts, yet the
plain C4 *average* masks them (0.9, 0, 0, 0 → 0.225) and PCA then mistakes
their noise for signal.

This module turns the tetramer's symmetry into an artifact detector: keep
only contacts whose symmetric copies are mutually *present and consistent*;
drop the symmetry-broken ones before PCA.

A contact's consistency, per state with signal, is the fraction of its
symmetric copies that are "present" (above both an absolute floor and a
fraction of that state's strongest copy).  We summarise over signal states
by the median.  A real symmetric contact scores ~1.0; an R617–D655-type
artifact scores ~0.25 (1 of 4).
"""
from __future__ import annotations

from collections import defaultdict

import numpy as np
import pandas as pd

from .c4_average import _parse, _canonicalize, _chain_class


def expected_copies(canonical: str) -> int:
    """Number of C4-symmetric copies a canonical contact *should* have:
    4 for self (intra-subunit) and adjacent inter-subunit pairs, 2 for the
    across-channel diagonal pairs."""
    p = _parse(canonical)
    if p is None:
        return 4
    cls = _chain_class(p[0], p[3])
    return 2 if cls == "diag" else 4


def symmetry_groups(columns) -> dict[str, list[str]]:
    """Map each canonical contact → list of its present symmetric-copy columns."""
    groups: dict[str, list[str]] = defaultdict(list)
    for col in columns:
        parts = _parse(col)
        if parts is None:
            continue
        canon = _canonicalize(*parts)
        if canon is None:
            continue
        groups[canon].append(col)
    return groups


def consistency_scores(
    raw_df: pd.DataFrame,
    signal_thresh: float = 0.2,
    abs_floor: float = 0.1,
    rel_floor: float = 0.3,
) -> pd.DataFrame:
    """
    For each canonical contact, score how symmetrically its copies behave.

    Parameters
    ----------
    raw_df : (state × raw-contact) frequencies, BEFORE C4 averaging.
    signal_thresh : a state "has signal" for a contact if its strongest
        symmetric copy exceeds this.
    abs_floor, rel_floor : a copy counts as "present" in a state if its
        frequency exceeds both ``abs_floor`` and ``rel_floor × (max copy)``.

    Returns
    -------
    DataFrame indexed by canonical contact with columns:
      n_copies      number of symmetric copies seen in the data
      n_signal      number of states with signal
      consistency   median fraction-of-copies-present over signal states
                    (1.0 = perfectly symmetric, 0.25 = 1-of-4 artifact)
    """
    groups = symmetry_groups(raw_df.columns)
    rows = {}
    for canon, cols in groups.items():
        sub = raw_df[cols].to_numpy()              # (n_states, n_observed_copies)
        exp = expected_copies(canon)               # denominator: copies that SHOULD exist
        maxc = sub.max(axis=1)
        sig = maxc > signal_thresh
        if sig.sum() == 0:
            rows[canon] = (sub.shape[1], exp, 0, np.nan)
            continue
        thr = np.maximum(abs_floor, rel_floor * maxc)[:, None]
        present = sub > thr
        # fraction of EXPECTED copies present (missing interfaces → not columns
        # → contribute 0 to numerator but exp keeps the denominator honest)
        frac = present.sum(axis=1) / exp
        rows[canon] = (sub.shape[1], exp, int(sig.sum()), float(np.median(frac[sig])))
    out = pd.DataFrame.from_dict(
        rows, orient="index",
        columns=["n_observed", "n_expected", "n_signal", "consistency"],
    )
    return out


def filtered_average(
    raw_df: pd.DataFrame,
    min_consistency: float = 0.5,
    **score_kwargs,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build a C4-averaged matrix keeping only symmetry-consistent contacts.

    Returns
    -------
    (avg_df, scores)
      avg_df : (state × canonical-contact) averaged over present copies,
               restricted to contacts with consistency ≥ min_consistency.
      scores : the full consistency table (for diagnostics).
    """
    scores = consistency_scores(raw_df, **score_kwargs)
    groups = symmetry_groups(raw_df.columns)
    keep = scores.index[(scores["consistency"] >= min_consistency).fillna(False)]
    data = {canon: raw_df[groups[canon]].mean(axis=1) for canon in keep}
    avg = pd.DataFrame(data, index=raw_df.index)
    avg.columns.name = None
    return avg, scores
