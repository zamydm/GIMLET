"""
2D-ChACRA: PCA on a (T, salt) state grid + post-hoc decomposition of each
chacra into temperature- and salt-responsive components.

The student's data is straight MD on a 2D (T, [NaCl]) grid, not HREMD on a
1D temperature ladder.  We can still apply ChACRA's PCA — the principal
components of contact frequencies still pick up the chemically meaningful
collective modes — but the PC scores now live on a 2D grid, so we have to
decide *which axis* each chacra responds to.

Method
------
1. Build the contact-frequency matrix X (n_states × n_contacts), index =
   MultiIndex(T, salt_mM).
2. Fit PCA via ChACRA's ``ContactPCA`` (uses the same permutation
   significance test as the original method).
3. For each PC k, fit ``score_k ~ b0 + b_T * T + b_S * salt``.
   - Partial R² on T identifies temperature-driven chacras (the classical
     "melting" mode lives here).
   - Partial R² on salt identifies salt-driven chacras (electrostatic /
     surface effects; expected to be strongest near pore-facing residues
     and the outer leaflet headgroup region).
   - Both significant → coupled modes (these are the most interesting:
     contacts whose temperature response is *gated* by ionic environment).
4. Write a CSV of (PC, var_explained, b_T, b_S, R²_T, R²_S, classification).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression


@dataclass
class ModeDecomp:
    pc: int
    var_explained: float
    b_T: float
    b_salt: float
    r2_T_partial: float       # gain in joint linear fit from adding T
    r2_salt_partial: float    # gain in joint linear fit from adding salt
    r2_full: float            # full bivariate linear fit
    r2_T_marginal: float      # R² of PC_avg_over_salt(T) ~ T (smoothed)
    r2_salt_marginal: float   # R² of PC_avg_over_T(salt) ~ salt (smoothed)
    label: str   # "T", "salt", "coupled", "neither"


def _partial_r2(y, X_full, X_drop) -> float:
    """R² gained by adding the dropped column to a model that already has the
    rest.  Equivalent to a partial F-style decomposition for one regressor."""
    if X_drop.shape[1] == X_full.shape[1]:
        return 0.0
    full = LinearRegression().fit(X_full, y).score(X_full, y)
    reduced = LinearRegression().fit(X_drop, y).score(X_drop, y) if X_drop.shape[1] else 0.0
    return max(0.0, full - reduced)


def _marginal_r2(y: np.ndarray, group: np.ndarray) -> float:
    """R² of (group-mean of y) vs (sorted unique group values), as a 1D
    linear fit.  Captures monotonic dependence after smoothing over the
    other grid axis.
    """
    levels = np.unique(group)
    if len(levels) < 2:
        return 0.0
    means = np.array([y[group == g].mean() for g in levels])
    return LinearRegression().fit(levels.reshape(-1, 1), means).score(
        levels.reshape(-1, 1), means
    )


def decompose_modes(scores: np.ndarray, T: np.ndarray, salt: np.ndarray,
                    var_explained: np.ndarray,
                    r2_thresh: float = 0.5) -> list[ModeDecomp]:
    """Classify each PC as T-driven, salt-driven, coupled, or neither.

    We use the **marginal** R²s (PC vs T after averaging over salt, and
    vice versa) for classification — these are robust to within-cell
    noise from finite sampling.  The full bivariate R² is reported but
    not used for labelling.

    Parameters
    ----------
    scores : (n_states, n_pc) array of PC projections.
    T, salt : (n_states,) arrays.
    var_explained : (n_pc,) explained-variance ratio from PCA.
    r2_thresh : float
        Threshold on the **marginal** R² (default 0.5).
    """
    T = np.asarray(T, dtype=float)
    salt = np.asarray(salt, dtype=float)
    X_full = np.column_stack([T, salt])
    X_T_only = T.reshape(-1, 1)
    X_S_only = salt.reshape(-1, 1)

    out: list[ModeDecomp] = []
    for k in range(scores.shape[1]):
        y = scores[:, k]
        reg_full = LinearRegression().fit(X_full, y)
        r2_full = reg_full.score(X_full, y)
        b_T, b_S = reg_full.coef_
        r2_T_partial = _partial_r2(y, X_full, X_S_only)
        r2_S_partial = _partial_r2(y, X_full, X_T_only)
        r2_T_marg = _marginal_r2(y, T)
        r2_S_marg = _marginal_r2(y, salt)

        if r2_T_marg >= r2_thresh and r2_S_marg >= r2_thresh:
            label = "coupled"
        elif r2_T_marg >= r2_thresh:
            label = "T"
        elif r2_S_marg >= r2_thresh:
            label = "salt"
        else:
            label = "neither"
        out.append(ModeDecomp(
            pc=k + 1, var_explained=float(var_explained[k]),
            b_T=float(b_T), b_salt=float(b_S),
            r2_T_partial=float(r2_T_partial), r2_salt_partial=float(r2_S_partial),
            r2_full=float(r2_full),
            r2_T_marginal=float(r2_T_marg), r2_salt_marginal=float(r2_S_marg),
            label=label,
        ))
    return out


def run(freq_df: pd.DataFrame, n_permutations: int = 1000, n_jobs: int = 4,
        r2_thresh: float = 0.5):
    """
    Run ChACRA PCA + 2D decomposition.

    Parameters
    ----------
    freq_df : pd.DataFrame
        Output of ``frequencies.build_matrix``.  MultiIndex(T_K, salt_mM).
    n_permutations, n_jobs : passed through to ChACRA's permutation test.
    r2_thresh : threshold for mode classification.

    Returns
    -------
    dict with keys ``"cf"`` (the ContactFrequencies object), ``"scores"``
    (DataFrame indexed by state), ``"loadings"`` (DataFrame indexed by
    contact pair), ``"decomp"`` (DataFrame of ModeDecomp results).
    """
    # Lazy import so this module is usable without the full chacra-env.
    from chacra.ContactFrequencies import ContactFrequencies

    flat = freq_df.copy()
    flat.index = [f"{t}K_{s}mM" for (t, s) in flat.index]   # ChACRA wants 1-D index

    cf = ContactFrequencies(
        flat, get_chacras=True, N_permutations=n_permutations, n_jobs=n_jobs,
    )
    cpca = cf.cpca

    scores = pd.DataFrame(
        cpca._transform,
        index=freq_df.index,
        columns=[f"PC{i+1}" for i in range(cpca._transform.shape[1])],
    )
    loadings = cpca.loadings.copy()

    T = freq_df.index.get_level_values("T_K").to_numpy(dtype=float)
    salt = freq_df.index.get_level_values("salt_mM").to_numpy(dtype=float)
    decomp = decompose_modes(
        cpca._transform, T, salt,
        cpca.pca.explained_variance_ratio_, r2_thresh=r2_thresh,
    )
    decomp_df = pd.DataFrame([d.__dict__ for d in decomp]).set_index("pc")
    return {"cf": cf, "scores": scores, "loadings": loadings, "decomp": decomp_df}
