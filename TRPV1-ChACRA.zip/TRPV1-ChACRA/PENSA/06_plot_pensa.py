"""
PENSA step 6: figure from pensa_ion_sites.json.

Top row : per-ion occupancy heatmap (ion pockets x salinity).  Pockets are
          ordered by axial position z (extracellular top, cytosolic bottom),
          measured from the membrane midplane of the alignment-reference frame
          (all-lipid-P midplane of 305K05, frame 2500), so the sites can be
          read against the channel.
Bottom  : per-ion Jensen-Shannon distance between salinities (mean over
          pockets) + the single most salt-sensitive pocket per pair.

Run with the llpsmd env (has src + MDAnalysis):
  /opt/miniconda3/envs/llpsmd-new/bin/python PENSA/06_plot_pensa.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path("/Users/potoyan/Library/CloudStorage/Box-Box/1_GROUP_data/TRPV1-analysis")
sys.path.insert(0, str(ROOT))
OUT = ROOT / "PENSA" / "outputs"

IONS = ["K", "Na", "Cl"]
ICOL = {"K": "#2166ac", "Na": "#b2182b", "Cl": "#7a7a7a"}
SALTS = [50, 100, 150]

mpl.rcParams.update({
    "font.family": "sans-serif", "font.size": 12, "axes.titlesize": 13,
    "axes.labelsize": 12, "xtick.labelsize": 11, "ytick.labelsize": 10,
    "legend.fontsize": 10, "axes.spines.top": False, "axes.spines.right": False,
})


ONE = {"ARG": "R", "LYS": "K", "ASP": "D", "GLU": "E", "TYR": "Y", "SER": "S",
       "THR": "T", "LEU": "L", "VAL": "V", "PHE": "F", "ALA": "A", "GLY": "G",
       "ILE": "I", "MET": "M", "CYS": "C", "ASN": "N", "GLN": "Q", "PRO": "P",
       "TRP": "W", "HIS": "H", "HSD": "H"}


def res_short(entry):
    """'GLY644:C(2.3Å)' -> 'G644'; '' -> '?'."""
    import re
    if not entry:
        return "?"
    m = re.match(r"([A-Z]{3})(\d+)", entry[0])
    return f"{ONE.get(m.group(1), m.group(1))}{m.group(2)}" if m else entry[0]


def reference_frame():
    """(z0 membrane midplane, axis_xy) of the alignment reference; None on failure."""
    try:
        from src.conditions import Condition
        from src import trajectory_io as tio
        u = tio.universe(Condition(T=305, salt_code="05", resolution="atom"),
                         centered=False, protein_only=False)
        u.trajectory[2500]
        pz = u.select_atoms("name P").positions[:, 2]
        m = pz.mean()
        z0 = 0.5 * (pz[pz > m].mean() + pz[pz < m].mean())
        axy = u.select_atoms("protein and name CA").positions[:, :2].mean(0)
        return float(z0), axy
    except Exception as e:
        print(f"[warn] reference frame read failed ({e}); using raw z", flush=True)
        return None, None


def main():
    data = json.loads((OUT / "pensa_ion_sites.json").read_text())
    resf = OUT / "pensa_pocket_residues.json"
    resmap = json.loads(resf.read_text()) if resf.exists() else {}
    z0, axy = reference_frame()

    fig = plt.figure(figsize=(13.5, 8.6))
    gs = fig.add_gridspec(2, 3, height_ratios=[1.35, 1.0], hspace=0.42, wspace=0.42,
                          left=0.08, right=0.97, top=0.9, bottom=0.09)

    for j, ion in enumerate(IONS):
        d = data[ion]
        xyz = np.array(d["sites_xyz"])
        zrel = xyz[:, 2] - z0 if z0 is not None else xyz[:, 2]
        order = np.argsort(-zrel)                      # extracellular (high z) at top
        occ = np.array([d["occupancy"][str(s)] for s in SALTS]).T[order]   # [pocket, salt]

        ax = fig.add_subplot(gs[0, j])
        im = ax.imshow(occ, aspect="auto", cmap="magma", vmin=0, vmax=1)
        ax.set_xticks(range(3)); ax.set_xticklabels([f"{s}" for s in SALTS])
        rlist = resmap.get(ion, [])
        def ylab(i):
            r = res_short(rlist[i]["nearest_residues"]) if i < len(rlist) else "?"
            return f"{r}  (z{zrel[i]:+.0f})"
        ax.set_yticks(range(len(order)))
        ax.set_yticklabels([ylab(i) for i in order])
        ax.set_xlabel("salinity (mM)")
        if j == 0:
            ax.set_ylabel("ion pocket: nearest residue (axial z, Å)\nextracellular → cytosolic")
        ax.set_title(f"{ion}$^{{{'+' if ion!='Cl' else '-'}}}$  pocket occupancy")
        for p in range(len(order)):
            for s in range(3):
                v = occ[p, s]
                ax.text(s, p, f"{v:.2f}", ha="center", va="center",
                        fontsize=8, color="white" if v < 0.6 else "black")
        if j == 2:
            cax = ax.inset_axes([1.06, 0.0, 0.05, 1.0])
            fig.colorbar(im, cax=cax, label="occupancy")

    # bottom: mean JSD per salinity pair, per ion
    axb = fig.add_subplot(gs[1, :])
    pairs = ["50v100", "50v150", "100v150"]
    xlab = ["50→100", "50→150", "100→150"]
    x = np.arange(len(pairs)); w = 0.26
    for k, ion in enumerate(IONS):
        means = [np.mean(data[ion]["jsd"][p]) for p in pairs]
        maxs = [np.max(data[ion]["jsd"][p]) for p in pairs]
        axb.bar(x + (k - 1) * w, means, w, color=ICOL[ion], label=f"{ion} (mean)")
        axb.plot(x + (k - 1) * w, maxs, "v", color=ICOL[ion], ms=7,
                 markeredgecolor="black", markeredgewidth=0.5)
    axb.set_xticks(x); axb.set_xticklabels(xlab)
    axb.set_ylabel("Jensen-Shannon distance\n(bar = mean, ▼ = most sensitive pocket)")
    axb.set_xlabel("salinity change (mM)")
    axb.set_title("ion-site occupancy divergence vs salinity")
    axb.legend(ncol=3, frameon=False, loc="upper left")

    fig.suptitle("PENSA ion-pocket densities and salinity divergence (TRPV1, 305 K)",
                 fontsize=15, fontweight="bold")
    out = OUT / "pensa_ion_density.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    print(f"saved {out}")

    # console summary
    print("\n# mean JSD (occupancy divergence) by ion and salinity pair")
    print(f"{'ion':>4} {'50v100':>8} {'50v150':>8} {'100v150':>8}")
    for ion in IONS:
        m = [np.mean(data[ion]["jsd"][p]) for p in pairs]
        print(f"{ion:>4} {m[0]:>8.3f} {m[1]:>8.3f} {m[2]:>8.3f}")


if __name__ == "__main__":
    main()
