"""
PENSA preliminary — step 1: feasibility probe (single condition).

The only trajectory that still contains ions is the full-system NPT.xtc
(~38 GB/condition, no cached offsets); the protein-only files used for
ChACRA stripped the ions.  Before designing an ion-density comparison we
must know:
  (1) read cost over SMB   — universe open, offset build, per-frame streaming
  (2) geometry             — is the pore axis == z (membrane normal)?
  (3) signal sufficiency   — do the few K+/Na+/Cl- ions actually visit the
                             channel vestibule, or is the pore essentially
                             never occupied in 400 ns?

Everything is timed and flushed so a partial run is still informative if the
SMB read is killed by a timeout.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path("/Users/potoyan/Library/CloudStorage/Box-Box/1_GROUP_data/TRPV1-analysis")
sys.path.insert(0, str(ROOT))
from src.conditions import Condition
from src import trajectory_io as tio

CATIONS = "resname POT SOD"       # K+, Na+
K_SEL, NA_SEL, CL_SEL = "resname POT", "resname SOD", "resname CLA"
CYL_R = 15.0                       # Angstrom radius around pore axis == "vestibule"


def log(msg):
    print(msg, flush=True)


def main():
    cond = Condition(T=305, salt_code="05", resolution="atom")
    log(f"# condition {cond.label} ({cond.salt_mM} mM), full system (with ions)")

    t0 = time.time()
    u = tio.universe(cond, centered=False, protein_only=False)
    log(f"[open ] Universe built in {time.time()-t0:5.1f} s   ({u.atoms.n_atoms} atoms)")

    prot = u.select_atoms("protein")
    K = u.select_atoms(K_SEL)
    Na = u.select_atoms(NA_SEL)
    Cl = u.select_atoms(CL_SEL)
    log(f"[ions ] protein={prot.n_atoms}  K+={K.n_atoms}  Na+={Na.n_atoms}  Cl-={Cl.n_atoms}")

    # --- first frame: geometry + membrane-normal check --------------------
    t0 = time.time()
    for ts in u.trajectory:          # sequential read of frame 0 (no offsets)
        break
    log(f"[read ] first frame streamed in {time.time()-t0:5.1f} s")
    box = ts.dimensions[:3]
    log(f"[geom ] box = {box[0]:.0f} x {box[1]:.0f} x {box[2]:.0f} A")

    # membrane normal: POPC phosphate z should be bimodal (two leaflets)
    P = u.select_atoms("resname POPC and name P")
    if P.n_atoms:
        pz = P.positions[:, 2]
        log(f"[geom ] POPC-P z: min={pz.min():.0f} max={pz.max():.0f} "
            f"spread={pz.max()-pz.min():.0f} A  (bilayer along z if two bands)")

    # --- sequential throughput over a short burst -------------------------
    com0 = prot.center_of_mass()
    log(f"[geom ] protein COM = ({com0[0]:.0f},{com0[1]:.0f},{com0[2]:.0f})")
    N_BURST = 12
    t0 = time.time()
    counts = []
    for ts in u.trajectory[1:1 + N_BURST]:
        com = prot.center_of_mass()
        # cylinder around pore axis (== z through protein COM)
        for name, grp in (("K", K), ("Na", Na), ("Cl", Cl)):
            if grp.n_atoms == 0:
                continue
            dxy = grp.positions[:, :2] - com[:2]
            r = np.sqrt((dxy ** 2).sum(1))
            zrel = grp.positions[:, 2] - com[2]
            in_cyl = (r < CYL_R)
            counts.append((name, int(in_cyl.sum()),
                           int((in_cyl & (np.abs(zrel) < 25)).sum())))
    dt = time.time() - t0
    log(f"[speed] {N_BURST} frames streamed in {dt:5.1f} s "
        f"= {dt/N_BURST:4.1f} s/frame  ->  strided(50) full pass ~"
        f"{dt/N_BURST*(400/ (u.trajectory.dt/1000) )/50/60:4.1f} min (rough)")

    # signal: cations/anions inside the r<15A cylinder, and within +-25A of COM
    import collections
    agg = collections.defaultdict(list)
    for name, ncyl, ncore in counts:
        agg[name].append((ncyl, ncore))
    log("[signal] per-frame ion count inside pore cylinder (r<15A):")
    for name in ("K", "Na", "Cl"):
        if name in agg:
            arr = np.array(agg[name])
            log(f"         {name:2s}:  cylinder mean={arr[:,0].mean():4.1f}  "
                f"core(|z|<25A) mean={arr[:,1].mean():4.1f}  "
                f"(over {len(arr)} frames)")

    # --- offset build cost (n_frames) — do this LAST, may be slow ---------
    log("[nfrm ] building offsets / n_frames (this scans the 38 GB file headers)...")
    t0 = time.time()
    try:
        n = u.trajectory.n_frames
        dt_ps = float(u.trajectory.dt)
        log(f"[nfrm ] n_frames={n}  dt={dt_ps:.1f} ps  "
            f"total={n*dt_ps/1000:.0f} ns   (offset build {time.time()-t0:.1f} s)")
    except Exception as e:
        log(f"[nfrm ] offset build FAILED/slow after {time.time()-t0:.1f} s: "
            f"{type(e).__name__}: {e}")

    log("# done")


if __name__ == "__main__":
    main()
