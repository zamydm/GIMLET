"""
PENSA step 4: extract small, protein-aligned local trajectories (protein + ions)
from the 38 GB full-system NPT.xtc, for the 305 K salinity row.

PENSA density featurization needs the trajectories (a) small and local (not
streamed 38 GB over SMB per pass) and (b) aligned to a COMMON reference so the
ion densities of different conditions live in the same coordinate frame and can
be compared voxel-by-voxel.

Common reference = the first kept frame of 305 K / 50 mM, protein CA.  Each
condition's protein is superposed onto it (rigid-body, CA), and the same
transform is applied to the ions.  Ion counts differ across salinity, so each
condition gets its own topology PDB (protein + its own ions).

Output (local scratch, NOT the synced Box dir):
  /tmp/trpv1_pensa/305K{SS}_protions.pdb   topology (protein + ions)
  /tmp/trpv1_pensa/305K{SS}_protions.xtc   aligned, strided trajectory
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import MDAnalysis as mda
from MDAnalysis.analysis import align

ROOT = Path("/Users/potoyan/Library/CloudStorage/Box-Box/1_GROUP_data/TRPV1-analysis")
sys.path.insert(0, str(ROOT))
from src.conditions import Condition
from src import trajectory_io as tio

LOCAL = Path("/tmp/trpv1_pensa")
LOCAL.mkdir(parents=True, exist_ok=True)

SALTS = ["05", "10", "15"]
TEMP = 305
# Global alignment reference shared by ALL (T, salt) extractions, so densities
# are comparable across BOTH temperature and salinity.  305 K / 50 mM, first
# kept frame.  Do not change once any condition has been extracted.
REF_T, REF_SALT = 305, "05"
ION_SEL = "resname POT SOD CLA"
KEEP_SEL = "protein or resname POT SOD CLA"
DROP_NS = 50.0
STRIDE = 20                       # ~875 frames/condition -> >100k ion samples, ample for density+JSD


def log(m):
    print(m, flush=True)


def extract(cond, ref):
    """Open the full-system universe ONCE; if ``ref`` is empty, seed the common
    alignment reference from this condition's first kept frame, then stream."""
    t0 = time.time()
    u = tio.universe(cond, centered=False, protein_only=False)   # single open
    dt_ps = float(u.trajectory.dt)
    start = int(round(DROP_NS * 1000 / dt_ps))
    sel = u.select_atoms(KEEP_SEL)
    ca = u.select_atoms("protein and name CA")

    if "ca" not in ref:                       # first condition defines the reference
        u.trajectory[start]
        rc = ca.center_of_mass()
        ref["ca"] = (ca.positions - rc).copy()
        ref["com"] = rc
        log(f"[ref] {cond.label} frame {start}: {ca.n_atoms} CA")
    assert ca.n_atoms == ref["ca"].shape[0], "CA count mismatch vs reference"
    log(f"  [{cond.label}] keep {sel.n_atoms} atoms "
        f"(prot {u.select_atoms('protein').n_atoms} + ions {u.select_atoms(ION_SEL).n_atoms}); "
        f"start={start} stride={STRIDE}  open+seek {time.time()-t0:.0f}s")

    pdb_out = LOCAL / f"{cond.label}_protions.pdb"
    xtc_out = LOCAL / f"{cond.label}_protions.xtc"
    nfr = 0
    t1 = time.time()
    with mda.Writer(str(xtc_out), sel.n_atoms) as w:
        for ts in u.trajectory[start::STRIDE]:
            mob_com = ca.center_of_mass()
            R, _ = align.rotation_matrix(ca.positions - mob_com, ref["ca"])
            sel.translate(-mob_com)
            sel.rotate(R)
            sel.translate(ref["com"])
            w.write(sel)
            if nfr == 0:
                sel.write(str(pdb_out))          # topology from first aligned frame
            nfr += 1
            if nfr % 200 == 0:
                log(f"  [{cond.label}] {nfr} frames  ({(time.time()-t1)/nfr:.2f}s/frame)")
    log(f"  [{cond.label}] DONE {nfr} frames in {time.time()-t1:.0f}s -> {xtc_out.name}")
    return nfr


def seed_reference(ref):
    """Seed ``ref`` from the fixed global reference (305 K / 50 mM, first kept
    frame) so every temperature and salinity aligns to the same frame."""
    cond = Condition(T=REF_T, salt_code=REF_SALT, resolution="atom")
    u = tio.universe(cond, centered=False, protein_only=False)
    start = int(round(DROP_NS * 1000 / float(u.trajectory.dt)))
    u.trajectory[start]
    ca = u.select_atoms("protein and name CA")
    rc = ca.center_of_mass()
    ref["ca"] = (ca.positions - rc).copy()
    ref["com"] = rc
    log(f"[ref] global reference = {cond.label} frame {start}: {ca.n_atoms} CA")


def main():
    # usage: 04_extract_local.py <salts, e.g. 05,10,15> [<temperature, e.g. 330>]
    salts = sys.argv[1].split(",") if len(sys.argv) > 1 else SALTS
    temp = int(sys.argv[2]) if len(sys.argv) > 2 else TEMP
    log(f"# extract protein+ions, {temp} K, salts {salts} -> {LOCAL}")
    ref = {}
    seed_reference(ref)                       # always the same global reference
    for sc in salts:
        cond = Condition(T=temp, salt_code=sc, resolution="atom")
        try:
            extract(cond, ref)
        except Exception as e:
            log(f"  [{cond.label}] FAILED: {type(e).__name__}: {e}")
    log("# done")


if __name__ == "__main__":
    main()
