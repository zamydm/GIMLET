# PENSA / ensemble-comparison exploration

Preliminary test of whether a PENSA-style ensemble comparison adds something
the ChACRA contact analysis cannot: **ion behaviour**. The mixed K+/Na+/Cl-
design was chosen to probe cation selectivity in gating, and contacts are
blind to ions, so the target is the ion distribution in the pore/vestibule and
how it shifts with salinity.

## Why not the `pensa` package directly
`pip install pensa` fails in this env: PENSA pulls in `pyemma`, which uses
`pkgutil.ImpImporter` (removed in Python 3.12+; this env is 3.14). PENSA's two
relevant capabilities — grid densities and Jensen-Shannon divergence between
ensembles — are a few lines of MDAnalysis + numpy, so the preliminary
reproduces that methodology directly. If we pursue it, run the packaged
version in a dedicated **Python 3.10 venv** (where pyemma builds).

## Data
Ions live only in the full-system production trajectory `NPT.xtc`
(~38 GB/condition); the protein-only `NPTProtein*.xtc` files used for ChACRA
stripped water and ions. Ion content per box: **K+ (POT) 120, Na+ (SOD) 184,
Cl- (CLA) 240** in a realistic asymmetric plasma-membrane bilayer
(POPC/SSM/CHL1/PAPC/DLPE/PAPS/POPE).

Read cost over SMB: one-time offset build ~220 s/condition (cached to a
`.npz` sidecar afterwards), then ~0.3 s/frame streaming. A strided pass is
~2-3 min/condition.

## Geometry (important)
- The full-system `.tpr` numbers residues **continuously** across the
  tetramer (chain A 1-556, B 557-1112, C 1113-1668, D 1669-2224), so
  residue-range selections do NOT pick the C4-symmetric pore.
- Pore axis is therefore defined **geometrically**: xy = centroid of all
  protein CA (on the C4 axis; protein is centred in the box).
- Axial zero z = **membrane midplane**, taken as the average of the two
  lipid-phosphate leaflet means (`name P`). Plain median is biased because
  the bilayer is compositionally asymmetric. +z = extracellular, -z =
  cytosolic; leaflets sit at ~±22 Å.

## Scripts
- `01_feasibility.py` — read-cost, geometry, and ion-signal probe on one
  condition. Establishes the facts above.
- `02_ion_density.py` — for the 305 K row (50/100/150 mM): axial ion density
  in the pore cylinder (r < 15 Å), vestibule occupancy, vestibule/bulk
  enrichment, and K/Na selectivity. Saves `outputs/iondens_305K*.npz`.
- `03_plot.py` — 2x2 figure (K/Na/Cl axial + enrichment/selectivity) and the
  verdict table. Writes `outputs/ion_density_305K.png`.

## Preliminary finding (smoke test, 20 frames)
Cl- is excluded from the vestibule (cation-channel check passes); Na+ peaks in
the extracellular outer vestibule (z ~ +15 Å) while K+ sits deeper and more
central (z ~ -6..+6 Å) — a clear differential K+/Na+ partitioning that
contacts cannot see. Full 600-frame/condition run in progress to test whether
that partition shifts systematically with salinity (the decision criterion).
