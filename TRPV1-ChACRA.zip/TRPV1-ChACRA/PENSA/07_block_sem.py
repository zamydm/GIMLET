"""
PENSA step 7: significance of the salinity divergence under 1-trajectory-per-
condition sampling.

Two quantities, both using PENSA's relative_entropy_analysis as the JSD engine:

  between-condition JSD (block SEM)
      split each condition's occupancy timeseries into K contiguous blocks,
      compute JSD(block_A, block_B) per block, report mean +- SEM.  This is the
      uncertainty on the reported divergence.

  within-condition noise floor (split-half)
      JSD between the first and second half of the SAME trajectory, averaged
      over the three conditions.  This is the divergence you get from finite
      sampling alone, with NO change in conditions.  A between-condition JSD is
      only credible if it clears this floor.

Re-featurizes on the SAME shared grids written by 05 (so sites match exactly).

Run with the PENSA env:
  /opt/miniconda3/envs/pensa/bin/python PENSA/07_block_sem.py
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from pensa.features import read_atom_features
from pensa.comparison import relative_entropy_analysis

ROOT = Path("/Users/potoyan/Library/CloudStorage/Box-Box/1_GROUP_data/TRPV1-analysis")
LOCAL = Path("/tmp/trpv1_pensa")
GRID = LOCAL / "grids"
OUT = ROOT / "PENSA" / "outputs"

IONS = [("POT", "K"), ("SOD", "Na"), ("CLA", "Cl")]
ICOL = {"K": "#2166ac", "Na": "#b2182b", "Cl": "#7a7a7a"}
CONDS = ["05", "10", "15"]
MM = {"05": 50, "10": 100, "15": 150}
TOP_ATOMS = 8
BIN_NUM = 2
K_BLOCKS = 5


def occ_matrix(fn, fd, label):
    key = f"{label}Pocket_OccupDistr"
    arrs = [np.asarray(a, dtype=float) for a in fd[key]]
    n = min(len(a) for a in arrs)
    return fn[key], np.stack([a[:n] for a in arrs], axis=1)   # names, [frames, sites]


def jsd(names, A, B):
    _, j, _, _ = relative_entropy_analysis(names, names, A, B, bin_num=BIN_NUM,
                                           verbose=False, override_name_check=True)
    return np.asarray(j, float)


def blocks(x, k):
    n = len(x) // k
    return [x[i * n:(i + 1) * n] for i in range(k)]


def main():
    sites_json = json.loads((OUT / "pensa_ion_sites.json").read_text())
    result = {}
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.6))

    for ax, (atomgroup, label) in zip(axes, IONS):
        grid_dx = str(GRID / f"comb_{label}_{atomgroup}_density.dx")
        occ = {}
        names = None
        for c in CONDS:
            fn, fd = read_atom_features(str(LOCAL / f"305K{c}_protions.pdb"),
                                        str(LOCAL / f"305K{c}_protions.xtc"),
                                        atomgroup, label, top_atoms=TOP_ATOMS,
                                        grid_input=grid_dx)
            names, occ[c] = occ_matrix(fn, fd, label)

        nsite = occ["05"].shape[1]
        # between-condition 50 vs 150, block SEM
        a, b = "05", "15"
        na = min(len(occ[a]), len(occ[b]))
        bl_a, bl_b = blocks(occ[a][:na], K_BLOCKS), blocks(occ[b][:na], K_BLOCKS)
        jsd_blocks = np.array([jsd(names, bl_a[i], bl_b[i]) for i in range(K_BLOCKS)])
        jbetween = jsd_blocks.mean(0)
        jsem = jsd_blocks.std(0) / np.sqrt(K_BLOCKS)

        # within-condition noise floor (split-half, averaged over conditions)
        floor = []
        for c in CONDS:
            h = len(occ[c]) // 2
            floor.append(jsd(names, occ[c][:h], occ[c][h:2 * h]))
        floor = np.array(floor)
        noise_mean = floor.mean(0)
        noise_hi = floor.mean(0) + floor.std(0)

        # order sites by axial z (from the saved sites)
        xyz = np.array(sites_json[label]["sites_xyz"])
        order = np.argsort(-xyz[:, 2])
        x = np.arange(nsite)
        sig = jbetween - jsem > noise_hi                       # clears the noise band
        ax.bar(x, jbetween[order], yerr=jsem[order], color=ICOL[label],
               edgecolor="black", linewidth=0.5, capsize=3,
               label="50→150 mM JSD ± block SEM")
        ax.step(np.concatenate([[-.5], x + .5]),
                np.concatenate([[noise_mean[order][0]], noise_mean[order]]),
                where="pre", color="0.35", lw=1.2)
        ax.fill_between(np.concatenate([[-.5], x + .5]),
                        np.concatenate([[0], noise_mean[order] * 0]),
                        np.concatenate([[noise_hi[order][0]], noise_hi[order]]),
                        step="pre", color="0.75", alpha=0.5, label="within-traj noise (mean+σ)")
        for xi, si in zip(x, order):
            if sig[si]:
                ax.text(xi, jbetween[si] + jsem[si] + 0.01, "*", ha="center",
                        fontsize=14, color="black")
        ax.set_xticks(x)
        ax.set_xticklabels([f"z{xyz[i,2]-xyz[:,2].mean():+.0f}" for i in order],
                           rotation=45, fontsize=8)
        ax.set_title(f"{label}$^{{{'+' if label!='Cl' else '-'}}}$")
        ax.set_xlabel("ion pocket (axial z, arb. origin)")
        if label == "K":
            ax.set_ylabel("Jensen-Shannon distance")
            ax.legend(fontsize=8, frameon=False, loc="upper right")

        result[label] = {
            "jsd_50v150_mean": jbetween.tolist(), "jsd_50v150_sem": jsem.tolist(),
            "noise_floor_mean": noise_mean.tolist(), "noise_floor_hi": noise_hi.tolist(),
            "n_significant": int(sig.sum()),
            "sites_significant": [int(i) for i in np.where(sig)[0]],
        }
        print(f"[{label}] {int(sig.sum())}/{nsite} pockets clear the noise floor "
              f"(50→150); max JSD {jbetween.max():.3f}", flush=True)

    fig.suptitle("Significance of salinity divergence vs within-trajectory noise (305 K, 50→150 mM)",
                 fontsize=13, fontweight="bold")
    fig.tight_layout()
    out = OUT / "pensa_block_sem.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    (OUT / "pensa_block_sem.json").write_text(json.dumps(result, indent=2))
    print(f"saved {out}")


if __name__ == "__main__":
    main()
