"""
PENSA preliminary — step 3: figure + verdict.

Loads the per-condition ion-density arrays (iondens_305K*.npz) and makes a
2x2 summary:
  (a) K+  axial density vs z, one curve per salinity
  (b) Na+ axial density vs z, one curve per salinity
  (c) Cl- axial density vs z (cation-channel exclusion check)
  (d) vestibule cation enrichment vs salinity, with K/Na selectivity ratio

z = 0 is the membrane midplane; +z extracellular, -z cytosolic; grey bands
mark the lipid-phosphate leaflets.  Salinity is coloured light->dark red
(consistent with "salt = red" in the main ChACRA figure).
"""
from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path("/Users/potoyan/Library/CloudStorage/Box-Box/1_GROUP_data/TRPV1-analysis")
OUT = ROOT / "PENSA" / "outputs"
SALTS = ["05", "10", "15"]
MM = {"05": 50, "10": 100, "15": 150}

mpl.rcParams.update({
    "font.family": "sans-serif", "font.size": 12.5, "axes.titlesize": 13.5,
    "axes.labelsize": 12.5, "xtick.labelsize": 11, "ytick.labelsize": 11,
    "legend.fontsize": 10, "axes.spines.top": False, "axes.spines.right": False,
})
SCOL = {s: plt.cm.Reds(v) for s, v in zip(SALTS, [0.45, 0.68, 0.92])}


def load():
    d = {}
    for s in SALTS:
        f = OUT / f"iondens_305K{s}.npz"
        if f.exists():
            d[s] = dict(np.load(f, allow_pickle=True))
    return d


def main():
    d = load()
    if not d:
        print("no iondens_*.npz yet")
        return
    any_r = next(iter(d.values()))
    zc = any_r["zc"]
    up = np.mean([d[s]["leaflet_up"] for s in d])
    dn = np.mean([d[s]["leaflet_dn"] for s in d])

    fig, axes = plt.subplots(2, 2, figsize=(11.5, 8.4))
    (axK, axNa), (axCl, axE) = axes

    def axial(ax, key, title):
        for s in d:
            ax.plot(zc, d[s][key], "-o", ms=3.2, lw=1.8, color=SCOL[s],
                    label=f"{MM[s]} mM")
        ax.axvspan(up - 2, up + 2, color="0.85", zorder=0)
        ax.axvspan(dn - 2, dn + 2, color="0.85", zorder=0)
        ax.axvline(0, color="0.6", lw=0.8, ls="--")
        ax.set_xlabel("axial position z  (Å,  0 = membrane midplane)")
        ax.set_ylabel("ions per 2 Å slab  (r < 15 Å)")
        ax.set_title(title)
        ax.set_xlim(zc.min(), zc.max())
    axial(axK, "axial_K", "a   K$^+$ axial density")
    axial(axNa, "axial_Na", "b   Na$^+$ axial density")
    axial(axCl, "axial_Cl", "c   Cl$^-$ axial density")
    axK.legend(title="salinity", frameon=False)
    for ax in (axK, axNa, axCl):
        ax.annotate("extracellular", (0.98, 0.94), xycoords="axes fraction",
                    ha="right", fontsize=9, color="0.4")
        ax.annotate("cytosolic", (0.02, 0.94), xycoords="axes fraction",
                    ha="left", fontsize=9, color="0.4")

    # (d) enrichment + selectivity vs salinity
    xs = [MM[s] for s in d]
    eK = [float(d[s]["enrich_K"]) for s in d]
    eNa = [float(d[s]["enrich_Na"]) for s in d]
    sel = [float(d[s]["selectivity_K_over_Na"]) for s in d]
    axE.plot(xs, eK, "-o", color="#2166ac", lw=2, ms=7, label="K$^+$ enrichment")
    axE.plot(xs, eNa, "-s", color="#b2182b", lw=2, ms=7, label="Na$^+$ enrichment")
    axE.axhline(1, color="0.6", lw=0.8, ls=":")
    axE.set_xlabel("salinity (mM)"); axE.set_ylabel("vestibule / bulk enrichment")
    axE.set_title("d   cation enrichment & K/Na selectivity")
    axE.set_xticks(xs)
    axE.legend(frameon=False, loc="upper left")
    for x, sv in zip(xs, sel):
        axE.annotate(f"S={sv:.2f}", (x, max(eK + eNa) * 0.98), ha="center",
                     fontsize=9.5, color="0.25")

    fig.tight_layout()
    out = OUT / "ion_density_305K.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    print(f"saved {out}")

    # verdict table
    print("\n# ---- verdict table (305 K) ----")
    print(f"{'salt':>6} {'vestK':>6} {'vestNa':>7} {'vestCl':>7} "
          f"{'enrK':>6} {'enrNa':>6} {'S(K/Na)':>8}")
    for s in d:
        r = d[s]
        print(f"{MM[s]:>6} {float(r['vest_K']):>6.2f} {float(r['vest_Na']):>7.2f} "
              f"{float(r['vest_Cl']):>7.2f} {float(r['enrich_K']):>6.2f} "
              f"{float(r['enrich_Na']):>6.2f} {float(r['selectivity_K_over_Na']):>8.2f}")


if __name__ == "__main__":
    main()
