"""
PENSA preliminary — step 2: ion axial density + cation selectivity vs salinity.

Scientific question the mixed K+/Na+/Cl- design was built for: does the
channel vestibule partition K+ vs Na+ differently, and does that partition
shift with bulk salinity?  This is the one axis ChACRA-on-contacts cannot see
and the reason PENSA (grid densities + divergence) was proposed.

Preliminary = one temperature row (305 K) across the three salinities
(50 / 100 / 150 mM).  We reproduce PENSA's density-featurization idea with
MDAnalysis directly (no pyemma build needed).

Pore axis is defined GEOMETRICALLY (numbering-free): the full-system .tpr
numbers residues continuously across the tetramer (chain A 1-556, B 557-1112,
...), so residue-range selections do NOT give the C4-symmetric pore.  Instead:

  pore axis (xy) : centroid of all protein CA  -> lies on the C4 axis
                   (protein is centred at the box centre)
  axial zero (z) : membrane midplane = median(POPC-P z); the pore/SF/gate sit
                   within +-20 A of this.  +z = extracellular, -z = cytosolic.
  vestibule      : cylinder r < R_CYL around the pore axis
  axial density  : <ions per 2 A slab of the cylinder>, per species
  enrichment     : vestibule number-density / bulk-shell number-density
  selectivity    : enrichment(K) / enrichment(Na)

Per-condition arrays saved immediately so a killed SMB read leaves usable
partial output.  Decision heuristic printed at the end.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path("/Users/potoyan/Library/CloudStorage/Box-Box/1_GROUP_data/TRPV1-analysis")
sys.path.insert(0, str(ROOT))
from src.conditions import Condition
from src import trajectory_io as tio

OUT = ROOT / "PENSA" / "outputs"
OUT.mkdir(parents=True, exist_ok=True)

SALTS = ["05", "10", "15"]        # 50 / 100 / 150 mM at 305 K
TEMP = 305
R_CYL = 15.0                      # vestibule cylinder radius (A)
R_AXIS = 12.0                     # near-axis CA radius (unused for centre now)
R_BULK_IN, R_BULK_OUT = 40.0, 70.0   # bulk reference shell (A)
Z_WIN = 25.0                      # |z| window for occupancy/enrichment (A)
ZBINS = np.arange(-40, 40.001, 2.0)   # axial histogram edges
ZC = 0.5 * (ZBINS[:-1] + ZBINS[1:])
DROP_NS = 50.0                    # equilibration discard
TARGET_FRAMES = 600               # per condition after equilibration


def log(m):
    print(m, flush=True)


def minimg_xy(dxy, box_xy):
    return dxy - box_xy * np.round(dxy / box_xy)


def process(cond):
    t0 = time.time()
    u = tio.universe(cond, centered=False, protein_only=False)
    log(f"  [{cond.label}] open {time.time()-t0:.0f}s  n_frames={u.trajectory.n_frames}")

    prot_ca = u.select_atoms("protein and name CA")
    memP = u.select_atoms("name P")   # ALL lipid phosphates (asymmetric mixed membrane)
    K = u.select_atoms("resname POT")
    Na = u.select_atoms("resname SOD")
    Cl = u.select_atoms("resname CLA")
    species = {"K": K, "Na": Na, "Cl": Cl}
    log(f"  [{cond.label}] protein CA={prot_ca.n_atoms}  POPC-P={memP.n_atoms}  "
        f"K={K.n_atoms} Na={Na.n_atoms} Cl={Cl.n_atoms}")

    dt_ps = float(u.trajectory.dt)
    start = int(round(DROP_NS * 1000 / dt_ps))
    stride = max(1, (u.trajectory.n_frames - start) // TARGET_FRAMES)

    hist = {s: np.zeros(len(ZC)) for s in species}          # summed axial counts (r<R_CYL)
    vest = {s: [] for s in species}                         # per-frame # in vestibule (|z|<Z_WIN)
    bulk = {s: [] for s in species}                         # per-frame # in bulk shell
    up_z, dn_z = [], []                                     # leaflet positions rel. z0
    nfr = 0
    t0 = time.time()
    for ts in u.trajectory[start::stride]:
        box_xy = ts.dimensions[:2]
        axis_xy = prot_ca.positions[:, :2].mean(0)          # C4 axis (protein centred)
        pz = memP.positions[:, 2]
        m = pz.mean()                                       # symmetric midplane: mean of the
        z0 = 0.5 * (pz[pz > m].mean() + pz[pz < m].mean())  # two leaflet means (population-safe)
        up_z.append(float(pz[pz > z0].mean()) - z0)
        dn_z.append(float(pz[pz < z0].mean()) - z0)
        for s, grp in species.items():
            p = grp.positions
            r = np.sqrt((minimg_xy(p[:, :2] - axis_xy, box_xy) ** 2).sum(1))
            z = p[:, 2] - z0
            incyl = r < R_CYL
            hist[s] += np.histogram(z[incyl], bins=ZBINS)[0]
            vest[s].append(int((incyl & (np.abs(z) < Z_WIN)).sum()))
            inbulk = (r >= R_BULK_IN) & (r < R_BULK_OUT) & (np.abs(z) < Z_WIN)
            bulk[s].append(int(inbulk.sum()))
        nfr += 1
        if nfr % 100 == 0:
            log(f"  [{cond.label}] {nfr} frames  ({(time.time()-t0)/nfr:.2f}s/frame)")

    v_vest = np.pi * R_CYL**2 * (2 * Z_WIN)
    v_bulk = np.pi * (R_BULK_OUT**2 - R_BULK_IN**2) * (2 * Z_WIN)
    res = {"label": cond.label, "salt_mM": cond.salt_mM, "n_frames": nfr,
           "zc": ZC, "leaflet_up": float(np.mean(up_z)), "leaflet_dn": float(np.mean(dn_z))}
    for s in species:
        res[f"axial_{s}"] = hist[s] / max(nfr, 1)            # <ions per slab>
        nv = float(np.mean(vest[s])); nb = float(np.mean(bulk[s]))
        res[f"vest_{s}"] = nv
        res[f"bulk_{s}"] = nb
        res[f"vest_sem_{s}"] = float(np.std(vest[s]) / np.sqrt(max(nfr, 1)))
        res[f"enrich_{s}"] = (nv / v_vest) / ((nb / v_bulk) if nb > 0 else np.nan)
    res["selectivity_K_over_Na"] = res["enrich_K"] / res["enrich_Na"] \
        if res["enrich_Na"] and np.isfinite(res["enrich_Na"]) else np.nan

    np.savez(OUT / f"iondens_{cond.label}.npz", **res)
    log(f"  [{cond.label}] DONE {nfr} frames in {time.time()-t0:.0f}s  "
        f"vest K/Na/Cl = {res['vest_K']:.2f}/{res['vest_Na']:.2f}/{res['vest_Cl']:.2f}  "
        f"enrich K/Na = {res['enrich_K']:.2f}/{res['enrich_Na']:.2f}  "
        f"S(K/Na)={res['selectivity_K_over_Na']:.2f}")
    return res


def main():
    salts = sys.argv[1].split(",") if len(sys.argv) > 1 else SALTS
    log(f"# ion-density preliminary, {TEMP} K row, salts {salts}")
    results = []
    for sc in salts:
        cond = Condition(T=TEMP, salt_code=sc, resolution="atom")
        try:
            results.append(process(cond))
        except Exception as e:
            log(f"  [{cond.label}] FAILED: {type(e).__name__}: {e}")

    if results:
        log("\n# ---- summary (305 K) ----")
        log(f"{'salt':>6} {'vestK':>6} {'vestNa':>7} {'vestCl':>7} "
            f"{'enrK':>6} {'enrNa':>6} {'S(K/Na)':>8}")
        for r in results:
            log(f"{r['salt_mM']:>6} {r['vest_K']:>6.2f} {r['vest_Na']:>7.2f} "
                f"{r['vest_Cl']:>7.2f} {r['enrich_K']:>6.2f} {r['enrich_Na']:>6.2f} "
                f"{r['selectivity_K_over_Na']:>8.2f}")
    log("# done")


if __name__ == "__main__":
    main()
