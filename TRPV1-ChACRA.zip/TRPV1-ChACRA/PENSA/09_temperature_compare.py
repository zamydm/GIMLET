"""
PENSA step 9: temperature effect on the ion sites (305 K vs 330 K).

Reuses the ion-pocket grids written by 05 (defined from the 305 K combined
density), so the SAME sites are featurized at both temperatures.  For each ion
and salinity we compute the Jensen-Shannon distance between 305 K and 330 K
occupancy at each pocket, and compare the magnitude of the temperature effect
to the salinity effect (50->150 mM at 305 K) from 05.

Because TRPV1 is a heat sensor, the question is whether raising temperature
reorganizes the cation sites as much as changing salinity does, and whether the
selectivity-filter site (K+ pocket at G644) is temperature-sensitive.

Run with the PENSA env:
  /opt/miniconda3/envs/pensa/bin/python PENSA/09_temperature_compare.py
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from pensa.features import read_atom_features
from pensa.comparison import relative_entropy_analysis

ROOT = Path("/Users/potoyan/Library/CloudStorage/Box-Box/1_GROUP_data/TRPV1-analysis")
LOCAL = Path("/tmp/trpv1_pensa")
GRID = LOCAL / "grids"
OUT = ROOT / "PENSA" / "outputs"

IONS = [("POT", "K"), ("SOD", "Na"), ("CLA", "Cl")]
ICOL = {"K": "#2166ac", "Na": "#b2182b", "Cl": "#7a7a7a"}
SALTS = ["05", "10", "15"]
MM = {"05": 50, "10": 100, "15": 150}
TOP_ATOMS = 8
BIN_NUM = 2


def occ_ts(pdb, xtc, atomgroup, label, grid_dx):
    fn, fd = read_atom_features(pdb, xtc, atomgroup, label, top_atoms=TOP_ATOMS,
                               grid_input=grid_dx)
    key = f"{label}Pocket_OccupDistr"
    arrs = [np.asarray(a, dtype=float) for a in fd[key]]
    n = min(len(a) for a in arrs)
    return fn[key], np.stack([a[:n] for a in arrs], axis=1)


def jsd(names, A, B):
    n = min(len(A), len(B))
    _, j, _, _ = relative_entropy_analysis(names, names, A[:n], B[:n], bin_num=BIN_NUM,
                                           verbose=False, override_name_check=True)
    return np.asarray(j, float)


def have(temp, sc):
    return (LOCAL / f"{temp}K{sc}_protions.pdb").exists() and \
           (LOCAL / f"{temp}K{sc}_protions.xtc").exists()


def main():
    salt_json = json.loads((OUT / "pensa_ion_sites.json").read_text())
    result = {}
    fig, ax = plt.subplots(figsize=(9.5, 5.2))
    xlab, xs, k = [], [], 0

    for atomgroup, label in IONS:
        grid_dx = str(GRID / f"comb_{label}_{atomgroup}_density.dx")
        per_salt_T = {}
        for sc in SALTS:
            if not (have(305, sc) and have(330, sc)):
                continue
            names, o305 = occ_ts(str(LOCAL / f"305K{sc}_protions.pdb"),
                                 str(LOCAL / f"305K{sc}_protions.xtc"), atomgroup, label, grid_dx)
            _, o330 = occ_ts(str(LOCAL / f"330K{sc}_protions.pdb"),
                             str(LOCAL / f"330K{sc}_protions.xtc"), atomgroup, label, grid_dx)
            jT = jsd(names, o305, o330)
            per_salt_T[MM[sc]] = jT.tolist()
            print(f"[{label}] 305→330 K at {MM[sc]} mM: mean JSD {jT.mean():.3f} "
                  f"(max {jT.max():.3f})", flush=True)
        # salinity reference (50->150 at 305 K) from step 5
        salt_ref = np.mean(salt_json[label]["jsd"]["50v150"])
        result[label] = {"jsd_305v330_by_salt": per_salt_T, "jsd_50v150_305K": float(salt_ref)}

        # plot: mean T-JSD at each salinity + salt reference
        for sc in SALTS:
            if MM[sc] in per_salt_T:
                xs.append(k); xlab.append(f"{label}\n{MM[sc]}mM")
                ax.bar(k, np.mean(per_salt_T[MM[sc]]), 0.8, color=ICOL[label],
                       edgecolor="black", linewidth=0.4)
                k += 1
        ax.axhline(salt_ref, xmin=(k-3.4)/max(k,1) if k else 0, color=ICOL[label],
                   ls="--", lw=1.3)
        k += 0.6

    ax.set_xticks(xs); ax.set_xticklabels(xlab, fontsize=9)
    ax.set_ylabel("Jensen-Shannon distance  (305 K → 330 K)")
    ax.set_title("Temperature effect on ion-pocket occupancy\n"
                 "(dashed = salinity effect 50→150 mM at 305 K, same ion)")
    fig.tight_layout()
    out = OUT / "pensa_temperature.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    (OUT / "pensa_temperature.json").write_text(json.dumps(result, indent=2))
    print(f"\nsaved {out}")


if __name__ == "__main__":
    main()
