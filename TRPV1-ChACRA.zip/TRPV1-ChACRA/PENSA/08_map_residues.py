"""
PENSA step 8: map each ion pocket to its nearest channel residues.

The pocket coordinates (from pensa_ion_sites.json) live in the common aligned
reference frame, which is the original coordinate frame of 305K05 frame 2500;
the local reference PDB (305K05_protions.pdb) shares that frame, so nearest-
residue assignment is a direct distance query.

The full-system topology numbers residues continuously (chain A 1-556,
B 557-1112, ...).  We translate to the crystal numbering used elsewhere in the
paper by matching residue order against the crystal PDB (8GFARepairCenter.pdb):
the i-th modelled residue of a chain is the same residue in both files.

Run with the llpsmd env:
  /opt/miniconda3/envs/llpsmd-new/bin/python PENSA/08_map_residues.py
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import MDAnalysis as mda

ROOT = Path("/Users/potoyan/Library/CloudStorage/Box-Box/1_GROUP_data/TRPV1-analysis")
LOCAL = Path("/tmp/trpv1_pensa")
OUT = ROOT / "PENSA" / "outputs"
CRYSTAL_PDB = "/Volumes/potoyan-lab/zach/TRPV1Simulations/Protein/8GFARepairCenter.pdb"

IONS = ["K", "Na", "Cl"]
ATOMG = {"K": "POT", "Na": "SOD", "Cl": "CLA"}
CHAINS = "ABCD"
NEAR = 8.0            # Angstrom search radius
TOP = 3              # nearest residues to report per pocket


def crystal_index_map():
    """Ordered crystal residue numbers for one chain (index -> crystal resid),
    from the crystal PDB.  Returns None if the file can't be read."""
    try:
        cu = mda.Universe(CRYSTAL_PDB)
        seg = sorted(set(cu.select_atoms("protein").segids))[0]
        ca = cu.select_atoms(f"protein and name CA and segid {seg}")
        return list(ca.resids)
    except Exception as e:
        print(f"[warn] crystal PDB unreadable ({e}); reporting continuous resid only")
        return None


def to_crystal(cont_resid, cmap, per_chain=556):
    if cmap is None:
        return None, "?"
    idx = (cont_resid - 1) % per_chain
    chain = CHAINS[(cont_resid - 1) // per_chain]
    return (cmap[idx] if idx < len(cmap) else None), chain


def main():
    data = json.loads((OUT / "pensa_ion_sites.json").read_text())
    u = mda.Universe(str(LOCAL / "305K05_protions.pdb"))
    prot = u.select_atoms("protein")
    ppos = prot.positions
    cmap = crystal_index_map()

    report = {}
    for ion in IONS:
        sites = np.array(data[ion]["sites_xyz"])
        print(f"\n#### {ion}  ({ATOMG[ion]}) ion pockets ####")
        entries = []
        for i, xyz in enumerate(sites):
            d = np.linalg.norm(ppos - xyz, axis=1)
            sel = d < NEAR
            # per-residue minimum distance
            res_best = {}
            for ai in np.where(sel)[0]:
                at = prot[ai]
                key = (at.segid, int(at.resid), at.resname)
                res_best[key] = min(res_best.get(key, 1e9), float(d[ai]))
            nearest = sorted(res_best.items(), key=lambda kv: kv[1])[:TOP]
            labels = []
            for (seg, rid, rn), dist in nearest:
                cr, ch = to_crystal(rid, cmap)
                tag = f"{rn}{cr}:{ch}" if cr is not None else f"{rn}{rid}"
                labels.append(f"{tag}({dist:.1f}Å)")
            occ_str = "/".join(f"{data[ion]['occupancy'][m][i]:.2f}" for m in ["50", "100", "150"])
            resid_here = "n/a" if not nearest else ", ".join(labels)
            print(f"  pocket {i}  z={xyz[2]:.0f}  occ(50/100/150)={occ_str}  ->  {resid_here}")
            entries.append({"pocket": i, "xyz": xyz.tolist(),
                            "occ_50_100_150": [data[ion]['occupancy'][m][i] for m in ["50","100","150"]],
                            "nearest_residues": labels})
        report[ion] = entries

    (OUT / "pensa_pocket_residues.json").write_text(json.dumps(report, indent=2))
    print(f"\nsaved {OUT / 'pensa_pocket_residues.json'}")


if __name__ == "__main__":
    main()
