"""
PENSA step 5: ion-pocket density featurization + relative-entropy (JSD) between
salinities, using the real PENSA 0.6.0 API.

Pipeline (per ion species K+/Na+/Cl-):
  1. extract_combined_grid  -> one shared density grid (.dx) built from two
     salinity ensembles, so the density maxima ("ion pockets") are defined on a
     common grid.  prot_prox=True restricts to pockets within 3.5 A of the
     channel (binding sites on the protein, not bulk).
  2. read_atom_features(..., grid_input=shared_grid) for EACH salinity -> the
     same top-N pockets, with a per-frame occupancy timeseries for each.
     (The per-condition atom-count scaling cancels in the density threshold, so
     identical grid -> identical pockets -> comparable features.)
  3. relative_entropy_analysis -> Jensen-Shannon distance per pocket between
     salinities: which ion sites change their occupancy with salt.

Operates on the small aligned local files from step 4 (protein + ions, common
reference frame), so no 38 GB SMB streaming here.

Outputs (PENSA/outputs/):
  pensa_ion_sites.json   per ion: pocket xyz, per-condition occupancy, pairwise JSD
  grids/*.dx             shared density grids (for rendering)
"""
from __future__ import annotations

import json
from itertools import combinations
from pathlib import Path

import numpy as np

# NB: run this with the PENSA env interpreter:
#   /opt/miniconda3/envs/pensa/bin/python PENSA/05_pensa_density.py
from pensa.preprocessing import extract_combined_grid
from pensa.features import read_atom_features
from pensa.comparison import relative_entropy_analysis

ROOT = Path("/Users/potoyan/Library/CloudStorage/Box-Box/1_GROUP_data/TRPV1-analysis")
LOCAL = Path("/tmp/trpv1_pensa")
GRID = LOCAL / "grids"
GRID.mkdir(parents=True, exist_ok=True)
OUT = ROOT / "PENSA" / "outputs"

IONS = [("POT", "K"), ("SOD", "Na"), ("CLA", "Cl")]
MM = {"05": 50, "10": 100, "15": 150}
TOP_ATOMS = 8                    # number of pockets to featurize per ion
BIN_NUM = 2                      # occupancy is ~binary; 2 bins for the JSD histogram


def log(m):
    print(m, flush=True)


def available_conditions():
    conds = []
    for sc in ["05", "10", "15"]:
        pdb = LOCAL / f"305K{sc}_protions.pdb"
        xtc = LOCAL / f"305K{sc}_protions.xtc"
        if pdb.exists() and xtc.exists():
            conds.append(sc)
    return conds


def occup_matrix(feat_names, feat_data, label):
    """[frames, sites] float matrix from the OccupDistr feature."""
    key = f"{label}Pocket_OccupDistr"
    arrs = [np.asarray(a, dtype=float) for a in feat_data[key]]
    n = min(len(a) for a in arrs)
    mat = np.stack([a[:n] for a in arrs], axis=1)     # [frames, sites]
    return feat_names[key], mat


def main():
    conds = available_conditions()
    if len(conds) < 2:
        log(f"need >=2 extracted conditions, have {conds}; run 04 first")
        return
    log(f"# PENSA ion-pocket density + JSD; conditions {conds} (mM {[MM[c] for c in conds]})")
    files = {c: (str(LOCAL / f"305K{c}_protions.pdb"),
                 str(LOCAL / f"305K{c}_protions.xtc")) for c in conds}

    results = {}
    for atomgroup, label in IONS:
        log(f"\n#### {label}+ ({atomgroup}) ####")
        a, b = conds[0], conds[-1]           # span the salt range for the shared grid
        prefix = str(GRID / f"comb_{label}_")
        log(f"[grid] combined density from {MM[a]} + {MM[b]} mM ...")
        # use_memmap=True avoids a PENSA bug in the default path: it calls
        # AnalysisFromFunction(...).run().results, which under MDAnalysis 2.8
        # returns a Results object (data under .timeseries) rather than a raw
        # array, leaking the string 'timeseries' into the coordinates. The
        # memmap path reads atoms.positions directly and is unaffected.
        extract_combined_grid(files[a][0], files[a][1], files[b][0], files[b][1],
                              atomgroup, write_grid_as="Angstrom^{-3}",
                              out_name=prefix, prot_prox=True,
                              use_memmap=True,
                              memmap=str(GRID / f"comb_{label}.mymemmap"))
        grid_dx = f"{prefix}{atomgroup}_density.dx"

        feats, occ_mats = {}, {}
        for c in conds:
            fn, fd = read_atom_features(files[c][0], files[c][1], atomgroup, label,
                                        top_atoms=TOP_ATOMS, grid_input=grid_dx)
            names, mat = occup_matrix(fn, fd, label)
            feats[c] = (fn, fd, names)
            occ_mats[c] = mat
            freq = fd[f"{label}Pocket_Occup"]
            log(f"[{MM[c]:>3} mM] {mat.shape[1]} pockets, "
                f"occupancy freq = {np.round(np.asarray(freq, float), 3).tolist()}")

        sites_xyz = [list(map(float, x)) for x in feats[conds[0]][1][f"{label}Pocket_xyz"]]
        entry = {"sites_xyz": sites_xyz,
                 "occupancy": {MM[c]: np.asarray(feats[c][1][f"{label}Pocket_Occup"], float).tolist()
                               for c in conds},
                 "jsd": {}}
        for ca, cb in combinations(conds, 2):
            na = feats[ca][2]; nb = feats[cb][2]
            dn, jsd, kab, kba = relative_entropy_analysis(
                na, nb, occ_mats[ca], occ_mats[cb], bin_num=BIN_NUM,
                verbose=False, override_name_check=True)
            entry["jsd"][f"{MM[ca]}v{MM[cb]}"] = np.asarray(jsd, float).tolist()
            log(f"[JSD] {MM[ca]} vs {MM[cb]} mM: per-pocket "
                f"{np.round(jsd,3).tolist()}  (mean {np.mean(jsd):.3f})")
        results[label] = entry

    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / "pensa_ion_sites.json", "w") as f:
        json.dump(results, f, indent=2)
    log(f"\nsaved {OUT / 'pensa_ion_sites.json'}")
    log("# done")


if __name__ == "__main__":
    main()
